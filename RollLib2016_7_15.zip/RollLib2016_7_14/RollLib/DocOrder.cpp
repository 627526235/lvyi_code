// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// RollDoc.cpp : CDocOrder ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "RollLib.h"
#endif

#include "DocOrder.h"
#include "DBmySQL.h"
#include "Compute.h"

#include <propkey.h>

#include "MainFrm.h"

//------------------------begin yangfan 2016_4_28
#include"NewCustomer.h"
//------------------------end   yangfan 2016_4_28





#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDocOrder

IMPLEMENT_DYNCREATE(CDocOrder, CDocument)

BEGIN_MESSAGE_MAP(CDocOrder, CDocument)
	//ON_COMMAND(ID_BTN_DB_INSERT, &CDocOrder::OnBtnDbInsert)
	//ON_UPDATE_COMMAND_UI(ID_BTN_DB_INSERT, &CDocOrder::OnUpdateBtnDbInsert)
	ON_COMMAND(ID_BTN_DB_FIRST, &CDocOrder::OnBtnDbFirst)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_FIRST, &CDocOrder::OnUpdateBtnDbFirst)
	ON_COMMAND(ID_BTN_DB_LAST, &CDocOrder::OnBtnDbLast)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_LAST, &CDocOrder::OnUpdateBtnDbLast)
	ON_COMMAND(ID_BTN_DB_PREV, &CDocOrder::OnBtnDbPrev)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_PREV, &CDocOrder::OnUpdateBtnDbPrev)
	ON_COMMAND(ID_BTN_DB_DEL, &CDocOrder::OnBtnDbDel)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_DEL, &CDocOrder::OnUpdateBtnDbDel)
	ON_COMMAND(ID_BTN_DB_NEXT, &CDocOrder::OnBtnDbNext)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_NEXT, &CDocOrder::OnUpdateBtnDbNext)
	//ON_COMMAND(ID_BTN_DB_QUERY, &CDocOrder::OnBtnDbQuery)
	//ON_UPDATE_COMMAND_UI(ID_BTN_DB_QUERY, &CDocOrder::OnUpdateBtnDbQuery)
	ON_COMMAND(ID_CHK_DOUBLE, &CDocOrder::OnChkDouble)
	ON_UPDATE_COMMAND_UI(ID_CHK_DOUBLE, &CDocOrder::OnUpdateChkDouble)
	ON_COMMAND(ID_CHK_TRIBLE, &CDocOrder::OnChkTrible)
	ON_UPDATE_COMMAND_UI(ID_CHK_TRIBLE, &CDocOrder::OnUpdateChkTrible)
	ON_COMMAND(ID_BTN_COLOR_SEPARATE, &CDocOrder::OnBtnColorSeparate)
	ON_UPDATE_COMMAND_UI(ID_BTN_COLOR_SEPARATE, &CDocOrder::OnUpdateBtnColorSeparate)
	ON_UPDATE_COMMAND_UI(ID_BTN_FIND_FAST, &CDocOrder::OnUpdateBtnFindFast)
	ON_COMMAND(ID_BTN_FIND_FAST, &CDocOrder::OnBtnFindFast)
	ON_COMMAND(ID_CHK_MONO, &CDocOrder::OnChkMono)
	ON_UPDATE_COMMAND_UI(ID_CHK_MONO, &CDocOrder::OnUpdateChkMono)
	ON_COMMAND(ID_SLD_COLOR_1_SEPARATION, &CDocOrder::OnSldColor1Separation)
	ON_UPDATE_COMMAND_UI(ID_SLD_COLOR_1_SEPARATION, &CDocOrder::OnUpdateSldColor1Separation)

	//------------------------------------------------begin yangfan 2016_4_21
	ON_COMMAND(ID_BTN_DBORDER_INSERT,&CDocOrder::OnBtnDborderInsert)
	ON_UPDATE_COMMAND_UI(ID_BTN_DBORDER_INSERT,&CDocOrder::OnUpdateBtnDborderInsert)
	ON_COMMAND(ID_BTN_ORDER_QUERY, &CDocOrder::OnBtnOrderQuery)
	ON_UPDATE_COMMAND_UI(ID_BTN_ORDER_QUERY, &CDocOrder::OnUpdateBtnOrderQuery)
	//ON_COMMAND(ID_BTN_NEWCUSTOMER, &CDocOrder::OnBtnNewcustomer)
	//ON_UPDATE_COMMAND_UI(ID_BTN_NEWCUSTOMER, &CDocOrder::OnUpdateBtnNewcustomer)
	ON_COMMAND(ID_DB_ORDER_LAST, &CDocOrder::OnDbOrderLast)
	ON_COMMAND(ID_DB_ORDER_FIRST, &CDocOrder::OnDbOrderFirst)
	ON_COMMAND(ID_DB_ORDER_PREV, &CDocOrder::OnDbOrderPrev)
	ON_COMMAND(ID_DB_ORDER_NEXT, &CDocOrder::OnDbOrderNext)
	//------------------------------------------------end   yangfan 2016_4_21
	ON_UPDATE_COMMAND_UI(ID_DB_ORDER_FIRST, &CDocOrder::OnUpdateDbOrderFirst)
	ON_UPDATE_COMMAND_UI(ID_DB_ORDER_LAST, &CDocOrder::OnUpdateDbOrderLast)
	ON_UPDATE_COMMAND_UI(ID_DB_ORDER_PREV, &CDocOrder::OnUpdateDbOrderPrev)
	ON_UPDATE_COMMAND_UI(ID_DB_ORDER_NEXT, &CDocOrder::OnUpdateDbOrderNext)
	//-------------------------------begin yangfan 2016_7_14
	ON_COMMAND(ID_BTN_INLIB, &CDocOrder::OnBtnInlib)
	ON_UPDATE_COMMAND_UI(ID_BTN_INLIB, &CDocOrder::OnUpdateBtnInlib)
	ON_COMMAND(ID_BTN_FASTSEARCH, &CDocOrder::OnBtnFastsearch)
	ON_UPDATE_COMMAND_UI(ID_BTN_FASTSEARCH, &CDocOrder::OnUpdateBtnFastsearch)
	//-------------------------------begin yangfan 2016_7_14
	
END_MESSAGE_MAP()


// CDocOrder ����/����
void CDocOrder::generateHeaders ( )
{
	int		i;
	DWORD	dwHeaderSize;
	char*	pBuffer;

	ASSERT ( m_lHeight );
	ASSERT ( m_lWidth );

	m_dwWidthBytes	= ((m_lWidth + 3) >> 2) << 2;
	m_dwBitBytes	= m_dwWidthBytes * (DWORD)m_lHeight;

	dwHeaderSize	= sizeof( BITMAPINFOHEADER ) + (sizeof( RGBQUAD ) << 8);
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_1	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_2	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_3	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiGray		= (LPBITMAPINFO) pBuffer;

	m_lpbiImage_1->bmiHeader.biSize			= sizeof( BITMAPINFOHEADER );
	m_lpbiImage_1->bmiHeader.biWidth		= m_lWidth;
	m_lpbiImage_1->bmiHeader.biHeight		= m_lHeight;
	m_lpbiImage_1->bmiHeader.biPlanes		= 1;
	m_lpbiImage_1->bmiHeader.biBitCount		= 8;
	m_lpbiImage_1->bmiHeader.biSizeImage	= m_dwBitBytes;
	m_lpbiImage_1->bmiHeader.biCompression	= BI_RGB;
	m_lpbiImage_1->bmiHeader.biXPelsPerMeter= 0;
	m_lpbiImage_1->bmiHeader.biYPelsPerMeter= 0;
	m_lpbiImage_1->bmiHeader.biClrUsed		= 256;
	m_lpbiImage_1->bmiHeader.biClrImportant	= 0;

	memcpy ( m_lpbiImage_2, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );
	memcpy ( m_lpbiImage_3, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );
	memcpy ( m_lpbiGray, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );

	for ( i=0; i<256; i++ )
	{
		m_lpbiImage_1->bmiColors[i].rgbBlue		= 0;
		m_lpbiImage_1->bmiColors[i].rgbGreen	= 0;
		m_lpbiImage_1->bmiColors[i].rgbRed		= i;
		m_lpbiImage_1->bmiColors[i].rgbReserved	= 0;

		m_lpbiImage_2->bmiColors[i].rgbBlue		= 0;
		m_lpbiImage_2->bmiColors[i].rgbGreen	= i;
		m_lpbiImage_2->bmiColors[i].rgbRed		= 0;
		m_lpbiImage_2->bmiColors[i].rgbReserved	= 0;

		m_lpbiImage_3->bmiColors[i].rgbBlue		= i;
		m_lpbiImage_3->bmiColors[i].rgbGreen	= 0;
		m_lpbiImage_3->bmiColors[i].rgbRed		= 0;
		m_lpbiImage_3->bmiColors[i].rgbReserved	= 0;

		m_lpbiGray->bmiColors[i].rgbBlue		= i;
		m_lpbiGray->bmiColors[i].rgbGreen		= i;
		m_lpbiGray->bmiColors[i].rgbRed			= i;
		m_lpbiGray->bmiColors[i].rgbReserved	= 0;

		m_rgbColor_1[i].rgbBlue		= i;
		m_rgbColor_1[i].rgbGreen	= i;
		m_rgbColor_1[i].rgbRed		= i;
		m_rgbColor_1[i].rgbReserved	= 0;

		m_rgbColor_2[i].rgbBlue		= i;
		m_rgbColor_2[i].rgbGreen	= i;
		m_rgbColor_2[i].rgbRed		= i;
		m_rgbColor_2[i].rgbReserved	= 0;

		m_rgbColor_3[i].rgbBlue		= i;
		m_rgbColor_3[i].rgbGreen	= i;
		m_rgbColor_3[i].rgbRed		= i;
		m_rgbColor_3[i].rgbReserved	= 0;

		m_rgbGray[i].rgbBlue		= i;
		m_rgbGray[i].rgbGreen		= i;
		m_rgbGray[i].rgbRed			= i;
		m_rgbGray[i].rgbReserved	= 0;
	}
}

CDocOrder::CDocOrder()
{
	//--------------------------------------------begin yangfan 2016_7_15
	FileCount = 0;
	readPath = "F:\\Project\\JPGLIB";
	m_pictureCount = 0;
	m_pthreadTexture = new CTexture;
	m_pthreadFeature = NULL;
	m_pFastSearImg = NULL;
	//--------------------------------------------end   yangfan 2016_7_15

	//--------------------------begin yangfan 2016_7_13
	m_pTexture = new CTexture;
	m_pFeature = NULL;
	//--------------------------end   yangfan 2016_7_13

	//--------------------------begin yangfan 2016_7_14
	m_bTestCalcu = false;
	//--------------------------end   yangfan 2016_7_14

	//--------------------------begin yangfan 2016_6_13
	m_pCurImage  = new Image;
	m_pLastImage = new Image;
	//--------------------------end   yangfan 2016_6_13

	//--------------------------begin yangfan 2016_4_29
	updateNewCustomer = true;
	m_nNumberIndent = 0;
	m_nCurrentIndent = 0;
	//--------------------------begin yangfan 2016_4_29
	Query_DocOrder = true;
	//--------------------------end   yangfan 2016_5_13

	//--------------------------end yangfan 2016_4_29

	m_pImage	= NULL;

	m_pImageDisplay	= NULL;

	m_iDisplay	= 0;

	m_lpbiImage_1	= NULL;
	m_lpbiImage_2	= NULL;
	m_lpbiImage_3	= NULL;
	m_lpbiGray		= NULL;

	m_pImage_1	= NULL;
	m_pImage_2	= NULL;
	m_pImage_3	= NULL;
	m_pGray		= NULL;

	m_lHeight	= 0;
	m_lWidth	= 0;

	m_bNewDoc	= false;
	m_bQuery	= false;

	m_iColors	= 1;

	m_nCurrent	= 0;
	m_nNumRes	= 0;

	m_iIndex	= -1;

	m_pResult	= NULL;

	feature_result	= NULL;
	match_result	= NULL;

	m_bDoneCalculating	= true;
	m_bCalculating		= false;

	m_fThreshold	= .1f;
}

CDocOrder::~CDocOrder()
{
	//--------------------------begin yangfan 2016_7_15
	if (m_pthreadTexture)
		delete m_pthreadTexture;
	//delete pFeature;
	LPTEXTURE_FEATURE	pthreadNext;

	while (m_pthreadFeature)
	{
		pthreadNext = m_pthreadFeature->pNext;

		delete	m_pthreadFeature;

		m_pthreadFeature = pthreadNext;
	}

	if (m_pFastSearImg)
		delete m_pFastSearImg;
	//--------------------------end   yangfan 2016_7_15


	//--------------------------begin yangfan 2016_7_13
	if(m_pTexture)
		delete m_pTexture;
	//delete pFeature;
	LPTEXTURE_FEATURE	pNext;

	while (m_pFeature)
	{
		pNext = m_pFeature->pNext;

		delete	m_pFeature;

		m_pFeature = pNext;
	}
	//--------------------------end   yangfan 2016_7_13


	int		i, iSize;

	if ( m_lpbiImage_1 )
		delete	m_lpbiImage_1;

	if ( m_lpbiImage_2 )
		delete	m_lpbiImage_2;

	if ( m_lpbiImage_3 )
		delete	m_lpbiImage_3;

	if ( m_lpbiGray )
		delete	m_lpbiGray;

	if ( m_pImage )
		delete	m_pImage;

	if ( m_pImage_1 )
		delete	m_pImage_1;

	if ( m_pImage_2 )
		delete	m_pImage_2;

	if ( m_pImage_3 )
		delete	m_pImage_3;

	if ( m_pGray )
		delete	m_pGray;

	//if ( m_pBmp_1 )
	//	delete	m_pBmp_1;

	//if ( m_pBmp_2 )
	//	delete	m_pBmp_2;

	//if ( m_pBmp_3 )
	//	delete	m_pBmp_3;

	if ( m_pResult )
		mysql_free_result ( m_pResult );

	if ( feature_result)
		delete	feature_result;

	iSize	= (int)m_Result.size();
	for ( i=0; i<iSize; i++ )
		delete m_Result[i];



}

BOOL CDocOrder::OnNewDocument()
{
	m_bNewDoc	= true;

	if (!CDocument::OnNewDocument())
		return FALSE;

	// surf the database

	return TRUE;
}




// CDocOrder ���л�

void CDocOrder::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: �ڴ����Ӵ洢����
	}
	else
	{
		// TODO: �ڴ����Ӽ��ش���
	}
}

#ifdef SHARED_HANDLERS

// ����ͼ��֧��
void CDocOrder::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// �޸Ĵ˴����Ի����ĵ�����
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// �������������֧��
void CDocOrder::InitializeSearchContent()
{
	CString strSearchContent;
	// ���ĵ����������������ݡ�
	// ���ݲ���Ӧ�ɡ�;���ָ�

	// ����:  strSearchContent = _T("point;rectangle;circle;ole object;")��
	SetSearchContent(strSearchContent);
}

void CDocOrder::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CDocOrder ���

#ifdef _DEBUG
void CDocOrder::AssertValid() const
{
	CDocument::AssertValid();
}

void CDocOrder::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CDocOrder ����


BOOL CDocOrder::OnOpenDocument(LPCTSTR lpszPathName)
{
//	if (!CDocument::OnOpenDocument(lpszPathName))
//		return FALSE;

	m_pImage	= new CImage;

	m_pImage->Load ( lpszPathName );

	//-------------------------------------begin yangfan 2016_7_15
	//for fast searching
	m_pFastSearImg = new CImage;
	m_pFastSearImg->Load(lpszPathName);
	//-------------------------------------end   yangfan 2016_7_15

	m_lHeight	= m_pImage->GetHeight ( );
	m_lWidth	= m_pImage->GetWidth ( );

	m_pImageDisplay	= m_pImage;

	generateHeaders ( );
	m_bDoneCalculating	= false;	// header ready, do calculating

	m_strPath	= lpszPathName;

	CFile	file;

	file.Open ( lpszPathName, CFile::modeRead );

	m_iLength	= (int)file.GetLength ( );

	file.Close ( );

	return TRUE;
}

void CDocOrder::SetTitle(LPCTSTR lpszTitle)
{
	CString	 strTitle ( lpszTitle );

	if ( 0 == strTitle.Left(6).Compare(_T("��������ļ�")) )
	{
		CDocument::SetTitle ( _T("��������") );
		return;
	}

	CDocument::SetTitle(lpszTitle);
}

void CDocOrder::loadRollFile ( IStream* pStream )
{
	CImage*		pImage;
	CImage*		pImageOld;

	pImage	= new CImage;

	pImage->Load ( pStream );

	pImageOld	= m_pImage;
	m_pImage	= pImage;

	UpdateAllViews ( NULL );

	if ( pImageOld )
		delete	pImageOld;

	refreshProperty ( );
}

void CDocOrder::loadRollFile ( LPCTSTR lpszPathName )
{
	CImage*		pImage;
	CImage*		pImageOld;

	pImage	= new CImage;

	pImage->Load ( m_strPath );

	CFile	file;

	file.Open ( m_strPath, CFile::modeRead );

	m_iLength	= (int)file.GetLength ( );

	file.Close ( );

	pImageOld	= m_pImage;
	m_pImage	= pImage;

	UpdateAllViews ( NULL );

	if ( pImageOld )
		delete	pImageOld;

	refreshProperty ( );
}


void CDocOrder::outputString ( CString strMsg, int iKind/* =0 */ )
{
	CMainFrame*	pMain;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	pMain->outputString ( strMsg, iKind );
}

void CDocOrder::refreshProperty ( )
{
	CMainFrame*	pMain;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	//--------------------------------------------begin yangfan 2016_5_11,����
//	pMain->refreshProperty ( this );
	pMain->refreshProperty ( this );
	//--------------------------------------------end   yangfan 2016_5_11
}

void CDocOrder::OnChkMono()
{
	m_iColors	= 1;
}

void CDocOrder::OnChkDouble()
{
	m_iColors	= 2;
}

void CDocOrder::OnUpdateChkMono(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck ( m_iColors == 1 );
}


void CDocOrder::OnUpdateChkDouble(CCmdUI *pCmdUI)
{
	//pCmdUI->Enable ( !m_bNewDoc );

	//if ( !m_bNewDoc )
		pCmdUI->SetCheck ( m_iColors == 2 );
}


void CDocOrder::OnChkTrible()
{
	m_iColors	= 3;
}


void CDocOrder::OnUpdateChkTrible(CCmdUI *pCmdUI)
{
	//pCmdUI->Enable ( !m_bNewDoc );

	//if ( !m_bNewDoc )
	//	pCmdUI->SetCheck ( !m_bDouble );
	
	pCmdUI->SetCheck ( m_iColors == 3 );
}

CImage* CDocOrder::getSeparated_1 ( )
{
	return	m_pImage_1;
}

CImage* CDocOrder::getSeparated_2 ( )
{
	return	m_pImage_2;
}

CImage* CDocOrder::getSeparated_3 ( )
{
	return	m_pImage_3;
}

CImage* CDocOrder::extractImage_1 ( CImage* pImageSrc, CDC* pDC )
{
	CImage*	pImage	= NULL;

	return	pImage;
}

void CDocOrder::OnBtnColorSeparate()
{
	if ( 1 == m_iColors )
		createMono ( );

	if ( 2 == m_iColors )
		createDouble ( );

	if ( 3 == m_iColors )
		createTrible ( );
}

void CDocOrder::createMono ( )
{
	CDC			memDC;
	HDC			hDC;
	CDC*		pDC;
	HBITMAP		hBitmap, hOld;
	CMainFrame*	pMain;
	LPBYTE		ppvBits;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
//	pMain->refreshProperty ( this );

	hDC	= m_pImage->GetDC ( );
	pDC	= CDC::FromHandle ( hDC );

	memDC.DeleteDC ( );
	memDC.CreateCompatibleDC ( pDC );

	// m_pImage_1
	hBitmap	= CreateDIBSection ( hDC, m_lpbiGray, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_1 )
		delete	m_pImage_1;

	m_pImage_1	= new CImage;
	m_pImage_1->Attach ( hBitmap );
	m_pImage_1->SetColorTable ( 0, 256, m_rgbColor_1 );

	// m_pImage_2
	if ( m_pImage_2 )
		delete	m_pImage_2;
	m_pImage_2	= NULL;
	// m_pImage_3
	if ( m_pImage_3 )
		delete	m_pImage_3;
	m_pImage_3	= NULL;

	m_pImage->ReleaseDC ( );

	calculateFeatures ( );

	pMain->refreshSeparatedColors ( this );
}

void CDocOrder::createDouble ( )
{
}

void CDocOrder::createTrible ( )
{
	CDC			memDC;
	HDC			hDC;
	CDC*		pDC;
	HBITMAP		hBitmap, hOld;
	CMainFrame*	pMain;
	LPBYTE		ppvBits;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
//	pMain->refreshProperty ( this );

	hDC	= m_pImage->GetDC ( );
	pDC	= CDC::FromHandle ( hDC );

	memDC.DeleteDC ( );
	memDC.CreateCompatibleDC ( pDC );

	// m_pImage_1
	hBitmap	= CreateDIBSection ( hDC, m_lpbiImage_1, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_1 )
		delete	m_pImage_1;

	m_pImage_1	= new CImage;
	m_pImage_1->Attach ( hBitmap );
	m_pImage_1->SetColorTable ( 0, 256, m_rgbColor_1 );

	// m_pImage_2
	hBitmap	= CreateDIBSection ( hDC, m_lpbiImage_2, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_2 )
		delete	m_pImage_2;

	m_pImage_2	= new CImage;
	m_pImage_2->Attach ( hBitmap );
	m_pImage_2->SetColorTable ( 0, 256, m_rgbColor_2 );

	// m_pImage_3
	hBitmap	= CreateDIBSection ( hDC, m_lpbiImage_3, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_3 )
		delete	m_pImage_3;

	m_pImage_3	= new CImage;
	m_pImage_3->Attach ( hBitmap );
	m_pImage_3->SetColorTable ( 0, 256, m_rgbColor_3 );


	m_pImage->ReleaseDC ( );

	calculateFeatures ( );

	pMain->refreshSeparatedColors ( this );
}

void CDocOrder::OnUpdateBtnColorSeparate(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( !m_bNewDoc );
}

void CDocOrder::calculateFeatures ( )
{
	CDC			memDC;
	HDC			hDC;
	CDC*		pDC;
	HBITMAP		hBitmap, hOld;
	LPBYTE		ppvBits;

	if ( m_bDoneCalculating )
	{
		Sleep ( 20 );
		return;
	}

	if ( m_bCalculating )
	{
		Sleep ( 20 );
		return;
	}

	m_bCalculating	= true;

	hDC	= m_pImage->GetDC ( );
	pDC	= CDC::FromHandle ( hDC );

	memDC.DeleteDC ( );
	memDC.CreateCompatibleDC ( pDC );

	// m_pGray
	hBitmap	= CreateDIBSection ( hDC, m_lpbiGray, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pGray )
		delete	m_pGray;

	m_pGray	= new CImage;
	m_pGray->Attach ( hBitmap );

	m_pImage->ReleaseDC ( );
	//-----------------------------------begin yangfan 2016_7_13
	// it seems that we don't need to calculate features when separate the color,so block
	/*
	CCompute	main_compute;

	main_compute.openImage ( m_pGray, ppvBits );

	feature_result	= main_compute.ComputeFeature ( );
	*/
	m_pFeature = m_pTexture->computingFeatures(m_pGray);
	//-----------------------------------end yangfan 2016_7_13

	m_bDoneCalculating	= true;	// all has been calculated
	m_bCalculating		= false;
}

void CDocOrder::setDisplay ( int iDisplay )
{
	m_iDisplay	= iDisplay;

	switch ( iDisplay )
	{
	case 1:
		m_pImageDisplay	= m_pImage_1;
		break;

	case 2:
		m_pImageDisplay	= m_pImage_2;
		break;

	case 3:
		m_pImageDisplay	= m_pImage_3;
		break;

	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 17:
		iDisplay	-= 10;
		if ( iDisplay < m_iCnt_matchRoll )
			m_pImageDisplay	= match_roll->at ( iDisplay )->mpImage;
		break;

	default:
		m_pImageDisplay	= m_pImage;
		break;
	}

	UpdateAllViews ( NULL );
}

void CDocOrder::OnUpdateBtnFindFast(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( (m_iDisplay>0/*֮ǰ��>0��2016_4_27����=*/) && (m_iDisplay<4) );
}


void CDocOrder::OnBtnFindFast()
{
	CMainFrame*	pMain;

	// �Ե�ǰ��ɫͼƬ���а��ƥ��
	ASSERT ( (0<m_iDisplay) & (m_iDisplay<4) );

	doRollMatching ( m_pImageDisplay );
	
	// ƥ�����, ���½���
	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	pMain->refreshRollMatches ( this );
}

void CDocOrder::doRollMatching ( CImage* pImage )
{
	CDC			memDC;
	HDC			hDC;
	CDC*		pDC;
	HBITMAP		hBitmap, hOld;
	LPBYTE		ppvBits;
	CImage*		pGray;

	// get the bits
	hDC	= pImage->GetDC ( );
	pDC	= CDC::FromHandle ( hDC );

	memDC.DeleteDC ( );
	memDC.CreateCompatibleDC ( pDC );

	// m_pGray
	hBitmap	= CreateDIBSection ( hDC, m_lpbiGray, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	pGray	= new CImage;
	pGray->Attach ( hBitmap );

	pImage->ReleaseDC ( );


	//==============================************************************************************
	//-----------------------------------begin yangfan 2016_7_13
	/*
	// calculating features of pImage
	CCompute		main_compute;

	main_compute.openImage ( m_pGray, ppvBits );

	feature_result	= main_compute.ComputeFeature ( );

	// search database to find out the candidates
//	match_result	= findInDB ( feature_result, m_fThreshold );
	
	//match_roll	= Works::QueryRollLibInfo ( *feature_result, m_fThreshold );
	*/
	int test = 0;
	feature_result = NULL;

	m_pFeature = m_pTexture->computingFeatures(pImage);
	match_roll = Works::QueryRollLibInfo(m_pFeature, m_fThreshold);

	//-----------------------------------end yangfan 2016_7_13


	delete	pGray;

//	if ( NULL == match_result )
	if ( NULL == match_roll )
	{
		m_iCnt_matchRoll	= -1;

		return;
	}

	// load the first 8 candidates
//	int		i, iSize;

//	m_iCnt_matchRoll	= (int)match_result->size();
	m_iCnt_matchRoll	= (int)match_roll->size();

	if ( m_iCnt_matchRoll > 8 )
		m_iCnt_matchRoll	= 8;
}

vector<CImage*>* CDocOrder::findInDB ( vector<double>* features, float fThreshold )
{
	return	Works::QueryImage ( *features );
}



void CDocOrder::OnSldColor1Separation()
{
	CMainFrame*			pMain;
	CMFCRibbonSlider*	pSlider;
	int					iPos;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );

	pSlider	= DYNAMIC_DOWNCAST( CMFCRibbonSlider, pMain->m_wndRibbonBar.FindByID ( ID_SLD_COLOR_1_SEPARATION ) );

	iPos	= pSlider->GetPos ( );

	m_fThreshold	= (100.f - iPos) / 100.f;

	if ( m_fThreshold > 99.9f )
	{
		m_fThreshold	= 99.9f;
	}
}


void CDocOrder::OnUpdateSldColor1Separation(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( TRUE );
}

//---------------------------------------------------------begin yangfan 2016_4_25
void CDocOrder::OnBtnDborderInsert()
{
	// TODO: �ڴ�����������������
	CString strMsg;
	//----------------------
	// pop out a warning
	if ( IDYES != MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
		_T("��ǰ�İ��ɨ��ͼ�������浽���ݿ���\r\n������?"),
		_T("ȷ��"),	MB_ICONINFORMATION | MB_YESNOCANCEL) )
	{
		return;
	}
	//--------------------
	LPDB_MYSQL pDB;
	pDB = CDBmySQL::getDB();
	
	map<string,string>::iterator iterIndent;
	//filePath�洢��picIndent����
	//string strValueInd[5] = {"10001","����ʱ��","�������",CString2str(m_strPath),"0.1"};//"�洢·��"
	string strValueInd[4] = {"10001","����ʱ��","�������","0.1"};
	for(iterIndent=mapDocOrder_Indent.begin();iterIndent!=mapDocOrder_Indent.end();++iterIndent)
	{
		string strItem = iterIndent->first;
		if(strItem=="�ͻ����̱��")
		{
			strValueInd[0] = iterIndent->second;
		}
		if(strItem=="����ʱ��")
		{
			strValueInd[1] = iterIndent->second;
		}
		if(strItem=="�������")
		{
			strValueInd[2] = iterIndent->second;
		}
		//if(strItem=="�洢·��")
		//{
			//strValueInd[3] = iterIndent->second;
		//}
		if(strItem=="��ֵ")
		{
			strValueInd[3] = iterIndent->second;
		}	
	}
	indent_yf* pIndent;
	pIndent = new indent_yf(strValueInd[0].c_str(),strValueInd[1].c_str(),strValueInd[2].c_str()/*,strValueInd[3].c_str()*/,strValueInd[3].c_str());
	pIndent->save();
	//================================================infoCustom���Ĳ���
	//infoCustom* pInfoCustom;
	//pInfoCustom = new infoCustom( strValueCus[0],strValueCus[1],strValueCus[2] );
	//pInfoCustom->Save();
	//================================================edgeSheet���Ĳ���
	//map<string,string>::iterator iterEdgeSheet;
	//string strValueEdgeSheet = "�洢·��";
	//for(iterEdgeSheet=mapDocOrder_EdgeSheet.begin();iterEdgeSheet!=mapDocOrder_EdgeSheet.end();++iterEdgeSheet)
	//{
		//strValueEdgeSheet = iterEdgeSheet->second;
	//}
	//edgeSheet* pEdgeSheet;
	//pEdgeSheet = new edgeSheet(strValueEdgeSheet.c_str(),0,0,pInfoCustom->getId());
	//pEdgeSheet->Save();
	//================================================manager���Ĳ���
	picIndent* pPicIndent;
	pPicIndent = new picIndent(CString2str(m_strPath),pIndent->getId());
	pPicIndent->Save();
	strMsg.Format( _T("�������в����¼�¼��������: %d"), pIndent->getId() );
	outputString ( strMsg );
	CMainFrame*	pMain;
	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	pMain->switch2DocOrderView ( TRUE );

	CDocument::OnCloseDocument ( );

	//--------------------------begin yangfan 2016_5_13
	//Query_DocOrder = true;
	//--------------------------end   yangfan 2016_5_13
}
//---------------------------------------------------------end yangfan 2016_4_25


//---------------------------------------------------------begin yangfan 2016_4_21
void CDocOrder::OnUpdateBtnDborderInsert(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	pCmdUI->Enable( !m_bNewDoc & !m_bQuery );//(m_iDisplay>0) && (m_iDisplay<4) );
}
//---------------------------------------------------------end  yangfan 2016_4_21


//---------------------------------------------------------begin yangfan 2016_4_23
void CDocOrder::initializePropertyData()
{
	CMainFrame*				pMain;
	pMain	= (CMainFrame*) AfxGetMainWnd ( );

	//updateNewCustomer = true;

	//LPPROPERTY_DATA_ITEM	pItemCustomer;
	//pItemCustomer	= m_dataProperty.addItem (  _T("�û���Ϣ") );
	//m_pItem_CustomerName   =  pItemCustomer->addSubItem ( _T("�û�����"), _T("����"), _T("�༭����") );
	//m_pItem_CustomerTel    =  pItemCustomer->addSubItem(_T("�û��绰"), _T("�绰"), _T("�༭�绰"));
	//m_pItem_CustomerIDCard =  pItemCustomer->addSubItem(_T("�û�����֤��"), _T("����֤��"), _T("�༭����֤��"));
	//m_pItem_CustomerName->m_pFP_infoRoll = NULL;
	//m_pItem_CustomerName->m_pFP_picRoll  = NULL;

	LPPROPERTY_DATA_ITEM   pItemCustomer;
	pItemCustomer =  m_dataProperty.addItem (  _T("�ͻ����̱��") );
	m_pItem_CustomerNumber = pItemCustomer->addSubItem ( _T("�ͻ����̱��"), _T("10001"), _T("�༭�ͻ����̱��") );

	//CMFCPropertyGridPropertyEx* pGroup1 = new CMFCPropertyGridPropertyEx(_T("ʱ��"));
	//CMFCPropertyGridProperty* pProp = new CMFCPropertyGridProperty(_T("ѹ����"), _T("��۴�С"), _T("����֮һ:��ϸ�������С�����������δ���ࡱ"));
	//pProp->AddOption(_T("��"));
	//pProp->AddOption(_T("ϸ"));
	//pProp->AddOption(_T("��"));
	//pProp->AddOption(_T("δ����"));
	//pProp->AllowEdit(FALSE);
	//pGroup1->AddSubItem(pProp);

	LPPROPERTY_DATA_ITEM   pItemIndent_time;
	pItemIndent_time = m_dataProperty.addItem (  _T("����ʱ��") );
	m_pItem_time_indent = pItemIndent_time->addSubItem ( _T("����ʱ��"), _T("00:00 1970/1/1"), _T("�༭ʱ��") );
	LPPROPERTY_DATA_ITEM   pItemIndent_number;
	pItemIndent_number =  m_dataProperty.addItem (  _T("�������") );
	m_pItem_number_indent = pItemIndent_number->addSubItem ( _T("�������"), _T("0"), _T("�༭���") );
	
	//LPPROPERTY_DATA_ITEM   pItemthreshold;
	//pItemthreshold = m_dataProperty.addItem (  _T("��ֵ") );
	//m_pItem_threshold =  pItemthreshold->addSubItem(_T("��ֵ"), _T("0.1"), _T("�༭��ֵ"));

	LPPROPERTY_DATA_ITEM   pItemThreshold;
	pItemThreshold = m_dataProperty.addItem (  _T("��ֵ") );
	m_pItem_threshold = pItemThreshold->addSubItem(_T("��ֵ"), _T("0.1"), _T("�༭��ֵ"));


	LPPROPERTY_DATA_ITEM   pItemfilepath;
	pItemfilepath = m_dataProperty.addItem (  _T("�洢·��") );
	m_pItem_filepath = pItemfilepath->addSubItem( _T("�洢·��"),m_strPath, _T("�༭·��")  );

	pMain->initializeProperty ( this );
}

void CDocOrder::updatePropertyData()
{
	//m_pItem_CustomerName->m_pProp->m_pItem = m_pItem_CustomerName;
	//m_pItem_CustomerTel->m_pProp->m_pItem = m_pItem_CustomerTel;
	//m_pItem_CustomerIDCard->m_pProp->m_pItem = m_pItem_CustomerIDCard;
	m_pItem_CustomerNumber->m_pProp->m_pItem = m_pItem_CustomerNumber;
	m_pItem_filepath->m_pProp->m_pItem = m_pItem_filepath;
	m_pItem_number_indent->m_pProp->m_pItem = m_pItem_number_indent;
	m_pItem_time_indent->m_pProp->m_pItem = m_pItem_time_indent;
	m_pItem_threshold->m_pProp->m_pItem = m_pItem_threshold;
}
//---------------------------------------------------------end   yangfan 2016_4_23


//---------------------------------------------------------begin yangfan 2016_4_25
void CDocOrder::onItemChanged(LPPROPERTY_DATA_ITEM pItem, CMFCPropertyGridPropertyEx* pProp)
{
	//MessageBox( AfxGetMainWnd()->GetSafeHwnd(),_T("�޸���DocOrder�½��������Խ�����ֵ!"),_T("��ʾ"),MB_OK);
	COleVariant			varNewValue;
	COleVariant			varOldValue;
	varNewValue	= pProp->GetValue ( );
	varOldValue	= pProp->GetOriginalValue ( );

	USES_CONVERSION;
	string strNewValue = W2A( varNewValue.bstrVal );
	CString DocOrderPropItemName = pProp->m_pItem->m_strName;
	string s = W2A( DocOrderPropItemName );
	mapDocOrder_Indent[s] = strNewValue;
	
}
//---------------------------------------------------------end   yangfan 2016_4_25

//---------------------------------------------------------begin yangfan 2016_4_26
void CDocOrder::OnBtnOrderQuery()
{
	// TODO: �ڴ�����������������
	CString		strMsg_startQuery;
	strMsg_startQuery.Format( _T("���ڲ�ѯ�������ݿ⣬���Ժ�...") );
	outputString ( strMsg_startQuery );

	m_ResultIndent = indent_yf::QueryIndent();
	m_nNumberIndent = (int)m_ResultIndent.size();
	for(int k=0;k<(int)m_ResultPicInd.size();k++)
		delete m_ResultPicInd[k];
	m_ResultPicInd = picIndent::QueryPicIndent();

	CString		strMsg_QueryDone;
	strMsg_QueryDone.Format(_T("�������ѯ��ϣ��ܼ�¼��: %d"),m_nNumberIndent);
	outputString ( strMsg_QueryDone );

	if ( 0 == m_nNumberIndent )
	{
		this->refreshProperty ( );
		return;
	}
	m_nCurrentIndent	= 0;

	m_bQuery	= true;
	updateIndent ( m_ResultIndent.at(m_nCurrentIndent) );
	updatePicInd ( m_ResultPicInd.at(m_nCurrentIndent) );
	loadRollFile ( m_ResultPicInd[m_nCurrentIndent]->GetStream() );
	m_ResultPicInd[m_nCurrentIndent]->FreeData();
}


void CDocOrder::OnUpdateBtnOrderQuery(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	pCmdUI->Enable(m_bNewDoc & !m_bQuery);
}
//---------------------------------------------------------end   yangfan 2016_4_26


//---------------------------------------------------------begin yangfan 2016_5_11
void CDocOrder::updateIndent ( indent_yf* pIndent )
{
	CString	strMsg;
	m_iIndex	= pIndent->id;
	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );
	m_pItem_CustomerNumber->setValue ( (_variant_t)pIndent->manufacturerNumber.c_str() );
	m_pItem_time_indent->setValue ( (_variant_t)pIndent->time.c_str() );
	m_pItem_number_indent->setValue ( (_variant_t)pIndent->indentNumber.c_str() );
	m_pItem_threshold->setValue ( (_variant_t)pIndent->threshold.c_str() );
	refreshProperty ( );
}


void CDocOrder::updatePicInd ( picIndent* pPicInd )
{
	m_pItem_filepath->setValue(  (_variant_t)pPicInd->filePath );
	refreshProperty ( );
}
//---------------------------------------------------------end   yangfan 2016_5_11

/*
//---------------------------------------------------------begin yangfan 2016_4_28
void CDocOrder::OnBtnNewcustomer()
{
	// TODO: �ڴ�����������������
	CNewCustomer DlgNewCus;
	if ( IDOK != DlgNewCus.DoModal() )
		return;
	//MessageBox(AfxGetMainWnd()->GetSafeHwnd(),_T("�½��ͻ��ɹ���"),_T("��ʾ"),MB_OK);
	//MessageBox(AfxGetMainWnd()->GetSafeHwnd(),_T("�����ȷ����ť!"),_T("��ʾ"),MB_OK);
}
//---------------------------------------------------------end   yangfan 2016_4_28

//---------------------------------------------------------begin yangfan 2016_4_28
void CDocOrder::OnUpdateBtnNewcustomer(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	pCmdUI->Enable( !theApp.m_bBusy );
}
//---------------------------------------------------------end   yangfan 2016_4_28
*/

//---------------------------------------------------------begin yangfan 2016_5_13
void CDocOrder::OnDbOrderLast()
{
	// TODO: �ڴ�����������������
	//MessageBox( AfxGetMainWnd()->GetSafeHwnd(),_T("�����β��¼!"),_T("��ʾ"),MB_OK );

	if ( m_nNumberIndent < 1 )
		return;
	m_nCurrentIndent	= m_nNumberIndent - 1;

	updateIndent ( m_ResultIndent.at(m_nCurrentIndent) );
	updatePicInd ( m_ResultPicInd.at(m_nCurrentIndent) );
	loadRollFile ( m_ResultPicInd[m_nCurrentIndent]->GetStream() );
	m_ResultPicInd[m_nCurrentIndent]->FreeData();

}

void CDocOrder::OnDbOrderFirst()
{
	// TODO: �ڴ�����������������
	//MessageBox( AfxGetMainWnd()->GetSafeHwnd(),_T("������׼�¼!"),_T("��ʾ"),MB_OK );

	if ( m_nNumberIndent < 1 )
		return;
	m_nCurrentIndent  =  0;

	updateIndent ( m_ResultIndent.at(m_nCurrentIndent) );
	updatePicInd ( m_ResultPicInd.at(m_nCurrentIndent) );
	loadRollFile ( m_ResultPicInd[m_nCurrentIndent]->GetStream() );
	m_ResultPicInd[m_nCurrentIndent]->FreeData();

}

void CDocOrder::OnDbOrderPrev()
{
	// TODO: �ڴ�����������������
	//MessageBox( AfxGetMainWnd()->GetSafeHwnd(),_T("�������һ��!"),_T("��ʾ"),MB_OK );

	if ( m_nCurrentIndent > 0 )
		--m_nCurrentIndent;
	else 
		return;

	updateIndent ( m_ResultIndent.at(m_nCurrentIndent) );
	updatePicInd ( m_ResultPicInd.at(m_nCurrentIndent) );
	loadRollFile ( m_ResultPicInd[m_nCurrentIndent]->GetStream() );
	m_ResultPicInd[m_nCurrentIndent]->FreeData();
}

void CDocOrder::OnDbOrderNext()
{
	// TODO: �ڴ�����������������
	//MessageBox( AfxGetMainWnd()->GetSafeHwnd(),_T("�������һ��!"),_T("��ʾ"),MB_OK );

	if (m_nCurrentIndent >= m_nNumberIndent - 1 )
		return;
	m_nCurrentIndent++;

	updateIndent ( m_ResultIndent.at(m_nCurrentIndent) );
	updatePicInd ( m_ResultPicInd.at(m_nCurrentIndent) );
	loadRollFile ( m_ResultPicInd[m_nCurrentIndent]->GetStream() );
	m_ResultPicInd[m_nCurrentIndent]->FreeData();
}
//---------------------------------------------------------end   yangfan 2016_5_13


//---------------------------------------------------------begin yangfan 2016_5_25
void CDocOrder::OnUpdateDbOrderFirst(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	pCmdUI->Enable( m_bNewDoc & m_bQuery & (m_nCurrentIndent>0) );
}


void CDocOrder::OnUpdateDbOrderLast(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	pCmdUI->Enable( m_bNewDoc & m_bQuery & (m_nCurrentIndent<m_nNumberIndent-1) );
}

void CDocOrder::OnUpdateDbOrderPrev(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	pCmdUI->Enable( m_bNewDoc & m_bQuery & (m_nCurrentIndent>0) );
}

void CDocOrder::OnUpdateDbOrderNext(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	pCmdUI->Enable( m_bNewDoc & m_bQuery & (m_nCurrentIndent < m_nNumberIndent-1) );
}

//---------------------------------------------------------end  yangfan 2016_5_25

//--------------------------------------begin yangfan 2016_7_15
DWORD __stdcall CDocOrder::threadTextureIntoLib(LPVOID lpVoid)
{
	CDocOrder*	pThis;
	pThis = (CDocOrder*)lpVoid;

	
	list<CString>::iterator it_str = (pThis->picturePath).begin();

	while (pThis->m_pictureCount>0 && it_str != (pThis->picturePath).end())
	{
		//for (; it_str != (pThis->picturePath).end(); ++it_str)
		//{
		CImage* pImage = new CImage;
		pImage->Load(*it_str);

		pThis->m_pthreadFeature = (pThis->m_pthreadTexture)->computingFeatures(pImage);
		//������ֵ�������ݿ��Texture��
		Texture* pTexture = new Texture(pThis->m_pthreadFeature->fEnergy, pThis->m_pthreadFeature->fEntropy,
				pThis->m_pthreadFeature->fInertiaQuadrature, pThis->m_pthreadFeature->fLocalCalm, pThis->m_pthreadFeature->fCorrelation);
		pTexture->save();

		delete pTexture;
		delete pImage;
		it_str++;
		(pThis->m_pictureCount)--;
		//}
	}
	
	pThis->m_hThreadCalculating = NULL;

	return	625;
}



//��ȡָ��Ŀ¼�µ��ļ����ļ�����
void CDocOrder::getAllFiles(string path, vector<string>& files)
{
	//�ļ����  
	//long   hFile = 0;
	intptr_t  hFile = 0;

	//�ļ���Ϣ  
	struct _finddata_t fileinfo;
	string p;

	if ((hFile = _findfirst(p.assign(path).append("\\*").c_str(), &fileinfo)) != -1)
	{
		while (_findnext(hFile, &fileinfo) == 0)
		{
			if (fileinfo.attrib &  _A_SUBDIR)
			{
				if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
				{
					files.push_back(p.assign(path).append("\\").append(fileinfo.name));
					getAllFiles(p.assign(path).append("\\").append(fileinfo.name), files);
				}
			}
			else
				files.push_back(p.assign(path).append("\\").append(fileinfo.name));
		};
	}
	_findclose(hFile);
}

//--------------------------------------end   yangfan 2016_7_15




//--------------------------------------begin yangfan 2016_7_14
void CDocOrder::OnBtnInlib()
{
	// TODO: �ڴ�����������������
	/*
	calculateFeatures();
	Texture* pTexture = new Texture(m_pFeature->fEnergy, m_pFeature->fEntropy,
		m_pFeature->fInertiaQuadrature, m_pFeature->fLocalCalm, m_pFeature->fCorrelation);
	pTexture->save();

	m_bTestCalcu = true;
	*/

	getAllFiles(readPath, fileList);

	vector<string>::iterator ite_str;
	for (ite_str = fileList.begin(); ite_str != fileList.end(); ite_str++)
	{
		string substring = (*ite_str).substr((*ite_str).length() - 3, (*ite_str).length());
		//��jpg��bmp�ļ������list��
		if (substring == "jpg"|| substring == "bmp")
		{
			string tmp = *ite_str;
			CString cs(tmp.c_str());
			//picturePath.push_back((*ite_str).c_str());
			picturePath.push_back(cs);
			m_pictureCount++;
		}	
	}
	//�����߳�
	m_hThreadCalculating = ::CreateThread(NULL, 0, threadTextureIntoLib, (LPVOID)this, 0, NULL);
	m_bTestCalcu = true;
}

void CDocOrder::OnUpdateBtnInlib(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	pCmdUI->Enable(!m_bQuery && !m_bNewDoc && !m_bTestCalcu);//!m_bQuery
}


void CDocOrder::OnBtnFastsearch()
{
	/*
	// TODO: �ڴ�����������������
	CMainFrame*	pMain;

	// �Ե�ǰ��ɫͼƬ���а��ƥ��
	//ASSERT ( (0<m_iDisplay) & (m_iDisplay<4) );

	doRollMatching ( m_pImage );
	
	// ƥ�����, ���½���
	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	pMain->refreshRollMatches ( this );
	*/

	CTexture* pTex = new CTexture;
	LPTEXTURE_FEATURE pFea;
	pFea = pTex->computingFeatures(m_pFastSearImg);
	vector<Texture*> matchResult = Texture::QueryTexture(pFea, 0.01);
	if (matchResult.size() == 0)
	{
		MessageBox(AfxGetMainWnd()->GetSafeHwnd(), _T("û��ƥ�䵽����"), _T("���ҽ��"), MB_ICONINFORMATION);
			//_T("��ǰ�İ��ɨ��ͼ�������浽���ݿ���\r\n������?"), MB_ICONINFORMATION );
	}
	else
		MessageBox(AfxGetMainWnd()->GetSafeHwnd(), _T("ƥ�䵽����"), _T("���ҽ��"), MB_ICONINFORMATION);
}
 
void CDocOrder::OnUpdateBtnFastsearch(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	pCmdUI->Enable(  !m_bQuery && !m_bNewDoc);
}
//--------------------------------------end  yangfan 2016_7_14
