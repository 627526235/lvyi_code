
#ifndef	_MFC_PROPERTY_GRIDCTRL_EX_H
#define	_MFC_PROPERTY_GRIDCTRL_EX_H

// CMFCPropertyGridCtrlEx

#include "PropertyData.h"

class CRollDoc;
class CMFCPropertyGridPropertyEx;

class CMFCPropertyGridCtrlEx : public CMFCPropertyGridCtrl
{
	DECLARE_DYNAMIC(CMFCPropertyGridCtrlEx)

public:
	CRollDoc*	m_pDoc;

	int AddProperty(CMFCPropertyGridPropertyEx* pProp, BOOL bRedraw = TRUE, BOOL bAdjustLayout = TRUE);

protected:
	LPPROPERTY_DATA		m_pData_initial;
//	LPPROPERTY_DATA		m_pData_display;

	void	bindGrid ( );

public:
	CMFCPropertyGridCtrlEx();
	virtual ~CMFCPropertyGridCtrlEx();

	virtual void	initializeData ( LPPROPERTY_DATA pData_initial );

protected:
	DECLARE_MESSAGE_MAP()

};

#endif
