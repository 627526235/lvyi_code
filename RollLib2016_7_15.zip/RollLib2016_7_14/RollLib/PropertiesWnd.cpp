// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

#include "stdafx.h"

#include <afxdisp.h>

#include "PropertiesWnd.h"
#include "Resource.h"
#include "MainFrm.h"
#include "RollLib.h"

#include "DocRoll.h"
#include "DocRollLib.h"
#include "DocOrder.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// CResourceViewBar

void CPropertiesWnd::initializeProperty ( CDocOrder* pDoc )
{
	m_pDocCurrent	= pDoc;
	//--------------------------------begin yangfan 2016_4_23
	SetPropListFont();

	m_wndPropListOrder.EnableHeaderCtrl(FALSE);
	m_wndPropListOrder.EnableDescriptionArea();
	m_wndPropListOrder.SetVSDotNetLook();
	m_wndPropListOrder.MarkModifiedProperties();
	m_wndPropListOrder.initializeData ( pDoc->getData() );
	//--------------------------------end   yangfan 2016_4_23
}

void CPropertiesWnd::initializeProperty ( CDocRoll* pDoc )
{
	m_pDocCurrent	= pDoc;
	//--------------------------------begin yangfan 2016_4_12
	SetPropListFont();

	m_wndPropListRoll.EnableHeaderCtrl(FALSE);
	m_wndPropListRoll.EnableDescriptionArea();
	m_wndPropListRoll.SetVSDotNetLook();
	m_wndPropListRoll.MarkModifiedProperties();
	m_wndPropListRoll.initializeData ( pDoc->getData() );
	//--------------------------------end   yangfan 2016_4_12
}

void CPropertiesWnd::initializeProperty ( CDocRollLib* pDoc )
{
	//LPPROPERTY_DATA			pRoot_data;
	//LPPROPERTY_DATA_ITEM	pNext, pChild;

	m_pDocCurrent	= pDoc;

	SetPropListFont();

	m_wndPropListLib.EnableHeaderCtrl(FALSE);
	m_wndPropListLib.EnableDescriptionArea();
	m_wndPropListLib.SetVSDotNetLook();
	m_wndPropListLib.MarkModifiedProperties();
	m_wndPropListLib.initializeData ( pDoc->getData() );

	//pRoot_data	= pDoc->getData ( );

	//pNext	= pRoot_data->m_pHeadList;
	//while ( pNext )
	//{
	//	CMFCPropertyGridPropertyEx*	pGroup;

	//	pGroup	= new CMFCPropertyGridPropertyEx ( pNext->m_strName, pNext->m_varValue, pNext->m_strDescr );

	//	m_wndPropListLib.AddProperty ( pGroup );

	//	pNext	= pNext->pNext;
	//}
}

void CPropertiesWnd::updateProperties ( CDocRollLib* pDoc )
{
	if ( NULL== pDoc )
		return;

	m_iStatus	= 1;

	m_pDocCurrent	= pDoc;

	pDoc->updatePropertyData ( );

	m_wndPropListRoll.ShowWindow ( SW_HIDE );
	m_wndPropListOrder.ShowWindow ( SW_HIDE );

	m_wndPropListLib.ShowWindow ( SW_SHOW );

	return;
	m_wndPropListLib.RemoveAll ( );
//	UpdateWindow ( );

	CString	strIndex;
	
	//---------------------------------------------------------------begin yangfan 2016_3_12
	CString picPath;		//Ҫ��ʾ�Ĵ洢λ��
	picPath = pDoc->m_strPath;

	string  creTime, manufac;   //Ҫ��ʾ�Ĳ���ʱ��ͳ���
	CString C_creTime,C_manufac;
	creTime = pDoc->m_createtime;
	C_creTime = creTime.c_str();
	manufac = pDoc->m_manufacturer;
	C_manufac = manufac.c_str();
	//-----------------------------------------------------------------end yangfan 2016_3_12

	strIndex.Format ( _T("��¼�����ţ�%d"), pDoc->m_iIndex );
	CMFCPropertyGridPropertyEx* pGroup0 = new CMFCPropertyGridPropertyEx( strIndex );

//	CMFCPropertyGridProperty* pGroup01	= new CMFCPropertyGridProperty(_T("Lib���"), (_variant_t) _T("������"), _T("���ڴ˱༭������") );
	CMFCPropertyGridProperty* pGroup01	= new CMFCPropertyGridProperty(_T("Lib���"), strIndex, _T("���ڴ˱༭������") );
	pGroup0->AddSubItem( pGroup01 );
	pGroup0->Expand ( );
	m_wndPropListLib.AddProperty ( pGroup0 );

	//-----------------------------------------------------------begin yangfan 2016_3_11
	/*
	CMFCPropertyGridPropertyEx* pGroup1 = new CMFCPropertyGridPropertyEx(_T("ʱ��"));

	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("ѹ����"), (_variant_t) false, _T("ѹ�������")));

	CMFCPropertyGridProperty* pProp = new CMFCPropertyGridProperty(_T("ѹ����"), _T("��۴�С"), _T("����֮һ:��ϸ�������С�����������δ���ࡱ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("ϸ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("δ����"));
	pProp->AllowEdit(FALSE);
	pGroup1->AddSubItem(pProp);

	m_pPropManufacturer	= new CMFCPropertyGridProperty(_T("��������"), (_variant_t) _T("����"), _T("�༭����") );
	pGroup1->AddSubItem( m_pPropManufacturer );
//	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("��������"), (_variant_t) _T("����"), _T("�༭����")));

	m_wndPropListLib.AddProperty(pGroup1);

	CMFCPropertyGridPropertyEx* pSize = new CMFCPropertyGridPropertyEx(_T("ͼ���С"), 0, TRUE);

	pProp = new CMFCPropertyGridProperty(_T("�߶�"), (_variant_t) 250l, _T("ָ��ͼ��ĸ߶�"));
	pProp->EnableSpinControl(TRUE, 50, 300);
	pSize->AddSubItem(pProp);

	pProp = new CMFCPropertyGridProperty( _T("����"), (_variant_t) 150l, _T("ָ��ͼ��Ŀ���"));
	pProp->EnableSpinControl(TRUE, 50, 200);
	pSize->AddSubItem(pProp);

	m_wndPropListLib.AddProperty(pSize);


	CMFCPropertyGridPropertyEx* pGroup3 = new CMFCPropertyGridPropertyEx(_T("����"));
	pProp = new CMFCPropertyGridProperty(_T("(����)"), _T("���"));
	pProp->Enable(FALSE);
	pGroup3->AddSubItem(pProp);

	CMFCPropertyGridColorProperty* pColorProp = new CMFCPropertyGridColorProperty(_T("��ɫ"), RGB(210, 192, 254), NULL, _T("ָ��Ĭ�ϵĴ�����ɫ"));
	pColorProp->EnableOtherButton(_T("����..."));
	pColorProp->EnableAutomaticButton(_T("Ĭ��"), ::GetSysColor(COLOR_3DFACE));
	pGroup3->AddSubItem(pColorProp);

	static const TCHAR szFilter[] = _T("ps�ļ�(*.psd)|*.psd|�����ļ�(*.*)|*.*||");
	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("ps�ļ�"), TRUE, _T(""), _T("psd"), 0, szFilter, _T("ָ������ͼ��")));

	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("�洢λ��"), _T("c:\\")));

	m_wndPropListLib.AddProperty(pGroup3);

	CMFCPropertyGridPropertyEx* pGroup4 = new CMFCPropertyGridPropertyEx(_T("��ṹ"));

	CMFCPropertyGridProperty* pGroup41 = new CMFCPropertyGridProperty(_T("��һ���Ӽ�"));
	pGroup4->AddSubItem(pGroup41);

	CMFCPropertyGridProperty* pGroup411 = new CMFCPropertyGridProperty(_T("�ڶ����Ӽ�"));
	pGroup41->AddSubItem(pGroup411);

	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 1"), (_variant_t) _T("ֵ 1"), _T("��Ϊ˵��")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 2"), (_variant_t) _T("ֵ 2"), _T("��Ϊ˵��")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 3"), (_variant_t) _T("ֵ 3"), _T("��Ϊ˵��")));

	pGroup4->Expand(FALSE);
	m_wndPropListLib.AddProperty(pGroup4);


	CMFCPropertyGridPropertyEx* pGroup5 = new CMFCPropertyGridPropertyEx(_T("����"));

	LOGFONT lf;
	CFont* font = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	font->GetLogFont(&lf);

	lstrcpy(lf.lfFaceName, _T("����, Arial"));

	pGroup5->AddSubItem(new CMFCPropertyGridFontProperty(_T("����"), lf, CF_EFFECTS | CF_SCREENFONTS, _T("ָ�����ڵ�Ĭ������")));
	pGroup5->AddSubItem(new CMFCPropertyGridProperty(_T("ʹ��ϵͳ����"), (_variant_t) true, _T("ָ������ʹ�á�MS Shell Dlg������")));

	pGroup5->Expand(FALSE);
	m_wndPropListLib.AddProperty(pGroup5);
	*/
}

void CPropertiesWnd::updateProperties ( CDocRoll* pDoc, bool bOnlyShow )
{
	if ( NULL== pDoc )
		return;

	m_iStatus	= 2;

	m_pDocCurrent	= pDoc;

	//-------------------------------------------------begin yangfan 2016_4_13
	pDoc->updatePropertyData ( );
	//-------------------------------------------------end   yangfan 2016_4_13


	m_wndPropListOrder.ShowWindow ( SW_HIDE );
	m_wndPropListLib.ShowWindow ( SW_HIDE );

//	m_wndPropListRoll.RemoveAll ( );
	m_wndPropListRoll.ShowWindow ( SW_SHOW );
	if ( bOnlyShow )
		return;

	m_wndPropListRoll.RemoveAll ( );
//	UpdateWindow ( );

	CString	strIndex;

	strIndex.Format ( _T("��ţ�%s"), pDoc->m_strIdentifier );
	CMFCPropertyGridPropertyEx* pGroup0 = new CMFCPropertyGridPropertyEx( strIndex );
	m_wndPropListRoll.AddProperty ( pGroup0 );

	CMFCPropertyGridPropertyEx* pGroup1 = new CMFCPropertyGridPropertyEx(_T("ʱ��"));

	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("ѹ����"), (_variant_t) false, _T("ѹ�������")));

	CMFCPropertyGridProperty* pProp = new CMFCPropertyGridProperty(_T("ѹ����"), _T("��۴�С"), _T("����֮һ:��ϸ�������С�����������δ���ࡱ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("ϸ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("δ����"));
	pProp->AllowEdit(FALSE);
	pGroup1->AddSubItem(pProp);

	m_pPropManufacturer	= new CMFCPropertyGridProperty(_T("Roll��������"), (_variant_t) pDoc->m_strManufacturer, _T("�༭����") );
	pGroup1->AddSubItem( m_pPropManufacturer );
//	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("��������"), (_variant_t) _T("����"), _T("�༭����")));

	m_wndPropListRoll.AddProperty(pGroup1);

	CMFCPropertyGridPropertyEx* pSize = new CMFCPropertyGridPropertyEx(_T("ͼ���С"), 0, TRUE);

	pProp = new CMFCPropertyGridProperty(_T("�߶�"), (_variant_t) 250l, _T("ָ��ͼ��ĸ߶�"));
	pProp->EnableSpinControl(TRUE, 50, 300);
	pSize->AddSubItem(pProp);

	pProp = new CMFCPropertyGridProperty( _T("����"), (_variant_t) 150l, _T("ָ��ͼ��Ŀ���"));
	pProp->EnableSpinControl(TRUE, 50, 200);
	pSize->AddSubItem(pProp);

	m_wndPropListRoll.AddProperty(pSize);


	CMFCPropertyGridPropertyEx* pGroup3 = new CMFCPropertyGridPropertyEx(_T("����"));
	pProp = new CMFCPropertyGridProperty(_T("(����)"), _T("���"));
	pProp->Enable(FALSE);
	pGroup3->AddSubItem(pProp);

	CMFCPropertyGridColorProperty* pColorProp = new CMFCPropertyGridColorProperty(_T("��ɫ"), RGB(210, 192, 254), NULL, _T("ָ��Ĭ�ϵĴ�����ɫ"));
	pColorProp->EnableOtherButton(_T("����..."));
	pColorProp->EnableAutomaticButton(_T("Ĭ��"), ::GetSysColor(COLOR_3DFACE));
	pGroup3->AddSubItem(pColorProp);

	static const TCHAR szFilter[] = _T("ps�ļ�(*.psd)|*.psd|�����ļ�(*.*)|*.*||");
	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("ps�ļ�"), TRUE, _T(""), _T("psd"), 0, szFilter, _T("ָ������ͼ��")));

	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("�洢λ��"), _T("c:\\")));

	m_wndPropListRoll.AddProperty(pGroup3);

	CMFCPropertyGridPropertyEx* pGroup4 = new CMFCPropertyGridPropertyEx(_T("��ṹ"));

	CMFCPropertyGridProperty* pGroup41 = new CMFCPropertyGridProperty(_T("��һ���Ӽ�"));
	pGroup4->AddSubItem(pGroup41);

	CMFCPropertyGridProperty* pGroup411 = new CMFCPropertyGridProperty(_T("�ڶ����Ӽ�"));
	pGroup41->AddSubItem(pGroup411);

	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 1"), (_variant_t) _T("ֵ 1"), _T("��Ϊ˵��")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 2"), (_variant_t) _T("ֵ 2"), _T("��Ϊ˵��")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 3"), (_variant_t) _T("ֵ 3"), _T("��Ϊ˵��")));

	pGroup4->Expand(FALSE);
	m_wndPropListRoll.AddProperty(pGroup4);


	CMFCPropertyGridPropertyEx* pGroup5 = new CMFCPropertyGridPropertyEx(_T("����"));

	LOGFONT lf;
	CFont* font = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	font->GetLogFont(&lf);

	lstrcpy(lf.lfFaceName, _T("����, Arial"));

	pGroup5->AddSubItem(new CMFCPropertyGridFontProperty(_T("����"), lf, CF_EFFECTS | CF_SCREENFONTS, _T("ָ�����ڵ�Ĭ������")));
	pGroup5->AddSubItem(new CMFCPropertyGridProperty(_T("ʹ��ϵͳ����"), (_variant_t) true, _T("ָ������ʹ�á�MS Shell Dlg������")));

	pGroup5->Expand(FALSE);
	m_wndPropListRoll.AddProperty(pGroup5);
}

CPropertiesWnd::CPropertiesWnd()
{
	m_iStatus	= -1;

	m_pPropManufacturer	= NULL;

	m_pDocCurrent	= NULL;

	m_pDocRollCurrent		= NULL;
	m_pDocRollLibCurrent	= NULL;
	m_pDocOrderCurrent		= NULL;
}

CPropertiesWnd::~CPropertiesWnd()
{
}

BEGIN_MESSAGE_MAP(CPropertiesWnd, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EXPAND_ALL, OnExpandAllProperties)
	ON_UPDATE_COMMAND_UI(ID_EXPAND_ALL, OnUpdateExpandAllProperties)
	ON_COMMAND(ID_SORTPROPERTIES, OnSortProperties)
	ON_UPDATE_COMMAND_UI(ID_SORTPROPERTIES, OnUpdateSortProperties)
	ON_COMMAND(ID_PROPERTIES1, OnProperties1)
	ON_UPDATE_COMMAND_UI(ID_PROPERTIES1, OnUpdateProperties1)
	ON_COMMAND(ID_PROPERTIES2, OnProperties2)
	ON_UPDATE_COMMAND_UI(ID_PROPERTIES2, OnUpdateProperties2)
	ON_WM_SETFOCUS()
	ON_WM_SETTINGCHANGE()

	ON_REGISTERED_MESSAGE ( AFX_WM_PROPERTY_CHANGED, OnPropertyChanged )
//	ON_CBN_SELCHANGE(ID_PROPERTIES_CB,OnComboBoxSelChange)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CResourceViewBar ��Ϣ��������

void CPropertiesWnd::AdjustLayout()
{
	if (GetSafeHwnd() == NULL)
	{
		return;
	}

	CRect rectClient,rectCombo;
	GetClientRect(rectClient);

	m_wndObjectCombo.GetWindowRect(&rectCombo);

	int cyCmb = rectCombo.Size().cy;
	int cyTlb = m_wndToolBar.CalcFixedLayout(FALSE, TRUE).cy;

	m_wndObjectCombo.SetWindowPos(NULL, rectClient.left, rectClient.top, rectClient.Width(), 200, SWP_NOACTIVATE | SWP_NOZORDER);
	m_wndToolBar.SetWindowPos(NULL, rectClient.left, rectClient.top + cyCmb, rectClient.Width(), cyTlb, SWP_NOACTIVATE | SWP_NOZORDER);
	m_wndPropListLib.SetWindowPos(NULL, rectClient.left, rectClient.top + cyCmb + cyTlb, rectClient.Width(), rectClient.Height() -(cyCmb+cyTlb), SWP_NOACTIVATE | SWP_NOZORDER);
	m_wndPropListOrder.SetWindowPos(NULL, rectClient.left, rectClient.top + cyCmb + cyTlb, rectClient.Width(), rectClient.Height() -(cyCmb+cyTlb), SWP_NOACTIVATE | SWP_NOZORDER);
	m_wndPropListRoll.SetWindowPos(NULL, rectClient.left, rectClient.top + cyCmb + cyTlb, rectClient.Width(), rectClient.Height() -(cyCmb+cyTlb), SWP_NOACTIVATE | SWP_NOZORDER);
}

int CPropertiesWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	// �������:
	const DWORD dwViewStyle = WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_BORDER | CBS_SORT | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;

	if (!m_wndObjectCombo.Create(dwViewStyle, rectDummy, this, 1))
	{
		TRACE0("δ�ܴ���������� \n");
		return -1;      // δ�ܴ���
	}

//	m_wndObjectCombo.AddString(_T("Application"));
//	m_wndObjectCombo.AddString(_T("Properties Window"));
//	m_wndObjectCombo.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
//	m_wndObjectCombo.SetCurSel(0);

	if (!m_wndPropListOrder.Create(WS_VISIBLE | WS_CHILD, rectDummy, this, 2))
	{
		TRACE0("Failed to create Properties Grid \n");
		return -1;      // fail to create
	}

	if (!m_wndPropListRoll.Create(WS_VISIBLE | WS_CHILD, rectDummy, this, 3))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}

	if (!m_wndPropListLib.Create(WS_VISIBLE | WS_CHILD, rectDummy, this, 4))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}

	InitPropListLib();
	InitPropListRoll();
	InitPropListOrder();

	m_wndToolBar.Create(this, AFX_DEFAULT_TOOLBAR_STYLE, IDR_PROPERTIES);
	m_wndToolBar.LoadToolBar(IDR_PROPERTIES, 0, 0, TRUE /* ������*/);
	m_wndToolBar.CleanUpLockedImages();
	m_wndToolBar.LoadBitmap(theApp.m_bHiColorIcons ? IDB_PROPERTIES_HC : IDR_PROPERTIES, 0, 0, TRUE /* ����*/);

	m_wndToolBar.SetPaneStyle(m_wndToolBar.GetPaneStyle() | CBRS_TOOLTIPS | CBRS_FLYBY);
	m_wndToolBar.SetPaneStyle(m_wndToolBar.GetPaneStyle() & ~(CBRS_GRIPPER | CBRS_SIZE_DYNAMIC | CBRS_BORDER_TOP | CBRS_BORDER_BOTTOM | CBRS_BORDER_LEFT | CBRS_BORDER_RIGHT));
	m_wndToolBar.SetOwner(this);

	// �������ͨ���˿ؼ�·�ɣ�������ͨ�������·��:
	m_wndToolBar.SetRouteCommandsViaFrame(FALSE);

	AdjustLayout();

	m_wndPropListOrder.ShowWindow ( SW_HIDE );
	m_wndPropListRoll.ShowWindow ( SW_HIDE );

	return 0;
}

void CPropertiesWnd::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	AdjustLayout();
}

void CPropertiesWnd::OnExpandAllProperties()
{
	m_wndPropListOrder.ExpandAll();
	m_wndPropListLib.ExpandAll();
	m_wndPropListRoll.ExpandAll();
//	m_wndPropListRoll.ExpandAll();
}

void CPropertiesWnd::OnUpdateExpandAllProperties(CCmdUI* /* pCmdUI */)
{
}

void CPropertiesWnd::OnSortProperties()
{
	m_wndPropListOrder.SetAlphabeticMode(!m_wndPropListOrder.IsAlphabeticMode());
	m_wndPropListLib.SetAlphabeticMode(!m_wndPropListLib.IsAlphabeticMode());
	m_wndPropListRoll.SetAlphabeticMode(!m_wndPropListRoll.IsAlphabeticMode());
}

void CPropertiesWnd::OnUpdateSortProperties(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_wndPropListLib.IsAlphabeticMode());
}

void CPropertiesWnd::OnProperties1()
{
	// TODO: �ڴ˴�����������������
}

void CPropertiesWnd::OnUpdateProperties1(CCmdUI* /*pCmdUI*/)
{
	// TODO: �ڴ˴������������ UI �����������
}

void CPropertiesWnd::OnProperties2()
{
	// TODO: �ڴ˴�����������������
}

void CPropertiesWnd::OnUpdateProperties2(CCmdUI* /*pCmdUI*/)
{
	// TODO: �ڴ˴������������ UI �����������
}

void CPropertiesWnd::InitPropListOrder ()
{
	SetPropListFont();

	m_wndPropListOrder.EnableHeaderCtrl(FALSE);
	m_wndPropListOrder.EnableDescriptionArea();
	m_wndPropListOrder.SetVSDotNetLook();
	m_wndPropListOrder.MarkModifiedProperties();

	//-----------------------------------------------------------------------------------------begin yangfan 2016_4_23
	return;
	//cancel all,kepp the same with InitPropListLib
	/*
	CMFCPropertyGridPropertyEx* pGroup1 = new CMFCPropertyGridPropertyEx(_T("Order����a��Ϣ"));

	pGroup1->AddSubItem(new CMFCPropertyGridPropertyEx(_T("Orderѹ����"), (_variant_t) false, _T("ѹ�������")));

	CMFCPropertyGridProperty* pProp = new CMFCPropertyGridPropertyEx(_T("ѹ����"), _T("��۴�С"), _T("����֮һ:��ϸ�������С�����������δ���ࡱ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("ϸ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("δ����"));
	pProp->AllowEdit(FALSE);
	pGroup1->AddSubItem(pProp);

	m_pPropManufacturer	= new CMFCPropertyGridProperty(_T("��������"), (_variant_t) _T("��a��"), _T("�༭����"));
	pGroup1->AddSubItem( m_pPropManufacturer );

//	COleVariant	varManufacturer;
//	varManufacturer.bstrVal	= _T("���̸���");
//	m_pPropManufacturer->SetValue ( varManufacturer );
//	m_pPropManufacturer->SetName ( _T("���̸���") );

	m_wndPropListOrder.AddProperty(pGroup1);

//	m_wndPropListRoll.AddProperty(pGroup1);

	CMFCPropertyGridPropertyEx* pSize = new CMFCPropertyGridPropertyEx(_T("ͼ���С"), 0, TRUE);

	pProp = new CMFCPropertyGridPropertyEx(_T("�߶�"), (_variant_t) 250l, _T("ָ��ͼ��ĸ߶�"));
	pProp->EnableSpinControl(TRUE, 50, 300);
	pSize->AddSubItem(pProp);

	pProp = new CMFCPropertyGridPropertyEx( _T("����"), (_variant_t) 150l, _T("ָ��ͼ��Ŀ���"));
	pProp->EnableSpinControl(TRUE, 50, 200);
	pSize->AddSubItem(pProp);

	m_wndPropListOrder.AddProperty(pSize);

	CMFCPropertyGridPropertyEx* pGroup2 = new CMFCPropertyGridPropertyEx(_T("Font"));

	LOGFONT lf;
	CFont* font = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	font->GetLogFont(&lf);

	lstrcpy(lf.lfFaceName, _T("Arial"));

	pGroup2->AddSubItem(new CMFCPropertyGridFontProperty(_T("Font"), lf, CF_EFFECTS | CF_SCREENFONTS, _T("Specifies the default font for the window")));
	pGroup2->AddSubItem(new CMFCPropertyGridProperty(_T("Use System Font"), (_variant_t) true, _T("Specifies that the window uses MS Shell Dlg font")));

	m_wndPropListOrder.AddProperty(pGroup2);

	CMFCPropertyGridPropertyEx* pGroup3 = new CMFCPropertyGridPropertyEx(_T("Misc"));
	pProp = new CMFCPropertyGridProperty(_T("(Name)"), _T("Application"));
	pProp->Enable(FALSE);
	pGroup3->AddSubItem(pProp);

	CMFCPropertyGridColorProperty* pColorProp = new CMFCPropertyGridColorProperty(_T("Window Color"), RGB(210, 192, 254), NULL, _T("Specifies the default window color"));
	pColorProp->EnableOtherButton(_T("Other..."));
	pColorProp->EnableAutomaticButton(_T("Default"), ::GetSysColor(COLOR_3DFACE));
	pGroup3->AddSubItem(pColorProp);

	static TCHAR BASED_CODE szFilter[] = _T("Icon Files(*.ico)|*.ico|All Files(*.*)|*.*||");
	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("Icon"), TRUE, _T(""), _T("ico"), 0, szFilter, _T("Specifies the window icon")));

	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("Folder"), _T("c:\\")));

	m_wndPropListOrder.AddProperty(pGroup3);

	CMFCPropertyGridPropertyEx* pGroup4 = new CMFCPropertyGridPropertyEx(_T("Hierarchy"));

	CMFCPropertyGridProperty* pGroup41 = new CMFCPropertyGridProperty(_T("First sub-level"));
	pGroup4->AddSubItem(pGroup41);

	CMFCPropertyGridProperty* pGroup411 = new CMFCPropertyGridProperty(_T("Second sub-level"));
	pGroup41->AddSubItem(pGroup411);

	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("Item 1"), (_variant_t) _T("Value 1"), _T("This is a description")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("Item 2"), (_variant_t) _T("Value 2"), _T("This is a description")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("Item 3"), (_variant_t) _T("Value 3"), _T("This is a description")));

	pGroup4->Expand(FALSE);
	m_wndPropListOrder.AddProperty(pGroup4);
	*/



}

void CPropertiesWnd::InitPropListRoll ( )
{
	SetPropListFont();

	m_wndPropListRoll.EnableHeaderCtrl(FALSE);
	m_wndPropListRoll.EnableDescriptionArea();
	m_wndPropListRoll.SetVSDotNetLook();
	m_wndPropListRoll.MarkModifiedProperties();

	//-------------------------------------------------------------------------------------------------------------begin yangfan 2016_4_12
	//cancel and keep the same with m_wndPropListLib
	return;
	//-----------------------------------------------------------------------------------------begin yangfan 2016_4_10
	/*
	CMFCPropertyGridPropertyEx* pGroup1 = new CMFCPropertyGridPropertyEx(_T("����"));
	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("��������"), (_variant_t) "����", _T("�༭����")));
	m_wndPropListRoll.AddProperty(pGroup1);

	CMFCPropertyGridPropertyEx* pGroup2 = new CMFCPropertyGridPropertyEx(_T("ʱ��"));
	pGroup2->AddSubItem(new CMFCPropertyGridProperty(_T("ʱ��"), (_variant_t) "00:00 1970/1/1", _T("�༭ʱ��")));
	m_wndPropListRoll.AddProperty(pGroup2);

	CMFCPropertyGridPropertyEx* pGroup3 = new CMFCPropertyGridPropertyEx(_T("���"));
	pGroup3->AddSubItem(new CMFCPropertyGridProperty(_T("���"), (_variant_t) "0", _T("�༭���")));
	m_wndPropListRoll.AddProperty(pGroup3);

	CMFCPropertyGridPropertyEx* pGroup4 = new CMFCPropertyGridPropertyEx(_T("�洢·��"));
	pGroup4->AddSubItem(new CMFCPropertyGridProperty(_T("�洢·��"), (_variant_t) "X:\\default.jpg", _T("�༭�洢·��")));
	m_wndPropListRoll.AddProperty(pGroup4);
	*/
	//-----------------------------------------------------------------------------------------end  yangfan  2016_4_10

	/*
	CMFCPropertyGridPropertyEx* pGroup1 = new CMFCPropertyGridPropertyEx(_T("Roll����aaaa"));
	
	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("Rollѹ����_initial"), (_variant_t) false, _T("ѹ�������")));
	CMFCPropertyGridProperty* pProp = new CMFCPropertyGridProperty(_T("ѹ����roll_initial"), _T("��۴�С"), _T("����֮һ:��ϸ�������С�����������δ���ࡱ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("ϸ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("δ����"));
	pProp->AllowEdit(FALSE);

	pGroup1->AddSubItem(pProp);
	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("��������roll_initial"), (_variant_t) _T("����"), _T("�༭����")));

	m_wndPropListRoll.AddProperty(pGroup1);
	
//	m_wndPropListRoll.AddProperty(pGroup1);

	CMFCPropertyGridPropertyEx* pSize = new CMFCPropertyGridPropertyEx(_T("ͼ���Сaaa_roll_initial"), 0, TRUE);

	pProp = new CMFCPropertyGridProperty(_T("�߶�roll_initial"), (_variant_t) 250l, _T("ָ��ͼ��ĸ߶�"));
	pProp->EnableSpinControl(TRUE, 50, 300);
	pSize->AddSubItem(pProp);

	pProp = new CMFCPropertyGridProperty( _T("����roll_initial"), (_variant_t) 150l, _T("ָ��ͼ��Ŀ���"));
	pProp->EnableSpinControl(TRUE, 50, 200);
	pSize->AddSubItem(pProp);

	m_wndPropListRoll.AddProperty(pSize);


	CMFCPropertyGridPropertyEx* pGroup3 = new CMFCPropertyGridPropertyEx(_T("����"));
	pProp = new CMFCPropertyGridProperty(_T("(����)"), _T("���"));
	pProp->Enable(FALSE);
	pGroup3->AddSubItem(pProp);

	CMFCPropertyGridColorProperty* pColorProp = new CMFCPropertyGridColorProperty(_T("��ɫ"), RGB(210, 192, 254), NULL, _T("ָ��Ĭ�ϵĴ�����ɫ"));
	pColorProp->EnableOtherButton(_T("����..."));
	pColorProp->EnableAutomaticButton(_T("Ĭ��"), ::GetSysColor(COLOR_3DFACE));
	pGroup3->AddSubItem(pColorProp);

	static const TCHAR szFilter[] = _T("ps�ļ�(*.psd)|*.psd|�����ļ�(*.*)|*.*||");
	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("ps�ļ�"), TRUE, _T(""), _T("psd"), 0, szFilter, _T("ָ������ͼ��")));

	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("�洢λ��"), _T("c:\\")));

	m_wndPropListRoll.AddProperty(pGroup3);

	CMFCPropertyGridPropertyEx* pGroup4 = new CMFCPropertyGridPropertyEx(_T("��ṹ"));

	CMFCPropertyGridProperty* pGroup41 = new CMFCPropertyGridProperty(_T("��һ���Ӽ�"));
	pGroup4->AddSubItem(pGroup41);

	CMFCPropertyGridProperty* pGroup411 = new CMFCPropertyGridProperty(_T("�ڶ����Ӽ�"));
	pGroup41->AddSubItem(pGroup411);

	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 1"), (_variant_t) _T("ֵ 1"), _T("��Ϊ˵��")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 2"), (_variant_t) _T("ֵ 2"), _T("��Ϊ˵��")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 3"), (_variant_t) _T("ֵ 3"), _T("��Ϊ˵��")));

	pGroup4->Expand(FALSE);
	m_wndPropListRoll.AddProperty(pGroup4);


	CMFCPropertyGridPropertyEx* pGroup5 = new CMFCPropertyGridPropertyEx(_T("����"));

	LOGFONT lf;
	CFont* font = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	font->GetLogFont(&lf);

	lstrcpy(lf.lfFaceName, _T("����, Arial"));

	pGroup5->AddSubItem(new CMFCPropertyGridFontProperty(_T("����"), lf, CF_EFFECTS | CF_SCREENFONTS, _T("ָ�����ڵ�Ĭ������")));
	pGroup5->AddSubItem(new CMFCPropertyGridProperty(_T("ʹ��ϵͳ����"), (_variant_t) true, _T("ָ������ʹ�á�MS Shell Dlg������")));

	pGroup5->Expand(FALSE);
	m_wndPropListRoll.AddProperty(pGroup5);
	*/




	//-------------------------------------------------------------------------------------------------------------begin yangfan 2016_4_12
}

void CPropertiesWnd::OnSetFocus(CWnd* pOldWnd)
{
	CDockablePane::OnSetFocus(pOldWnd);
	m_wndPropListLib.SetFocus();
}

void CPropertiesWnd::OnSettingChange(UINT uFlags, LPCTSTR lpszSection)
{
	CDockablePane::OnSettingChange(uFlags, lpszSection);
	SetPropListFont();
}

void CPropertiesWnd::SetPropListFont()
{
	::DeleteObject(m_fntPropList.Detach());

	LOGFONT lf;
	afxGlobalData.fontRegular.GetLogFont(&lf);

	NONCLIENTMETRICS info;
	info.cbSize = sizeof(info);

	afxGlobalData.GetNonClientMetrics(info);

	lf.lfHeight = info.lfMenuFont.lfHeight;
	lf.lfWeight = info.lfMenuFont.lfWeight;
	lf.lfItalic = info.lfMenuFont.lfItalic;

	m_fntPropList.CreateFontIndirect(&lf);

	m_wndPropListOrder.SetFont(&m_fntPropList);
	m_wndPropListLib.SetFont(&m_fntPropList);
	m_wndPropListRoll.SetFont(&m_fntPropList);
//	m_wndObjectCombo.SetFont(&m_fntPropList);
}

void CPropertiesWnd::showProperties ( CDocRoll* pDoc )
{
	if ( NULL == pDoc )
		return;

	m_pDocCurrent	= pDoc;

//	m_pDocRollCurrent	= pDoc;
}

LRESULT CPropertiesWnd::OnPropertyChanged ( WPARAM wParam, LPARAM lParam )
{
//	int							i;
	//CString						strName;
	//CString						strValue;
	//COleVariant					varNewValue;
	//COleVariant					varOldValue;
	CMFCPropertyGridPropertyEx*	pProp;
	//CMFCPropertyGridProperty*	pParent;
	//CMFCPropertyGridProperty*	pRoot;
	LPPROPERTY_DATA_ITEM		pItem;

	pProp	= (CMFCPropertyGridPropertyEx*) lParam;
	pItem	= pProp->m_pItem;

	if ( NULL == pItem )
		return	0;

	if ( NULL == m_pDocCurrent )
		return	0;

	m_pDocCurrent->onItemChanged ( pItem, pProp );
	//pItem->onItemChanged ( pProp );
	
	//pParent	= pProp->GetParent ( );
	//pRoot	= pParent;
	//while ( pRoot )
	//{
	//	pParent	= pRoot;

	//	pRoot	= pRoot->GetParent ( );
	//}

	//if ( &m_wndPropListOrder == pParent )
	//{
	//}
	//else if ( &m_wndPropListLib == pParent )
	//{
	//}
	//else if ( &m_wndPropListRoll == pParent )
	//{
	//}

	//i		= (int)pProp->GetData ( );
	//strName	= pProp->GetName ( );

	//varNewValue	= pProp->GetValue ( );
	//varOldValue	= pProp->GetOriginalValue ( );

	//strValue	= varNewValue.bstrVal;

//	m_wndPropList.MarkModifiedProperties ( );

	//if ( pProp == m_pPropManufacturer )
	//{
	//	varNewValue	= pProp->GetValue ( );
	//	strValue	= varNewValue.bstrVal;

	//	if ( m_pDocRollCurrent )
	//	{
	//		m_pDocRollCurrent->setManufacturer ( strValue );
	//	}

	//	return	0;
	//}

	return	0;
}