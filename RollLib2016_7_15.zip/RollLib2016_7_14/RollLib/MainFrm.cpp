// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// MainFrm.cpp : CMainFrame ���ʵ��
//

#include "stdafx.h"
#include "RollLib.h"

#include "MainFrm.h"

#include "DocRollLib.h"
#include "ViewRollLib.h"
//------------------------begin yangfan 2016_5_10
#include"ViewOrder.h"
//------------------------end   yanfgan 2016_5_10
#include "DocOrder.h"

//------------------------begin yangfan 2016_4_29
#include"NewCustomer.h"
#include "DBmySQL.h"
//------------------------end   yangfan 2016_4_29

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWndEx)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWndEx)
	ON_WM_CREATE()
	// ȫ�ְ�������
	ON_COMMAND(ID_HELP_FINDER, &CMDIFrameWndEx::OnHelpFinder)
	ON_COMMAND(ID_HELP, &CMDIFrameWndEx::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, &CMDIFrameWndEx::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, &CMDIFrameWndEx::OnHelpFinder)
	ON_COMMAND(ID_WINDOW_MANAGER, &CMainFrame::OnWindowManager)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnUpdateApplicationLook)
	ON_COMMAND(ID_VIEW_CAPTION_BAR, &CMainFrame::OnViewCaptionBar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_CAPTION_BAR, &CMainFrame::OnUpdateViewCaptionBar)
	ON_COMMAND(ID_TOOLS_OPTIONS, &CMainFrame::OnOptions)
	ON_WM_SETTINGCHANGE()
	ON_WM_CLOSE()
	//----------------------------------------begin yangfan 2016_4_29
	ON_COMMAND(ID_BTN_NEWCUSTOMER, &CMainFrame::OnBtnNewcustomer)
	//----------------------------------------end   yangfan 2016_4_29
END_MESSAGE_MAP()


//----------------------------------begin yangfan 2016_6_13
void CMainFrame::ShowScale(int a_Scale)  //��״̬������ʾͼ����ʾ����
{
	CString str;
	str.Format(_T("%d"),a_Scale);
	str += "%";
	m_wndStatusBars.SetPaneText(1,str);
	
}
//----------------------------------end   yangfan 2016_6_13


// CMainFrame ����/����
CMainFrame::CMainFrame()
{
	//----------------------------begin yangfan 2016_4_29
	//updateBtnOrderQuery = true;
	//m_nNumberIndent = 0;
	//----------------------------end   yangfan 2016_4_29

	m_pDocRollCurrent		= NULL;
	m_pDocRollLibCurrent	= NULL;
	m_pDocOrderCurrent		= NULL;

	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_OFF_2007_BLUE);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;
	// ���ڳ־�ֵ�����Ӿ�����������ʽ
	OnApplicationLook(theApp.m_nAppLook);

	CMDITabInfo mdiTabParams;
	mdiTabParams.m_style = CMFCTabCtrl::STYLE_3D_ONENOTE; // ����������ʽ...
	mdiTabParams.m_bActiveTabCloseButton = TRUE;      // ����Ϊ FALSE �Ὣ�رհ�ť������ѡ�������Ҳ�
	mdiTabParams.m_bTabIcons = FALSE;    // ����Ϊ TRUE ���� MDI ѡ��������ĵ�ͼ��
	mdiTabParams.m_bAutoColor = TRUE;    // ����Ϊ FALSE ������ MDI ѡ����Զ���ɫ
	mdiTabParams.m_bDocumentMenu = TRUE; // ��ѡ�������ұ�Ե�����ĵ��˵�
	EnableMDITabbedGroups(TRUE, mdiTabParams);

	m_wndRibbonBar.Create(this);
	m_wndRibbonBar.LoadFromResource(IDR_RIBBON);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("δ�ܴ���״̬��\n");
		return -1;      // δ�ܴ���
	}

	CString strTitlePane1;
	CString strTitlePane2;
	bNameValid = strTitlePane1.LoadString(IDS_STATUS_PANE1);
	ASSERT(bNameValid);
	bNameValid = strTitlePane2.LoadString(IDS_STATUS_PANE2);
	ASSERT(bNameValid);
	m_wndStatusBar.AddElement(new CMFCRibbonStatusBarPane(ID_STATUSBAR_PANE1, strTitlePane1, TRUE), strTitlePane1);
	m_wndStatusBar.AddExtendedElement(new CMFCRibbonStatusBarPane(ID_STATUSBAR_PANE2, strTitlePane2, TRUE), strTitlePane2);

	// ���� Visual Studio 2005 ��ʽͣ��������Ϊ
	CDockingManager::SetDockingMode(DT_SMART);
	// ���� Visual Studio 2005 ��ʽͣ�������Զ�������Ϊ
	EnableAutoHidePanes(CBRS_ALIGN_ANY);

	// �������񽫴�������࣬��˽���ʱ��������ͣ��:
	EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM | CBRS_ALIGN_RIGHT);

	// ���������á�Outlook��������:
	if (!CreateOutlookBar(m_wndNavigationBar, ID_VIEW_NAVIGATION, m_wndTree, m_wndCalendar, 250))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}

	// ����������:
	if (!CreateCaptionBar())
	{
		TRACE0("δ�ܴ���������\n");
		return -1;      // δ�ܴ���
	}

	// �Ѵ��� Outlook ����Ӧ���������ͣ����
	EnableDocking(CBRS_ALIGN_LEFT);
//	EnableAutoHidePanes(CBRS_ALIGN_RIGHT);
	EnableAutoHidePanes(CBRS_ALIGN_LEFT);

	// ���ز˵���ͼ��(�����κα�׼��������):
	CMFCToolBar::AddToolBarForImageCollection(IDR_MENU_IMAGES, theApp.m_bHiColorIcons ? IDB_MENU_IMAGES_24 : 0);

	// ����ͣ������
	if (!CreateDockingWindows())
	{
		TRACE0("δ�ܴ���ͣ������\n");
		return -1;
	}

	m_wndFileView.EnableDocking(CBRS_ALIGN_ANY);
	m_wndClassView.EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndFileView);
	CDockablePane* pTabbedBar = NULL;
	m_wndClassView.AttachToTabWnd(&m_wndFileView, DM_SHOW, TRUE, &pTabbedBar);

	m_wndProperties.EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndProperties);

//	EnableDocking(CBRS_ALIGN_RIGHT);
	m_wndOutput.EnableDocking(CBRS_ALIGN_ANY);
//	m_wndOutput.EnableDocking(CBRS_ALIGN_RIGHT);
	DockPane ( &m_wndOutput );


	// ������ǿ�Ĵ��ڹ����Ի���
	EnableWindowsDialog(ID_WINDOW_MANAGER, ID_WINDOW_MANAGER, TRUE);

	// ���ĵ�����Ӧ�ó��������ڴ��ڱ������ϵ�˳����н�������
	// ���Ľ��������Ŀ����ԣ���Ϊ��ʾ���ĵ�����������ͼ��
	ModifyStyle(0, FWS_PREFIXTITLE);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
		 | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE | WS_SYSMENU;

	return TRUE;
}

BOOL CMainFrame::CreateDockingWindows()
{
	BOOL bNameValid;

	// ��������ͼ
	CString strClassView;
	bNameValid = strClassView.LoadString(IDS_CLASS_VIEW);
	ASSERT(bNameValid);
	if (!m_wndClassView.Create(strClassView, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_CLASSVIEW, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_LEFT | CBRS_FLOAT_MULTI))
	{
		TRACE0("δ�ܴ���������ͼ������\n");
		return FALSE; // δ�ܴ���
	}

	// �����ļ���ͼ
	CString strFileView;
	bNameValid = strFileView.LoadString(IDS_FILE_VIEW);
	ASSERT(bNameValid);
	if (!m_wndFileView.Create(strFileView, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_FILEVIEW, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_LEFT| CBRS_FLOAT_MULTI))
	{
		TRACE0("δ�ܴ������ļ���ͼ������\n");
		return FALSE; // δ�ܴ���
	}

	// �����������
	CString strOutputWnd;
	bNameValid = strOutputWnd.LoadString(IDS_OUTPUT_WND);
	ASSERT(bNameValid);
	if (!m_wndOutput.Create(strOutputWnd, this, CRect(0, 0, 100, 100), TRUE, ID_VIEW_OUTPUTWND, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_RIGHT | CBRS_FLOAT_MULTI))
	{
		TRACE0("δ�ܴ����������\n");
		return FALSE; // δ�ܴ���
	}

	// �������Դ���
	CString strPropertiesWnd;
	bNameValid = strPropertiesWnd.LoadString(IDS_PROPERTIES_WND);
	ASSERT(bNameValid);
	if (!m_wndProperties.Create(strPropertiesWnd, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_PROPERTIESWND, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_BOTTOM | CBRS_FLOAT_MULTI))
	{
		TRACE0("δ�ܴ��������ԡ�����\n");
		return FALSE; // δ�ܴ���
	}

	SetDockingWindowIcons(theApp.m_bHiColorIcons);
	return TRUE;
}

void CMainFrame::SetDockingWindowIcons(BOOL bHiColorIcons)
{
	HICON hFileViewIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_FILE_VIEW_HC : IDI_FILE_VIEW), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndFileView.SetIcon(hFileViewIcon, FALSE);

	HICON hClassViewIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_CLASS_VIEW_HC : IDI_CLASS_VIEW), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndClassView.SetIcon(hClassViewIcon, FALSE);

	HICON hOutputBarIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_OUTPUT_WND_HC : IDI_OUTPUT_WND), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndOutput.SetIcon(hOutputBarIcon, FALSE);

	HICON hPropertiesBarIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_PROPERTIES_WND_HC : IDI_PROPERTIES_WND), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndProperties.SetIcon(hPropertiesBarIcon, FALSE);

	UpdateMDITabbedBarsIcons();
}

BOOL CMainFrame::CreateOutlookBar(CMFCOutlookBar& bar, UINT uiID, CMFCShellTreeCtrl& tree, CCalendarBar& calendar, int nInitialWidth)
{
	bar.SetMode2003();

	BOOL bNameValid;
	CString strTemp;
	bNameValid = strTemp.LoadString(IDS_SHORTCUTS);
	ASSERT(bNameValid);
	if (!bar.Create(strTemp, this, CRect(0, 0, nInitialWidth, 32000), uiID, WS_CHILD | WS_VISIBLE | CBRS_LEFT))
	{
		return FALSE; // δ�ܴ���
	}

	CMFCOutlookBarTabCtrl* pOutlookBar = (CMFCOutlookBarTabCtrl*)bar.GetUnderlyingWindow();

	if (pOutlookBar == NULL)
	{
		ASSERT(FALSE);
		return FALSE;
	}

	pOutlookBar->EnableInPlaceEdit(TRUE);

	static UINT uiPageID = 1;

	// �ɸ��������Զ����أ��ɵ�����С�������ܹر�
	DWORD dwStyle = AFX_CBRS_FLOAT | AFX_CBRS_AUTOHIDE | AFX_CBRS_RESIZE;

	CRect rectDummy(0, 0, 0, 0);
	const DWORD dwTreeStyle = WS_CHILD | WS_VISIBLE | TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS;

	tree.Create(dwTreeStyle, rectDummy, &bar, 1200);
	bNameValid = strTemp.LoadString(IDS_FOLDERS);
	ASSERT(bNameValid);
	pOutlookBar->AddControl(&tree, strTemp, 2, TRUE, dwStyle);

	calendar.Create(rectDummy, &bar, 1201);
	bNameValid = strTemp.LoadString(IDS_CALENDAR);
	ASSERT(bNameValid);
	pOutlookBar->AddControl(&calendar, strTemp, 3, TRUE, dwStyle);

	bar.SetPaneStyle(bar.GetPaneStyle() | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	pOutlookBar->SetImageList(theApp.m_bHiColorIcons ? IDB_PAGES_HC : IDB_PAGES, 24);
	pOutlookBar->SetToolbarImageList(theApp.m_bHiColorIcons ? IDB_PAGES_SMALL_HC : IDB_PAGES_SMALL, 16);
	pOutlookBar->RecalcLayout();

	BOOL bAnimation = theApp.GetInt(_T("OutlookAnimation"), TRUE);
	CMFCOutlookBarTabCtrl::EnableAnimation(bAnimation);

	bar.SetButtonsFont(&afxGlobalData.fontBold);

	return TRUE;
}

BOOL CMainFrame::CreateCaptionBar()
{
	if (!m_wndCaptionBar.Create(WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS, this, ID_VIEW_CAPTION_BAR, -1, TRUE))
	{
		TRACE0("δ�ܴ���������\n");
		return FALSE;
	}

	BOOL bNameValid;

	CString strTemp, strTemp2;
	bNameValid = strTemp.LoadString(IDS_CAPTION_BUTTON);
	ASSERT(bNameValid);
	m_wndCaptionBar.SetButton(strTemp, ID_TOOLS_OPTIONS, CMFCCaptionBar::ALIGN_LEFT, FALSE);
	bNameValid = strTemp.LoadString(IDS_CAPTION_BUTTON_TIP);
	ASSERT(bNameValid);
	m_wndCaptionBar.SetButtonToolTip(strTemp);

	bNameValid = strTemp.LoadString(IDS_CAPTION_TEXT);
	ASSERT(bNameValid);
	m_wndCaptionBar.SetText(strTemp, CMFCCaptionBar::ALIGN_LEFT);

	m_wndCaptionBar.SetBitmap(IDB_INFO, RGB(255, 255, 255), FALSE, CMFCCaptionBar::ALIGN_LEFT);
	bNameValid = strTemp.LoadString(IDS_CAPTION_IMAGE_TIP);
	ASSERT(bNameValid);
	bNameValid = strTemp2.LoadString(IDS_CAPTION_IMAGE_TEXT);
	ASSERT(bNameValid);
	m_wndCaptionBar.SetImageToolTip(strTemp, strTemp2);

	return TRUE;
}

// CMainFrame ���

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame ��Ϣ��������

void CMainFrame::OnWindowManager()
{
	ShowWindowsDialog();
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_VS_2008:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2008));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_WINDOWS_7:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows7));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(TRUE);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
	}

	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}

void CMainFrame::OnViewCaptionBar()
{
	m_wndCaptionBar.ShowWindow(m_wndCaptionBar.IsVisible() ? SW_HIDE : SW_SHOW);
	RecalcLayout(FALSE);
}

void CMainFrame::OnUpdateViewCaptionBar(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_wndCaptionBar.IsVisible());
}

void CMainFrame::OnOptions()
{
	CMFCRibbonCustomizeDialog *pOptionsDlg = new CMFCRibbonCustomizeDialog(this, &m_wndRibbonBar);
	ASSERT(pOptionsDlg != NULL);

	pOptionsDlg->DoModal();
	delete pOptionsDlg;
}

void CMainFrame::OnSettingChange(UINT uFlags, LPCTSTR lpszSection)
{
	CMDIFrameWndEx::OnSettingChange(uFlags, lpszSection);
	m_wndOutput.UpdateFonts();
}

void CMainFrame::outputString ( CString strMsg, int iKind )
{
	m_wndOutput.outputString ( strMsg, iKind );
}

void CMainFrame::setCurrentDoc ( CDocRoll* pDoc, bool bRefreshProperty/* =true */ )
{
	if ( NULL == pDoc )
		return;

	if ( m_pDocRollCurrent == pDoc )
	{
		if ( bRefreshProperty )
		{
			refreshProperty ( pDoc );
			return;
		}
	}

	m_pDocRollCurrent	= pDoc;
	refreshProperty ( pDoc );

	//if ( pDoc->IsKindOf(RUNTIME_CLASS(CDocOrder)))
	//	m_wndOutput.UpdateSeparatedColors ( (CDocOrder*)pDoc );
	//else
	//	m_wndOutput.UpdateSeparatedColors ( NULL );
}

void CMainFrame::setCurrentDoc ( CDocRollLib* pDoc, bool bRefreshProperty/* =true */ )
{
	m_wndOutput.UpdateSeparatedColors ( NULL );

	if ( NULL == pDoc )
		return;

	if ( m_pDocRollLibCurrent == pDoc )
	{
		if ( bRefreshProperty )
		{
			refreshProperty ( pDoc );
			return;
		}
	}

	m_pDocRollLibCurrent	= pDoc;

	refreshProperty ( pDoc );
}

void CMainFrame::setCurrentDoc ( CDocOrder* pDoc, bool bRefreshProperty/* =true */ )
{
	m_wndOutput.UpdateSeparatedColors ( NULL );

	if ( NULL == pDoc )
		return;

	if ( m_pDocOrderCurrent == pDoc )
	{
		if ( bRefreshProperty )
		{
			refreshProperty ( pDoc );
			return;
		}
	}

	m_pDocOrderCurrent	= pDoc;

	refreshProperty ( pDoc );
}

void CMainFrame::refreshProperty ( CDocRoll* pDoc, bool bOnlyShow )
{
	if ( m_pDocRollCurrent != pDoc )
	{
		m_pDocRollCurrent	= pDoc;

		bOnlyShow	= false;
	}

	m_wndProperties.updateProperties ( pDoc, bOnlyShow );
}

void CMainFrame::refreshProperty ( CDocRollLib* pDoc )
{
	m_wndProperties.updateProperties ( pDoc );
}

void CMainFrame::refreshProperty ( CDocOrder* pDoc, bool bOnlyShow )
{
	m_wndProperties.updateProperties ( pDoc, bOnlyShow );
}

void CMainFrame::refreshSeparatedColors ( CDocOrder* pDoc )
{
	m_wndOutput.UpdateSeparatedColors ( pDoc );
}

void CMainFrame::initializeProperty ( CDocRollLib* pDoc )
{
	m_wndProperties.initializeProperty ( pDoc );
}

void CMainFrame::initializeProperty ( CDocOrder* pDoc )
{
	m_wndProperties.initializeProperty ( pDoc );
}

void CMainFrame::initializeProperty ( CDocRoll* pDoc )
{
	m_wndProperties.initializeProperty ( pDoc );
}

void CMainFrame::refreshRollMatches ( CDocOrder* pDoc )
{
	m_wndOutput.UpdateRollMatches ( pDoc );
}

void CMainFrame::OnClose()
{
	theApp.m_bWork	= FALSE;
	while ( theApp.m_hThreadCalculating )
	{
		Sleep ( 200 );
	}

	while ( theApp.m_hThreadInteracting )
	{
		Sleep ( 200 );
	}

	CMDIFrameWndEx::OnClose();
}

void CMainFrame::switchGUI ( CDocRollLib* pDoc )
{
	m_wndOutput.UpdateDBMessages ( pDoc );
}


//-----------------------------begin yangfan 2016_5_10
void CMainFrame::switchGUI ( CDocOrder* pDoc )
{
	m_wndOutput.UpdateDBMessages ( pDoc );
}
//-----------------------------end   yangfan 2016_5_10


void CMainFrame::CloseView ( CDocTemplate* pTemplate, CRuntimeClass* pViewClass )
{
	CMDIChildWnd * pMDIActive	= MDIGetActive();
	if(!pMDIActive)
		return;
	CDocument * pDoc	= pMDIActive->GetActiveDocument();
	CView * pView;

	POSITION pos	= pDoc->GetFirstViewPosition();
	while( pos != NULL )
	{
		pView	= pDoc->GetNextView( pos );
		if( pView->IsKindOf( pViewClass ) )
		{
			// close the parent frame
			pView->GetParentFrame()->ActivateFrame();
			pView->GetParentFrame()->ShowWindow(SW_HIDE);//PostMessage(WM_CLOSE);
			return;
		}
	}
}

void CMainFrame::SwitchToView ( CDocTemplate* pTemplate, CRuntimeClass* pViewClass )
{
	CMDIChildWnd * pMDIActive	= MDIGetActive();
	if(!pMDIActive)
		return;

	CDocument * pDoc	= pMDIActive->GetActiveDocument();
	CView * pView;

	POSITION pos	= pDoc->GetFirstViewPosition();
	while( pos != NULL )
	{
		pView	= pDoc->GetNextView( pos );
		if( pView->IsKindOf( pViewClass ) )
		{
			// the requested view class has already been created; show it
			pView->GetParentFrame()->ActivateFrame();
			return;
		}
	}

	// The requested view hasn't been created yet
	CMDIChildWnd * pNewFrame	= (CMDIChildWnd *)
		pTemplate->CreateNewFrame( pDoc, NULL );

	if( pNewFrame == NULL )
		return;

	pTemplate->InitialUpdateFrame( pNewFrame, pDoc );
}

BOOL CMainFrame::switch2RollLibView ( BOOL bLast )
{
	POSITION		pos;
	CDocRollLib*	pDoc;
	CView *			pView;

	pos	= theApp.m_pLibTemplate->GetFirstDocPosition ( );

	if ( NULL == pos )
	{
		if ( bLast )
			pDoc	= (CDocRollLib*)theApp.m_pLibTemplate->OpenDocumentFile ( NULL );
		else
			return	FALSE;
	}
	else
	{
		CMDIChildWnd * pMDIActive	= MDIGetActive();
		if ( !pMDIActive )
			return	FALSE;

		pDoc	= (CDocRollLib*)theApp.m_pLibTemplate->GetNextDoc ( pos );
	}

	if ( bLast )
	{
		pDoc->OnBtnDbQuery ( );
		pDoc->OnBtnDbLast ( );
	}

	pos	= pDoc->GetFirstViewPosition ( );
	while ( pos != NULL )
	{
		pView	= pDoc->GetNextView( pos );
		if( pView->IsKindOf( RUNTIME_CLASS(CViewRollLib) ) )
		{
			// the requested view class has already been created; show it
			pView->GetParentFrame()->ActivateFrame();

			switchGUI ( pDoc );
			return	TRUE;
		}
	}

	return	FALSE;
}

//----------------------------------------begin yangfan 2016_5_10
BOOL CMainFrame::switch2DocOrderView ( BOOL bLast )
{
	POSITION		pos;
	CDocOrder*	    pDoc;
	CView *			pView;

	pos	= theApp.m_pOrderTemplate->GetFirstDocPosition ( );

	if ( NULL == pos )
	{
		if ( bLast )
			pDoc	= (CDocOrder*)theApp.m_pOrderTemplate->OpenDocumentFile ( NULL );
		else
			return	FALSE;
	}
	else
	{
		CMDIChildWnd * pMDIActive	= MDIGetActive();
		if ( !pMDIActive )
			return	FALSE;

		pDoc	= (CDocOrder*)theApp.m_pOrderTemplate->GetNextDoc ( pos );
	}

	if ( bLast )
	{
		//*****************************************************��Ҫ��д����ķ���
		//---------------------------begin yangfan 2016_5_10
		//pDoc->OnBtnDbQuery ( );
		  pDoc->OnBtnOrderQuery();
		//pDoc->OnBtnDbLast ( );
		  pDoc->OnDbOrderLast();
		//---------------------------end   yangfan 2016_5_10

	}

	pos	= pDoc->GetFirstViewPosition ( );
	while ( pos != NULL )
	{
		pView	= pDoc->GetNextView( pos );
		if( pView->IsKindOf( RUNTIME_CLASS(CViewOrder) ) )
		{
			// the requested view class has already been created; show it
			pView->GetParentFrame()->ActivateFrame();

			switchGUI ( pDoc );
			return	TRUE;
		}
	}

	return	FALSE;
}
//----------------------------------------end   yanffan 2016_5_10


//----------------------------------------begin yangfan 2016_4_29
void CMainFrame::OnBtnNewcustomer()
{
	// TODO: �ڴ�����������������
	CNewCustomer DlgNewCus;
	if ( IDOK != DlgNewCus.DoModal() )
		return;
}
//----------------------------------------end  yangfan 2016_4_29

//----------------------------------------begin  yangfan 2016_4_29
/*
void CMainFrame::OnBtnOrderQuery()
{
	// TODO: �ڴ�����������������
	//updateBtnOrderQuery = false;
	//m_wndTabs.SetActiveTab ( 0 );

	CString		strMsg;
	strMsg.Format( _T("���ڲ�ѯ�������ݿ⣬���Ժ�...") );
	outputString ( strMsg );
	m_ResultIndent = indent_yf::QueryIndent();
	m_nNumberIndent = (int)m_ResultIndent.size();
	//refreshProperty ( );
	return;
}

void CMainFrame::OnUpdateBtnOrderQuery(CCmdUI *pCmdUI)
{
	// TODO: �ڴ�������������û����洦���������
	//pCmdUI->Enable( updateBtnOrderQuery );
}
*/
//----------------------------------------end  yangfan 2016_4_29
