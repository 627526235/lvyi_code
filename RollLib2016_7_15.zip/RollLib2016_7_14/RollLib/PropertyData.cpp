#include "StdAfx.h"
#include "PropertyData.h"


void CPropertyData::addItem ( )
{
}

void CPropertyData::addItem ( LPPROPERTY_DATA_ITEM pItem )
{
	if ( NULL == m_pHeadList )
	{
		m_pHeadList	= pItem;
		m_pTailList	= pItem;
		return;
	}

	ASSERT ( NULL == pItem->pNext );

	m_pTailList->pNext	= pItem;
	//-------------------------------------------begin yangfan 2016_3_24
	m_pTailList = pItem;
	//-------------------------------------------end   yangfan 2016_3_24
}


LPPROPERTY_DATA_ITEM CPropertyData::addItem ( CString strName, CString strValue, LPCTSTR lpszDescr )
{
	LPPROPERTY_DATA_ITEM	pItem;

	pItem	= new CPropertyDataItem ( strName, (_variant_t)strValue, lpszDescr );

	addItem ( pItem );

	return	pItem;
}

LPPROPERTY_DATA_ITEM CPropertyData::addItem ( CString strName )
{
	LPPROPERTY_DATA_ITEM	pItem;

	pItem	= new CPropertyDataItem ( strName, 0L, NULL );

	addItem ( pItem );

	return	pItem;
}

CPropertyData::CPropertyData ( )
{
	m_pHeadList	= NULL;
	m_pTailList	= NULL;
}


CPropertyData::~CPropertyData ( )
{
	LPPROPERTY_DATA_ITEM	pItem;

	pItem	= m_pHeadList;
	while ( pItem )
	{
		m_pHeadList	= pItem->pNext;

		delete	pItem;

		pItem	= m_pHeadList;
	}
}

LPPROPERTY_DATA CPropertyData::makeDataCopy ( LPPROPERTY_DATA pData_src )
{
	LPPROPERTY_DATA			pData_cpy;
	LPPROPERTY_DATA_ITEM	pItem, pItem_next;
	LPPROPERTY_DATA_ITEM	pItem_new;

	if ( NULL == pData_src )
		return	NULL;

	pData_cpy	= new PROPERTY_DATA;

	pItem	= pData_src->m_pHeadList;
	while ( pItem )
	{
		pItem_next	= pItem->pNext;

		pItem_new	= new CPropertyDataItem ( pItem );

		pData_cpy->addItem ( pItem_new );

		pItem	= pItem_next;
	}

	return	pData_cpy;
}

void CPropertyData::copyBindingInfo ( LPPROPERTY_DATA pData_init )
{
	LPPROPERTY_DATA_ITEM	pItem, pInit;
	LPPROPERTY_DATA_ITEM	pItem_next, pInit_next;

	pInit	= pData_init->m_pHeadList;
	pItem	= this->m_pHeadList;
	while ( pItem )
	{
		pItem_next	= pItem->pNext;
		pInit_next	= pInit->pNext;

		pItem->copyItemBindingInfo ( pInit );

		pItem	= pItem_next;
		pInit	= pInit_next;
	}
}