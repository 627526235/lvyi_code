// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// RollDoc.h : CRollDoc ��Ľӿ�
//


#pragma once

#include "DBmySQL.h"
#include "PropertyData.h"

//-----------------------------begin yangfan 2016_7_13
#include"Texture.h"
//-----------------------------end   yangfan 2016_7_13


DECLARE_HANDLE(HDIB);

//enum	typeDoc
//{
//	DOCTYPE_UNTYPED			= -1,
//	DOCTYPE_LIB_ROLL		= 1,
//	DOCTYPE_LIB_ROLL_VIEW	= 2,
//	DOCTYPE_ORDER			= 3,
//	DOCTYPE_HYBRID			= 8
//};
//
//typedef	typeDoc	DOCTYPE;

class CMFCPropertyGridPropertyEx;

class CRollDoc : public CDocument
{
protected: // �������л�����
	CRollDoc();
	DECLARE_DYNCREATE(CRollDoc)

protected:
	virtual void	initializePropertyData ( ){}

public:
	virtual void	updatePropertyData ( ){}

	virtual void	onItemChanged ( LPPROPERTY_DATA_ITEM pItem, CMFCPropertyGridPropertyEx* pProp ){m_bDirty=true;}

// ����
public:

	//--------------------------------------------begin yangfan 2016_7_13
	LPTEXTURE_FEATURE	m_pFeature;
	CTexture *	m_pTexture;
	//--------------------------------------------end   yangfan 2016_7_13

	CPropertyData	m_dataProperty;

	bool	m_bDirty;

	LPPROPERTY_DATA	getData ( ){return &m_dataProperty;}

	CImage*		m_pImage;
	CString		m_strPath;
	int			m_iLength;

	long		m_lHeight;
	long		m_lWidth;
	DWORD		m_dwWidthBytes;
	DWORD		m_dwBitBytes;

	vector<picRoll*>	 m_Result;

	char		m_strQueryCmd [256];
	MYSQL_RES*	m_pResult;
	int			m_nNumRes;
	int			m_nCurrent;
	int			m_iIndex;

	bool	m_bDoneCalculating;
	bool	m_bCalculating;
	vector<double>*	feature_result;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//	color separation
	CImage*		m_pImage_1;	// separated color
	CImage*		m_pImage_2;	// separated color
	CImage*		m_pImage_3;	// separated color
	CImage*		m_pGray;	// gray image

	//CBitmap*	m_pBmp_1;
	//CBitmap*	m_pBmp_2;
	//CBitmap*	m_pBmp_3;

	LPBITMAPINFO	m_lpbiImage_1;
	LPBITMAPINFO	m_lpbiImage_2;
	LPBITMAPINFO	m_lpbiImage_3;
	LPBITMAPINFO	m_lpbiGray;

	RGBQUAD		m_rgbColor_1[256];
	RGBQUAD		m_rgbColor_2[256];
	RGBQUAD		m_rgbColor_3[256];
	RGBQUAD		m_rgbGray[256];

	void	generateHeaders ( );
	void	calculateFeatures ( );
//--------------------------------------------------------------------

	// stored in table rollInfo
	char		m_lpszCustomer [64];


// ����
public:
	CImage*	getSeparated_1 ( );
	CImage*	getSeparated_2 ( );
	CImage*	getSeparated_3 ( );

	CImage*	extractImage_1 ( CImage* pImageSrc, CDC* pDC );

	void	outputString ( CString strMsg, int iKind=0);

	void	refreshProperty ( );

// ��д
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// ʵ��
public:
	virtual ~CRollDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	bool	m_bNewDoc;	// for surf the database
	bool	m_bQuery;	// query finished or not

	void	loadRollFile ( LPCTSTR lpszPathName );
	void	loadRollFile ( IStream* pStream );

// ���ɵ���Ϣӳ�亯��
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// ����Ϊ�����������������������ݵ� Helper ����
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
public:
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	afx_msg void OnBtnDbInsert();
	virtual void SetTitle(LPCTSTR lpszTitle);
	afx_msg void OnUpdateBtnDbInsert(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbFirst();
	afx_msg void OnUpdateBtnDbFirst(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbLast();
	afx_msg void OnUpdateBtnDbLast(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbPrev();
	afx_msg void OnUpdateBtnDbPrev(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbDel();
	afx_msg void OnUpdateBtnDbDel(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbNext();
	afx_msg void OnUpdateBtnDbNext(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbQuery();
	afx_msg void OnUpdateBtnDbQuery(CCmdUI *pCmdUI);
	afx_msg void OnChkDouble();
	afx_msg void OnUpdateChkDouble(CCmdUI *pCmdUI);
	afx_msg void OnChkTrible();
	afx_msg void OnUpdateChkTrible(CCmdUI *pCmdUI);
};
