#include "StdAfx.h"
#include "Texture.h"
#include<math.h>

void CTexture::setData(LPBYTE lpBytes, long lWidth, long lHeight)
{
}

void free(LPTEXTURE_FEATURE pFeature)
{
	LPTEXTURE_FEATURE	pNext;

	while (pFeature)
	{
		pNext = pFeature->pNext;

		delete	pFeature;

		pFeature = pNext;
	}
}

CTexture::CTexture()
{
	m_lpbiGray = NULL;

	m_pGray = NULL;

	m_ppGLCM = NULL;

	m_iGrayLevel = 3;
}


CTexture::~CTexture()
{
	if (m_lpbiGray)
		delete	m_lpbiGray;

	if (m_pGray)
		delete	m_pGray;

	if (m_ppGLCM)
	{
		int		i;
		int		iMax;

		iMax = 1 << m_iGrayLevel;

		for (i = 0; i<iMax; i++)
		{
			delete	m_ppGLCM[i];
		}

		delete	m_ppGLCM;
	}
}

CImage* CTexture::converToGray(CImage* pImage, LPBYTE* ppvBits)
{
	CDC			memDC;
	HDC			hDC;
	CDC*		pDC;
	HBITMAP		hBitmap, hOld;
	CImage*		pGray;


	hDC = pImage->GetDC();
	pDC = CDC::FromHandle(hDC);

	memDC.DeleteDC();
	memDC.CreateCompatibleDC(pDC);

	// m_pGray
	hBitmap = CreateDIBSection(hDC, m_lpbiGray, DIB_RGB_COLORS, (void**)ppvBits, NULL, 0);

	hOld = (HBITMAP)memDC.SelectObject(hBitmap);

	//
	pImage->BitBlt(memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY);

	GdiFlush();
	memDC.SelectObject(hOld);

	if (m_pGray)
		delete	m_pGray;

	pGray = new CImage;
	pGray->Attach(hBitmap);

	pImage->ReleaseDC();

	return	pGray;
}

void CTexture::generateHeader(BYTE  yGrayLevel)
{
	int		i;
	DWORD	dwHeaderSize;
	char*	pBuffer;

	ASSERT(m_lHeight);
	ASSERT(m_lWidth);

	if (m_lpbiGray)
		delete	m_lpbiGray;

	m_lWidthBytes = ((m_lWidth + 3) >> 2) << 2;
	m_lBitBytes = m_lWidthBytes * (DWORD)m_lHeight;

	dwHeaderSize = sizeof(BITMAPINFOHEADER) + (sizeof(RGBQUAD) << 8);
	pBuffer = new char[dwHeaderSize];

	m_lpbiGray = (LPBITMAPINFO)pBuffer;

	m_lpbiGray->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	m_lpbiGray->bmiHeader.biWidth = m_lWidth;
	m_lpbiGray->bmiHeader.biHeight = m_lHeight;
	m_lpbiGray->bmiHeader.biPlanes = 1;
	m_lpbiGray->bmiHeader.biBitCount = 8;
	m_lpbiGray->bmiHeader.biSizeImage = m_lBitBytes;
	m_lpbiGray->bmiHeader.biCompression = BI_RGB;
	m_lpbiGray->bmiHeader.biXPelsPerMeter = 0;
	m_lpbiGray->bmiHeader.biYPelsPerMeter = 0;
	m_lpbiGray->bmiHeader.biClrUsed = 256;
	m_lpbiGray->bmiHeader.biClrImportant = 0;


	//memcpy ( m_lpbiGray, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );

	m_iGrayLevel = 3;

	if (8 == yGrayLevel)
	{
		for (i = 0; i < 8; i++)
		{
			m_lpbiGray->bmiColors[i].rgbBlue = i * 32;
			m_lpbiGray->bmiColors[i].rgbGreen = i * 32;
			m_lpbiGray->bmiColors[i].rgbRed = i * 32;
			m_lpbiGray->bmiColors[i].rgbReserved = 0;
		}

		for (; i < 256; i++)
		{
			m_lpbiGray->bmiColors[i].rgbBlue = 0;
			m_lpbiGray->bmiColors[i].rgbGreen = 0;
			m_lpbiGray->bmiColors[i].rgbRed = 0;
			m_lpbiGray->bmiColors[i].rgbReserved = 0;
		}
	}
}

LPTEXTURE_FEATURE CTexture::computingFeatures(CImage* pImage)
{
	LPBYTE	lpBits;
	BYTE	yGrayLevel;

	yGrayLevel = 8;

	m_lWidth = pImage->GetWidth();
	m_lHeight = pImage->GetHeight();


	m_lWidthBytes = 0;
	generateHeader(yGrayLevel);
	ASSERT(0 != m_lWidthBytes);	// make sure that m_lWidthBytes is computed in the function generateHeader ( ... )

	m_pGray = converToGray(pImage, &lpBits);
	m_pGray->Save(CString(_T("test_yf.bmp")));

	// 
	return	computingFeatures(lpBits, yGrayLevel, 3, 0, 0, 256, 512);
}

LPTEXTURE_FEATURE CTexture::computingFeatures(LPBYTE lpBits, BYTE yGrayLevel, int iDistance, int x, int y, int iWidth, int iHeight)
{
	BYTE	yLoop;
	int		i, j, iMax, jMax;
	int*	lpiRow;
	LPBYTE	lpRow_current, lpCurrent, lpShift;

	// initialization
	m_ppGLCM = new int*[yGrayLevel];
	for (yLoop = 0; yLoop<yGrayLevel; yLoop++)
	{
		lpiRow = new int[yGrayLevel];

		for (int i = 0; i<yGrayLevel; i++)
		{
			lpiRow[i] = 0;
		}

		m_ppGLCM[yLoop] = lpiRow;
	}

	// set the value of gray level co-occurrence matrix
	iMax = x + iWidth;
	if (iMax > m_lWidth)
		iMax = m_lWidth;
	jMax = y + iDistance + iHeight;
	if (jMax > m_lHeight)
		jMax = m_lHeight;
	jMax = jMax - iDistance;

	lpRow_current = lpBits + (m_lHeight - y)*m_lWidthBytes;
	for (j = y; j<jMax; j++)
	{
		lpRow_current -= m_lWidthBytes;

		lpCurrent = lpRow_current + x;
		lpShift = lpCurrent + iDistance;
		for (i = x; i<iMax; i++)
		{
			m_ppGLCM[*lpCurrent][*lpShift]++;
			m_ppGLCM[*lpShift][*lpCurrent]++;

			lpCurrent++;
			lpShift++;
		}
	}

	return	ComputeFeature(m_ppGLCM, yGrayLevel);
}


////////////////////////////////////////////////////////////////////////////////////
//�������ܣ�������������
//������
//      pMatrix�����־���
//      dim�����־����ά��
///////////////////////////////////////////////////////////////////////////////////
LPTEXTURE_FEATURE CTexture::ComputeFeature(int** pMatrix, int dim)
{
	int					i, j;
	double **			pdMatrix;
	LPTEXTURE_FEATURE	pFeature;
	double	dEnergy;
	double	dEntropy;
	double	dInertiaQuadrature;
	double	dLocalCalm;
	double	dCorrelation;

	pdMatrix = new double*[dim];
	for (i = 0; i<dim; i++)
		pdMatrix[i] = new double[dim];

	int total = 0;
	for (i = 0; i<dim; i++)
	{
		for (j = 0; j<dim; j++)
		{
			total += pMatrix[i][j];
		}
	}

	for (i = 0; i<dim; i++)
	{
		for (j = 0; j<dim; j++)
		{
			pdMatrix[i][j] = (double)pMatrix[i][j] / (double)total;
		}
	}

	pFeature = new TEXTURE_FEATURE;

	//	the following line is moved to constructor
	//	pFeature->pNext	= NULL;

	dEnergy = 0.0;
	dEntropy = 0.0;
	dInertiaQuadrature = 0.0;
	dLocalCalm = 0.0;

	//�����������ء����Ծء��ֲ�ƽ��
	for (i = 0; i<dim; i++)
	{
		for (j = 0; j<dim; j++)
		{
			// ����
			dEnergy += pdMatrix[i][j] * pdMatrix[i][j];

			// ��
			if (pdMatrix[i][j]>1e-12)
			{
				dEntropy -= pdMatrix[i][j] * log(pdMatrix[i][j]);
			}

			// ���Ծ�(�Աȶ�)
			dInertiaQuadrature += (double)(i - j)*(double)(i - j)*pdMatrix[i][j];

			// �ֲ�ƽ��(����)
			dLocalCalm += pdMatrix[i][j] / (1 + (double)(i - j)*(double)(i - j));
		}
	}

	//����ux
	double ux = 0.0;
	double localtotal = 0.0;
	for (i = 0; i<dim; i++)
	{
		localtotal = 0.0;
		for (j = 0; j<dim; j++)
		{
			localtotal += pdMatrix[i][j];
		}
		ux += (double)i * localtotal;
	}
	//-------------------------------------begin yangfan 2016_5_29
	//cout<<"begin----"<<"ux="<<ux<<"----";
	//-------------------------------------end   yangfan 2016_5_29

	//����uy
	double uy = 0.0;
	for (j = 0; j<dim; j++)
	{
		localtotal = 0.0;
		for (i = 0; i<dim; i++)
		{
			localtotal += pdMatrix[i][j];
		}
		uy += (double)j * localtotal;
	}
	//-------------------------------------begin yangfan 2016_5_29
	//cout<<"   ----"<<"uy="<<uy<<"----";
	//-------------------------------------end   yangfan 2016_5_29


	//����sigmax
	double sigmax = 0.0;
	for (i = 0; i<dim; i++)
	{
		localtotal = 0.0;
		for (j = 0; j<dim; j++)
		{
			localtotal += pdMatrix[i][j];
		}
		sigmax += (double)(i - ux) * (double)(i - ux) * localtotal;
	}
	//-------------------------------------begin yangfan 2016_5_29
	//cout<<"   ----"<<"sigmax="<<sigmax<<"----";
	//-------------------------------------end   yangfan 2016_5_29


	//����sigmay
	double sigmay = 0.0;
	for (j = 0; j<dim; j++)
	{
		localtotal = 0.0;
		for (i = 0; i<dim; i++)
		{
			localtotal += pdMatrix[i][j];
		}
		sigmay += (double)(j - uy) * (double)(j - uy) * localtotal;
	}
	//-------------------------------------begin yangfan 2016_5_29
	//cout<<"   ----"<<"sigmay="<<sigmay<<"----";
	//-------------------------------------end   yangfan 2016_5_29



	//�������
	dCorrelation = 0.0;
	for (i = 0; i<dim; i++)
	{
		for (j = 0; j<dim; j++)
		{
			dCorrelation += (double)(i - ux) * (double)(j - uy) * pdMatrix[i][j];
		}
	}
	//-------------------------------------begin yangfan 2016_5_29
	//cout<<"   ----"<<"FeatureCorrelation="<<FeatureCorrelation<<"----@@@@++++end.";
	//-------------------------------------end   yangfan 2016_5_29

	//-------------------------------------begin yangfan 2016_5_29
	dCorrelation /= sigmax;
	//cout<<"    FeatureCorrelation /= sigmax: "<<FeatureCorrelation<<",";
	//-------------------------------------end   yangfan 2016_5_29

	//-------------------------------------begin yangfan 2016_5_29
	dCorrelation /= sigmay;
	//cout<<"    FeatureCorrelation /= sigmay: "<<FeatureCorrelation<<".     "<<endl;
	//-------------------------------------end   yangfan 2016_5_29

	//-----------------------------begin yangfan 2016_7_13
	pFeature->lWidth  =	m_lWidth;
	pFeature->lHeight = m_lHeight;
	pFeature->iDistance = 3;
	pFeature->iX = 0;
	pFeature->iY = 0;
	//-----------------------------end  yanfgan 2016_7_13


	pFeature->fEnergy = (float)dEnergy;
	pFeature->fEntropy = (float)dEntropy;
	pFeature->fInertiaQuadrature = (float)dInertiaQuadrature;
	pFeature->fLocalCalm = (float)dLocalCalm;
	pFeature->fCorrelation = (float)dCorrelation;

	for (i = 0; i<dim; i++)
		delete	pdMatrix[i];
	delete	pdMatrix;

	return	pFeature;
}