

#include "stdafx.h"

#include "PropertiesWnd.h"
#include "DocOrder.h"

void CPropertiesWnd::updateProperties ( CDocOrder* pDoc, bool bOnlyShow )
{
	if ( NULL== pDoc )
		return;

	m_iStatus	= 1;

	m_pDocCurrent	= pDoc;

	//-----------------------------------------begin yangfan 2016_4_23
	pDoc->updatePropertyData ( );
	//-----------------------------------------end   yangfan 2016_4_23


	m_wndPropListLib.ShowWindow ( SW_HIDE );
	m_wndPropListRoll.ShowWindow ( SW_HIDE );
	m_wndPropListOrder.ShowWindow ( SW_SHOW );
	if ( bOnlyShow )
		return;

	m_wndPropListOrder.RemoveAll ( );
//	UpdateWindow ( );

	CString	strIndex;

	strIndex.Format ( _T("��ţ�") );
	CMFCPropertyGridPropertyEx* pGroup0 = new CMFCPropertyGridPropertyEx( strIndex );
	m_wndPropListRoll.AddProperty ( pGroup0 );

	CMFCPropertyGridPropertyEx* pGroup1 = new CMFCPropertyGridPropertyEx(_T("Orderʱ��"));

	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("ѹ����"), (_variant_t) false, _T("ѹ�������")));

	CMFCPropertyGridProperty* pProp = new CMFCPropertyGridProperty(_T("ѹ����"), _T("��۴�С"), _T("����֮һ:��ϸ�������С�����������δ���ࡱ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("ϸ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("δ����"));
	pProp->AllowEdit(FALSE);
	pGroup1->AddSubItem(pProp);

//	m_pPropManufacturer	= new CMFCPropertyGridProperty(_T("��������"), (_variant_t) pDoc->m_strManufacturer, _T("�༭����") );
	pGroup1->AddSubItem( m_pPropManufacturer );
//	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("��������"), (_variant_t) _T("����"), _T("�༭����")));

	m_wndPropListOrder.AddProperty(pGroup1);

	CMFCPropertyGridPropertyEx* pSize = new CMFCPropertyGridPropertyEx(_T("Orderͼ���С"), 0, TRUE);

	pProp = new CMFCPropertyGridProperty(_T("�߶�"), (_variant_t) 250l, _T("ָ��ͼ��ĸ߶�"));
	pProp->EnableSpinControl(TRUE, 50, 300);
	pSize->AddSubItem(pProp);

	pProp = new CMFCPropertyGridProperty( _T("����"), (_variant_t) 150l, _T("ָ��ͼ��Ŀ���"));
	pProp->EnableSpinControl(TRUE, 50, 200);
	pSize->AddSubItem(pProp);

	m_wndPropListOrder.AddProperty(pSize);


	CMFCPropertyGridPropertyEx* pGroup3 = new CMFCPropertyGridPropertyEx(_T("����"));
	pProp = new CMFCPropertyGridProperty(_T("(����)"), _T("���"));
	pProp->Enable(FALSE);
	pGroup3->AddSubItem(pProp);

	CMFCPropertyGridColorProperty* pColorProp = new CMFCPropertyGridColorProperty(_T("��ɫ"), RGB(210, 192, 254), NULL, _T("ָ��Ĭ�ϵĴ�����ɫ"));
	pColorProp->EnableOtherButton(_T("����..."));
	pColorProp->EnableAutomaticButton(_T("Ĭ��"), ::GetSysColor(COLOR_3DFACE));
	pGroup3->AddSubItem(pColorProp);

	static const TCHAR szFilter[] = _T("ps�ļ�(*.psd)|*.psd|�����ļ�(*.*)|*.*||");
	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("ps�ļ�"), TRUE, _T(""), _T("psd"), 0, szFilter, _T("ָ������ͼ��")));

	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("�洢λ��"), _T("c:\\")));

	m_wndPropListOrder.AddProperty(pGroup3);

	CMFCPropertyGridPropertyEx* pGroup4 = new CMFCPropertyGridPropertyEx(_T("��ṹ"));

	CMFCPropertyGridProperty* pGroup41 = new CMFCPropertyGridProperty(_T("��һ���Ӽ�"));
	pGroup4->AddSubItem(pGroup41);

	CMFCPropertyGridProperty* pGroup411 = new CMFCPropertyGridProperty(_T("�ڶ����Ӽ�"));
	pGroup41->AddSubItem(pGroup411);
//	pGroup41->SetValue (

	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 1"), (_variant_t) _T("ֵ 1"), _T("��Ϊ˵��")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 2"), (_variant_t) _T("ֵ 2"), _T("��Ϊ˵��")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("�� 3"), (_variant_t) _T("ֵ 3"), _T("��Ϊ˵��")));

	pGroup4->Expand(FALSE);
	m_wndPropListOrder.AddProperty(pGroup4);


	CMFCPropertyGridPropertyEx* pGroup5 = new CMFCPropertyGridPropertyEx(_T("����"));

	LOGFONT lf;
	CFont* font = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	font->GetLogFont(&lf);

	lstrcpy(lf.lfFaceName, _T("����, Arial"));

	pGroup5->AddSubItem(new CMFCPropertyGridFontProperty(_T("����"), lf, CF_EFFECTS | CF_SCREENFONTS, _T("ָ�����ڵ�Ĭ������")));
	pGroup5->AddSubItem(new CMFCPropertyGridProperty(_T("ʹ��ϵͳ����"), (_variant_t) true, _T("ָ������ʹ�á�MS Shell Dlg������")));

	pGroup5->Expand(FALSE);
	m_wndPropListOrder.AddProperty(pGroup5);
}


void CPropertiesWnd::InitPropListLib()
{
	return;

	SetPropListFont();

	m_wndPropListLib.EnableHeaderCtrl(FALSE);
	m_wndPropListLib.EnableDescriptionArea();
	m_wndPropListLib.SetVSDotNetLook();
	m_wndPropListLib.MarkModifiedProperties();

	CMFCPropertyGridPropertyEx* pGroup1 = new CMFCPropertyGridPropertyEx(_T("Lib����aaa��Ϣ"));

	pGroup1->AddSubItem(new CMFCPropertyGridProperty(_T("ѹ����"), (_variant_t) false, _T("ѹ�������")));

	CMFCPropertyGridProperty* pProp = new CMFCPropertyGridProperty(_T("ѹ����"), _T("��۴�С"), _T("����֮һ:��ϸ�������С�����������δ���ࡱ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("ϸ"));
	pProp->AddOption(_T("��"));
	pProp->AddOption(_T("δ����"));
	pProp->AllowEdit(FALSE);
	pGroup1->AddSubItem(pProp);

	m_pPropManufacturer	= new CMFCPropertyGridProperty(_T("��������"), (_variant_t) _T("����"), _T("�༭����"));
	pGroup1->AddSubItem( m_pPropManufacturer );

//	COleVariant	varManufacturer;
//	varManufacturer.bstrVal	= _T("���̸���");
//	m_pPropManufacturer->SetValue ( varManufacturer );
//	m_pPropManufacturer->SetName ( _T("���̸���") );

	m_wndPropListLib.AddProperty(pGroup1);

//	m_wndPropListRoll.AddProperty(pGroup1);

	CMFCPropertyGridPropertyEx* pSize = new CMFCPropertyGridPropertyEx(_T("ͼ���С"), 0, TRUE);

	pProp = new CMFCPropertyGridProperty(_T("�߶�"), (_variant_t) 250l, _T("ָ��ͼ��ĸ߶�"));
	pProp->EnableSpinControl(TRUE, 50, 300);
	pSize->AddSubItem(pProp);

	pProp = new CMFCPropertyGridProperty( _T("����"), (_variant_t) 150l, _T("ָ��ͼ��Ŀ���"));
	pProp->EnableSpinControl(TRUE, 50, 200);
	pSize->AddSubItem(pProp);

	m_wndPropListLib.AddProperty(pSize);

	CMFCPropertyGridPropertyEx* pGroup2 = new CMFCPropertyGridPropertyEx(_T("Font"));

	LOGFONT lf;
	CFont* font = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	font->GetLogFont(&lf);

	lstrcpy(lf.lfFaceName, _T("Arial"));

	pGroup2->AddSubItem(new CMFCPropertyGridFontProperty(_T("Font"), lf, CF_EFFECTS | CF_SCREENFONTS, _T("Specifies the default font for the window")));
	pGroup2->AddSubItem(new CMFCPropertyGridProperty(_T("Use System Font"), (_variant_t) true, _T("Specifies that the window uses MS Shell Dlg font")));

	m_wndPropListLib.AddProperty(pGroup2);

	CMFCPropertyGridPropertyEx* pGroup3 = new CMFCPropertyGridPropertyEx(_T("Misc"));
	pProp = new CMFCPropertyGridProperty(_T("(Name)"), _T("Application"));
	pProp->Enable(FALSE);
	pGroup3->AddSubItem(pProp);

	CMFCPropertyGridColorProperty* pColorProp = new CMFCPropertyGridColorProperty(_T("Window Color"), RGB(210, 192, 254), NULL, _T("Specifies the default window color"));
	pColorProp->EnableOtherButton(_T("Other..."));
	pColorProp->EnableAutomaticButton(_T("Default"), ::GetSysColor(COLOR_3DFACE));
	pGroup3->AddSubItem(pColorProp);

	static TCHAR BASED_CODE szFilter[] = _T("Icon Files(*.ico)|*.ico|All Files(*.*)|*.*||");
	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("Icon"), TRUE, _T(""), _T("ico"), 0, szFilter, _T("Specifies the window icon")));

	pGroup3->AddSubItem(new CMFCPropertyGridFileProperty(_T("Folder"), _T("c:\\")));

	m_wndPropListLib.AddProperty(pGroup3);

	CMFCPropertyGridPropertyEx* pGroup4 = new CMFCPropertyGridPropertyEx(_T("Hierarchy"));

	CMFCPropertyGridProperty* pGroup41 = new CMFCPropertyGridProperty(_T("First sub-level"));
	pGroup4->AddSubItem(pGroup41);

	CMFCPropertyGridProperty* pGroup411 = new CMFCPropertyGridProperty(_T("Second sub-level"));
	pGroup41->AddSubItem(pGroup411);

	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("Item 1"), (_variant_t) _T("Value 1"), _T("This is a description")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("Item 2"), (_variant_t) _T("Value 2"), _T("This is a description")));
	pGroup411->AddSubItem(new CMFCPropertyGridProperty(_T("Item 3"), (_variant_t) _T("Value 3"), _T("This is a description")));

	pGroup4->Expand(FALSE);
	m_wndPropListLib.AddProperty(pGroup4);
}
