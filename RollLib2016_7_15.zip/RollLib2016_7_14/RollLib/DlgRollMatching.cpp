// DlgRollMatching.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "RollLib.h"
#include "DlgRollMatching.h"
#include "afxdialogex.h"

#include "DocOrder.h"

// CDlgRollMatching �Ի���

IMPLEMENT_DYNAMIC(CDlgRollMatching, CDialogEx)

CDlgRollMatching::CDlgRollMatching(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgRollMatching::IDD, pParent)
{
	m_pDoc	= NULL;

	m_iCnt_matchRoll	= 0;
}

CDlgRollMatching::~CDlgRollMatching()
{
}

void CDlgRollMatching::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BTN_0,  m_btnImage_9);
	DDX_Control(pDX, IDC_BTN_8,  m_btnImage_1);
	DDX_Control(pDX, IDC_BTN_9,  m_btnImage_2);
	DDX_Control(pDX, IDC_BTN_10, m_btnImage_3);
	DDX_Control(pDX, IDC_BTN_11, m_btnImage_4);
	DDX_Control(pDX, IDC_BTN_12, m_btnImage_5);
	DDX_Control(pDX, IDC_BTN_13, m_btnImage_6);
	DDX_Control(pDX, IDC_BTN_14, m_btnImage_7);
	DDX_Control(pDX, IDC_BTN_15, m_btnImage_8);
	DDX_Control(pDX, IDC_BTN_16, m_btnImage_0);
	DDX_Control(pDX, IDC_STATIC_TEXT, m_Curtain);
}


BEGIN_MESSAGE_MAP(CDlgRollMatching, CDialogEx)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BTN_0,  &CDlgRollMatching::OnBnClickedBtn0)
	ON_BN_CLICKED(IDC_BTN_8,  &CDlgRollMatching::OnBnClickedBtn1)
	ON_BN_CLICKED(IDC_BTN_9,  &CDlgRollMatching::OnBnClickedBtn2)
	ON_BN_CLICKED(IDC_BTN_10, &CDlgRollMatching::OnBnClickedBtn3)
	ON_BN_CLICKED(IDC_BTN_11, &CDlgRollMatching::OnBnClickedBtn4)
	ON_BN_CLICKED(IDC_BTN_12, &CDlgRollMatching::OnBnClickedBtn5)
	ON_BN_CLICKED(IDC_BTN_13, &CDlgRollMatching::OnBnClickedBtn6)
	ON_BN_CLICKED(IDC_BTN_14, &CDlgRollMatching::OnBnClickedBtn7)
	ON_BN_CLICKED(IDC_BTN_15, &CDlgRollMatching::OnBnClickedBtn8)
	ON_BN_CLICKED(IDC_BTN_16, &CDlgRollMatching::OnBnClickedBtn9)
END_MESSAGE_MAP()


// CDlgRollMatching ��Ϣ��������

BOOL CDlgRollMatching::OnEraseBkgnd(CDC* pDC)
{
	CDialogEx::OnEraseBkgnd(pDC);

	CRect	rcDlg;
	CRect	rcBtn;

	GetWindowRect ( rcDlg );

	if ( NULL == m_pDoc )
	{
		return	FALSE;
	}

	CButtonST*	pBtn;
	CImage*		pImage;
	int			i;

//	match_result	= m_pDoc->match_result;

	for ( i=0; i<m_iCnt_matchRoll; i++ )
	{
		pBtn	= (CButtonST*)GetDlgItem ( IDC_BTN_8 + i );

		pBtn->GetWindowRect ( rcBtn );

		pImage	= match_result->at(i)->mpImage;

		pImage->BitBlt ( pDC->GetSafeHdc(), rcBtn.left-rcDlg.left, rcBtn.top-rcDlg.top,
			rcBtn.Width(), rcBtn.Height(), 0, 0, SRCCOPY );
	}

	return TRUE;
}

void CDlgRollMatching::OnSize(UINT nType, int cx, int cy)
{
	CRect	rcBtn;

	CDialogEx::OnSize(nType, cx, cy);

	cy	= cy - 35;

	if ( cy < 20 )
		cy	= 20;

	if ( NULL != m_btnImage_1.GetSafeHwnd() )
	{
		m_btnImage_0.MoveWindow ( 7, 7, (cx-14)/2, cy/5 );
		m_btnImage_1.MoveWindow ( 7, 14+cy/5, (cx-14)/2, cy/5 );
		m_btnImage_2.MoveWindow ( 7, 21+cy*2/5, (cx-14)/2, cy/5 );
		m_btnImage_3.MoveWindow ( 7, 28+cy*3/5, (cx-14)/2, cy/5 );
		m_btnImage_4.MoveWindow ( 7, 35+cy*4/5, (cx-14)/2, cy/5 );

		m_btnImage_5.MoveWindow ( 10+(cx-14)/2, 14+cy/5,  (cx-14)/2, cy/5 );
		m_btnImage_6.MoveWindow ( 10+(cx-14)/2, 21+cy*2/5, (cx-14)/2, cy/5 );
		m_btnImage_7.MoveWindow ( 10+(cx-14)/2, 28+cy*3/5, (cx-14)/2, cy/5 );
		m_btnImage_8.MoveWindow ( 10+(cx-14)/2, 35+cy*4/5, (cx-14)/2, cy/5 );

		m_Curtain.MoveWindow ( 10+(cx-14)/2, 7, (cx-14)/2, cy/5 );
//		m_Curtain.MoveWindow ( 0, 7, (cx-14)/2, cy/5 );

		m_btnImage_9.MoveWindow ( 0, 0, cx, cy+35 );
	}
}

void CDlgRollMatching::OnBnClickedBtn0()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 30 );
}

void CDlgRollMatching::OnBnClickedBtn1()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 10 );
}

void CDlgRollMatching::OnBnClickedBtn2()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 11 );
}

void CDlgRollMatching::OnBnClickedBtn3()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 12 );
}

void CDlgRollMatching::OnBnClickedBtn4()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 13 );
}

void CDlgRollMatching::OnBnClickedBtn5()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 14 );
}

void CDlgRollMatching::OnBnClickedBtn6()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 15 );
}

void CDlgRollMatching::OnBnClickedBtn7()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 16 );
}

void CDlgRollMatching::OnBnClickedBtn8()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 17 );
}

void CDlgRollMatching::OnBnClickedBtn9()
{
	if ( NULL == m_pDoc )
		return;

//	m_pDoc->setDisplay ( 19 );
}

void CDlgRollMatching::clear ( )
{
	m_pDoc	= NULL;

	m_btnImage_9.ShowWindow ( SW_SHOW );
}

void CDlgRollMatching::updateRollMatches ( CDocOrder* pDoc )
{
	int		i;
	CString	strMessage;

	CButtonST*	pBtn;

	m_pDoc	= pDoc;

	ASSERT ( m_pDoc );

	m_iCnt_matchRoll	= m_pDoc->m_iCnt_matchRoll;

	m_pImage	= m_pDoc->m_pImage;

//	match_result	= m_pDoc->match_result;
	match_result	= m_pDoc->match_roll;

	for ( i=0; i<m_iCnt_matchRoll; i++ )
	{
		pBtn	= (CButtonST*)GetDlgItem ( IDC_BTN_8 + i );

		pBtn->EnableWindow ( );
		pBtn->DrawTransparent ( );
	}

	m_btnImage_9.ShowWindow ( SW_HIDE );

	strMessage.Format ( _T("���ƥ����Ϣ:\r\nƥ�������%d"), m_iCnt_matchRoll );
	m_Curtain.SetWindowTextW ( strMessage );

	RedrawWindow ( );
	Invalidate ( );
	UpdateWindow ( );
}
