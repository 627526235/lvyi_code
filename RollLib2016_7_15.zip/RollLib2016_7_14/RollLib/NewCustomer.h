
#pragma once
#include<string>
using namespace std;

// CNewCustomer �Ի���

class CNewCustomer : public CDialogEx
{
	DECLARE_DYNAMIC(CNewCustomer)

public:
	CNewCustomer(CWnd* pParent = NULL);   // ��׼���캯��
	bool flag;
	virtual ~CNewCustomer();

// �Ի�������
	enum { IDD = IDD_DLG_NEWCUSTOMER };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	//afx_msg void OnBnClickedBtnSave();
	afx_msg void OnBnClickedOk();
};
