



#ifndef	__INFO_ROLL_EX_H__
#define	__INFO_ROLL_EX_H__

#include "DBmySQLEx.h"

typedef class CInfoRoll_ex	INFO_ROLL_EX, *LPINFO_ROLL_EX;

typedef	void (CInfoRoll_ex::*FP_INFO_ROLL_EX)( string );

class CInfoRoll_ex : public infoRoll
{
public:
	void	updateManufacturer ( string strName );
	
	//begin yangfan----------------------------------2016_3_23
	void	 updateCreatetime (string  strTime );
	//end   yangfan----------------------------------2016_3_23

	//begin yangfan----------------------------------2016_3_24
	void	 updateId(string );
	//end   yangfan----------------------------------2016_3_24
	
	

	
	static vector<LPINFO_ROLL_EX>	QueryInfoRoll_ex ( );

public:
	CInfoRoll_ex (string _number="",string _ct="",string _cc="",int _id=-1,int _state=-1){id=_id;state=_state;number=_number;createtime=_ct;manufacturer=_cc;}
	CInfoRoll_ex (int _id, int _state){id=_id;state=_state;}
	~CInfoRoll_ex ( ){}
};

#endif