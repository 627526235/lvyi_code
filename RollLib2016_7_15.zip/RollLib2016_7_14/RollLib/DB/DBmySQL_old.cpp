#include "StdAfx.h"
#include "DBmySQL.h" 
#include <fstream>
#include <sstream>  

LPDB_MYSQL CDBmySQL::m_pDB_mySQL	= NULL;

LPDB_MYSQL CDBmySQL::getDB ( )
{
	if ( NULL != m_pDB_mySQL )
		return	m_pDB_mySQL;

	m_pDB_mySQL	= new DB_MYSQL;

	return	m_pDB_mySQL;
}

CDBmySQL::CDBmySQL ( )
{
	myHost = host;
	myUser = user;
	myPassword = password;
	myDB = db;
	sock = NULL; 
}

CDBmySQL::~CDBmySQL ( )
{
	if(sock)
		mysql_close(sock);
}

bool CDBmySQL::ConnectSQL( )
{
	sock=mysql_init(0); 
	if(sock &&mysql_real_connect(sock,myHost.c_str(),myUser.c_str(),myPassword.c_str(),NULL,3306,NULL,0)) 
	{
		mysql_set_character_set(sock,"GBK"); 
		char CreateDBCmd[128]= {0};
		sprintf_s(CreateDBCmd, "CREATE DATABASE if not exists %s;", myDB.c_str());
		if(mysql_query(sock,CreateDBCmd))
			return false;
		char UseDBCmd[128]= {0};
		sprintf_s(UseDBCmd, "USE %s;", myDB.c_str());
		if(mysql_query(sock,UseDBCmd))
			return false;

		return true;
	}
	else
		return false;
}

MYSQL* CDBmySQL::GetSock( )
{
	return sock;
}

bool infoRoll::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `infoRoll` ("
							"`id` INT(11) NOT NULL AUTO_INCREMENT,"
							"`state` INT(11) NULL DEFAULT NULL,"
							"`number` VARCHAR(16) NULL DEFAULT NULL,"
							"`createtime` VARCHAR(64) NULL DEFAULT NULL,"
							"`manufacturer` VARCHAR(128) NULL DEFAULT NULL,"
							"PRIMARY KEY (`id`)) "
							"ENGINE = InnoDB "
							"DEFAULT CHARACTER SET = utf8 "
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into infoRoll(state,number,createtime,manufacturer) values('%d','%s','%s','%s');", state,number.c_str(),createtime.c_str(),manufacturer.c_str());
	else
		sprintf_s(SaveCmd,"update infoRoll set state = '%d',number = '%s' createtime = '%s' manufacturer = '%s' where id = '%d';", state,number.c_str(),createtime.c_str(),manufacturer.c_str(),id);
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}

vector<infoRoll*> infoRoll::QueryInfoRoll(string key, int value)
{
	vector<infoRoll*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from infoRoll where %s=%d;",key.c_str(),value);
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		infoRoll* pInfoRoll = new infoRoll(row[2],row[3],row[4],atoi(row[0]),atoi(row[1]));
		ans.push_back(pInfoRoll);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

//---------------------------------------------------------------------------------------begin yangfan 2016_3_12
vector<infoRoll*> infoRoll::QueryInfoRoll()
{
	vector<infoRoll*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from infoRoll ");
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		infoRoll* pInfoRoll = new infoRoll(row[2],row[3],row[4],atoi(row[0]),atoi(row[1]));
		ans.push_back(pInfoRoll);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

//---------------------------------------------------------------------------------------end yangfan 2016_3_12

picRoll::picRoll ( CStringA _filePath, int _id_infoRoll )
{
	id			= -1;
	pStream		= NULL;

	filePath	= _filePath;
	filePath.Replace ( "\\", "\\\\" );

	id_infoRoll	= _id_infoRoll;

	data	= LoadData ( );
	if ( NULL == data )
		size	= 0;
}

picRoll::picRoll (  int _id, CStringA _filePath,
					char* _data, unsigned long _size,
					int _id_infoRoll)
					: id(_id), filePath(_filePath), data(_data),
					size(_size), id_infoRoll(_id_infoRoll)
{
	filePath.Replace ( "\\", "\\\\" );
	pStream	= NULL;
}

picRoll::~picRoll ( )
{
	if ( data != NULL )
		free ( data );

	if ( pStream != NULL )
	{
		pStream->Release ( );
		GlobalFree ( hGlobal );
	}
}

bool picRoll::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `picRoll` ("
							"`id` INT(11) NOT NULL AUTO_INCREMENT,"
							"`filePath` VARCHAR(128) NULL DEFAULT NULL,"
							"`data` LONGBLOB NULL DEFAULT NULL,"
							"`id_infoRoll` INT(11) NOT NULL,"
							"PRIMARY KEY (`id`),"
							"INDEX `id_infoRoll_idx` (`id_infoRoll` ASC),"
							"CONSTRAINT `id_infoRoll` "
							"FOREIGN KEY (`id_infoRoll`) "
							"REFERENCES `infoRoll` (`id`) "
							"ON DELETE NO ACTION "
							"ON UPDATE NO ACTION) "
							"ENGINE = InnoDB "
							"DEFAULT CHARACTER SET = utf8 "
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into picRoll(filePath, data, id_infoRoll) values('%s', LOAD_FILE('%s'), '%d');", filePath, filePath, id_infoRoll);
	else
		return false;
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	id = mysql_insert_id( sock );
	return true;
}

bool picRoll::Delete()
{
	if(id==-1)
		return false;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	char DeleteCmd[128] = {0};
	sprintf_s(DeleteCmd, "delete from picRoll where id_infoRoll = %d;",id);
	if(mysql_query(sock,DeleteCmd))
	{
		return false;
	}
	sprintf_s(DeleteCmd, "delete from featureRoll where id_infoRoll = %d;",id);
	if(mysql_query(sock,DeleteCmd))
	{
		return false;
	}
	sprintf_s(DeleteCmd, "delete from infoRoll where id = %d;",id);
	if(mysql_query(sock,DeleteCmd))
	{
		return false;
	}
	id = -1;
	return true;
}

char* picRoll::LoadData( )
{
	FILE * pFile;
	long lSize;
	int result;
	errno_t err;
	/* ��Ҫһ��byte��©�ض��������ļ���ֻ�ܲ��ö����Ʒ�ʽ�� */ 
	err = fopen_s (&pFile, string(filePath).c_str(), "rb" );
	if (err!=0)
	{
		fputs ("File error",stderr);
		return NULL;
	}
	/* ��ȡ�ļ���С */
	fseek (pFile , 0 , SEEK_END);
	lSize = ftell (pFile);
	rewind (pFile);
	size = lSize;

	char* PicInfo = (char*)malloc(size+1);
	memset(PicInfo,0,size+1);
	/* ���ļ�������buffer�� */
	result = int(fread (PicInfo,1,size,pFile));
	if (result != size)
	{
		fclose(pFile);
		return NULL;
	}
	fclose(pFile);
	return PicInfo;
}


IStream* picRoll::GetStream ( )
{
	if ( pStream != NULL )
		return pStream;

	if ( size==0 && id!=-1 )
	{
		if ( !LoadDataFromSQL() )
			return NULL;
	}
	else if ( size == 0 )
		return NULL;

	hGlobal	= GlobalAlloc(GMEM_MOVEABLE,size);

	void* pData	= GlobalLock(hGlobal);
	memcpy ( pData, data, size );
	GlobalUnlock (hGlobal);

	pStream	= NULL;
	if ( CreateStreamOnHGlobal(hGlobal,TRUE,&pStream) != S_OK )
	{
		pStream = NULL;
	}

	return pStream;
}

infoRoll* picRoll::GetRollInfo( )
{
	vector<infoRoll*> ans = infoRoll::QueryInfoRoll("id",id_infoRoll);
	if(ans.size()==0)
		return NULL;
	return ans[0];
}

vector<picRoll*> picRoll::QueryPicRoll ( string key, int value )
{
	vector<picRoll*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from picRoll where %s=%d;",key.c_str(),value);
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		int size = 0;//mysql_fetch_lengths(res)[2];
		//char *buff = (char*)malloc(size+1);
		//memset(buff,0,size+1);
		//memcpy(buff,row[2],size);
		picRoll* pPicRoll = new picRoll(atoi(row[0]),row[1],NULL,size,atoi(row[3])); 
		ans.push_back(pPicRoll);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

void picRoll::FreeData ( )
{
	if(NULL!=data)
		free(data);
	data = NULL;
	if(pStream!=NULL)
	{
		pStream->Release();
		GlobalFree(hGlobal);
	}
	pStream = NULL;
	size = 0;
}

bool picRoll::LoadDataFromSQL()
{
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from picRoll where id=%d;",id);
	if(mysql_query(sock,QueryCmd))
	{
		return false;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
	int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼��
	if(num <1 )
		return false;
	row = mysql_fetch_row( res );
	size = mysql_fetch_lengths(res)[2];
	data = (char*)malloc(size+1);
	memset(data,0,size+1);
	memcpy(data,row[2],size);
	//picRoll* pPicRoll = new picRoll(atoi(row[0]),row[1],NULL,0,atoi(row[3])); 
	mysql_free_result(res); //�ͷŽ����Դ 
	return true;
}

vector<picRoll*> picRoll::QueryPicRoll()
{
	vector<picRoll*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from picRoll;");
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		int size = 0;//mysql_fetch_lengths(res)[2];
		//char *buff = (char*)malloc(size+1);
		//memset(buff,0,size+1);
		//memcpy(buff,row[2],size);
		picRoll* pPicRoll = new picRoll(atoi(row[0]),row[1],NULL,size,atoi(row[3])); 
		ans.push_back(pPicRoll);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

featureRoll::featureRoll(float _f1,float _f2,float _f3,float _f4,float _f5,int _id_infoRoll)
	:id(-1),f1(_f1),f2(_f2),f3(_f3),f4(_f4),
	 f5(_f5),id_infoRoll(_id_infoRoll)
{}
featureRoll::featureRoll(int _id,float _f1,float _f2,float _f3,float _f4,float _f5,int _id_infoRoll)
	:id(_id),f1(_f1),f2(_f2),f3(_f3),f4(_f4),
	 f5(_f5),id_infoRoll(_id_infoRoll)
{}

bool featureRoll::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `featureRoll` ("
							"`id` INT(11) NOT NULL AUTO_INCREMENT,"
							"`f1` FLOAT(11) NULL DEFAULT NULL,"
							"`f2` FLOAT(11) NULL DEFAULT NULL,"
							"`f3` FLOAT(11) NULL DEFAULT NULL,"
							"`f4` FLOAT(11) NULL DEFAULT NULL,"
							"`f5` FLOAT(11) NULL DEFAULT NULL,"
							"`id_infoRoll` INT(11) NOT NULL,"
							"PRIMARY KEY (`id`),"
							"INDEX `id_infoRoll_idx` (`id_infoRoll` ASC),"
							"CONSTRAINT `id_Roll` "
							"FOREIGN KEY (`id_infoRoll`) "
							"REFERENCES `infoRoll` (`id`) "
							"ON DELETE NO ACTION "
							"ON UPDATE NO ACTION) "
							"ENGINE = InnoDB "
							"DEFAULT CHARACTER SET = utf8 "
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into featureRoll(f1, f2, f3, f4, f5, id_infoRoll) values('%.4f','%.4f','%.4f','%.4f','%.4f','%d');", f1,f2,f3,f4,f5,id_infoRoll);
	else
		sprintf_s(SaveCmd,"update featureRoll set f1 = '%.4f',f2 = '%.4f',f3 = '%.4f', f4 = '%.4f',f5 = '%.4f' where id = '%d';", f1,f2,f3,f4,f5,id);
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}

vector<featureRoll*> featureRoll::QueryFeatureRoll(map<string,vector<float> > kv)
{
	vector<featureRoll*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	string QueryCmd = "";
	map<string,vector<float> >::iterator iter = kv.begin();
	for(;iter!=kv.end();++iter)
	{
		string key = iter->first;
		float min = iter->second[0];
		float max = iter->second[1];
		char cmd[128] = {0};
		sprintf_s(cmd,"%s>%.4f AND %s<%.4f",key.c_str(),min,key.c_str(),max);
		if (QueryCmd == "")
			QueryCmd += string(cmd);
		else
			QueryCmd += " AND " + string(cmd); 
	}
	QueryCmd = "select * from featureRoll where " + QueryCmd + ";";
	
	if(mysql_query(sock,QueryCmd.c_str()))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		featureRoll* pFeatureRoll = new featureRoll(atoi(row[0]),atof(row[1]),atof(row[2]),atof(row[3]),atof(row[4]),atof(row[5]),atoi(row[6])); 
		ans.push_back(pFeatureRoll);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

infoCustom::infoCustom(string _name,string _telephone,string _idCard)
	:id(-1), name(_name), telephone(_telephone), idCard(_idCard)
{}
infoCustom::infoCustom(int _id,string _name,string _telephone,string _idCard)
	:id(_id), name(_name), telephone(_telephone), idCard(_idCard)
{}

bool infoCustom::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `infoCustom` ("
							"`id` INT(11) NOT NULL AUTO_INCREMENT,"
							"`name` VARCHAR(45) NULL DEFAULT NULL,"
							"`telephone` VARCHAR(16) NULL DEFAULT NULL,"
							"`idCard` VARCHAR(64) NULL DEFAULT NULL,"
							"PRIMARY KEY (`id`)) "
							"ENGINE = InnoDB "
							"DEFAULT CHARACTER SET = utf8 "
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into infoCustom(name,telephone,idCard) values('%s','%s','%s');", name.c_str(),telephone.c_str(),idCard.c_str());
	else
		sprintf_s(SaveCmd,"update infoCustom set name = '%s',telephone = '%s',idCard = '%s' where id = '%d';", name.c_str(), telephone.c_str(),idCard.c_str(),id);
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}

vector<infoCustom*> infoCustom::QueryInfoCustom(string key, int value)
{
	vector<infoCustom*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from infoCustom where %s=%d;",key.c_str(),value);
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		infoCustom* pInfoCustom = new infoCustom(atoi(row[0]),row[1],row[2],row[3]);
		ans.push_back(pInfoCustom);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

edgeSheet::edgeSheet(CStringA _filePath,float _threshold1,float _threshold2,int _id_infoCustom)
	:id(-1), psdInfo(NULL), jpgInfo(NULL), filePath(_filePath),
	 threshold1(_threshold1), threshold2(_threshold2), id_infoCustom(_id_infoCustom)
{
	filePath.Replace("\\","\\\\");
}
edgeSheet::edgeSheet(int _id,char* _psdInfo, char* _jpgInfo,CStringA _filePath,float _threshold1,float _threshold2,int _id_infoCustom)
	:id(_id), psdInfo(_psdInfo), jpgInfo(_jpgInfo), filePath(_filePath),
	 threshold1(_threshold1), threshold2(_threshold2), id_infoCustom(_id_infoCustom)
{
	filePath.Replace("\\","\\\\");
}
edgeSheet::~edgeSheet()
{
	if(NULL != psdInfo)
		free(psdInfo);
	if(NULL != jpgInfo)
		free(jpgInfo);
}
bool edgeSheet::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `edgeSheet` ("
							"`id` INT(11) NOT NULL AUTO_INCREMENT,"
							"`psdInfo` LONGBLOB NULL DEFAULT NULL,"
							"`jpgInfo` LONGBLOB NULL DEFAULT NULL,"
							"`filePath` VARCHAR(128) NULL DEFAULT NULL,"
							"`threshold1` FLOAT(11) NULL DEFAULT NULL,"
							"`threshold2` FLOAT(11) NULL DEFAULT NULL,"
							"`id_infoCustom` INT(11) NOT NULL,"
							"PRIMARY KEY (`id`),"
							"INDEX `id_Custom_idx` (`id_infoCustom` ASC),"
							"CONSTRAINT `id_infoCustom` "
							"FOREIGN KEY (`id_infoCustom`) "
							"REFERENCES `infoCustom` (`id`) "
							"ON DELETE NO ACTION "
							"ON UPDATE NO ACTION) "
							"ENGINE = InnoDB "
							"DEFAULT CHARACTER SET = utf8 "
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into edgeSheet(psdInfo, jpgInfo, filePath, threshold1, threshold2, id_infoCustom) values(LOAD_FILE('%s'), LOAD_FILE('%s'), '%s', '%.4f', '%.4f', '%d');", filePath, filePath, filePath, threshold1, threshold2, id_infoCustom);
	else
		return false;
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	id = mysql_insert_id( sock );
	return true;
}

vector<edgeSheet*> edgeSheet::QueryEdgeSheet(string key, int value)
{
	vector<edgeSheet*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from edgeSheet where %s=%d;",key.c_str(),value);
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		
		int size1 = mysql_fetch_lengths(res)[1];
		char *img1 = (char*)malloc(size1+1);
		memset(img1,0,size1+1);
		memcpy(img1,row[1],size1);

		int size2 = mysql_fetch_lengths(res)[2];
		char *img2 = (char*)malloc(size2+1);
		memset(img2,0,size2+1);
		memcpy(img2,row[2],size2);

		edgeSheet* pEdgeSheet = new edgeSheet(atoi(row[0]),img1,img2,row[3],atof(row[4]),atof(row[5]),atoi(row[6])); 
		ans.push_back(pEdgeSheet);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

splitImg::splitImg(char* _img1,unsigned long _size1,char* _img2,unsigned long _size2,char* _img3,unsigned long _size3,int _id_edgeSheet)
	: id(-1),img1(_img1),size1(_size1),img2(_img2),size2(_size2),img3(_img3),size3(_size3),id_edgeSheet(_id_edgeSheet)
{}
splitImg::splitImg(int _id,char* _img1,unsigned long _size1,char* _img2,unsigned long _size2,char* _img3,unsigned long _size3,int _id_edgeSheet)
	: id(_id),img1(_img1),size1(_size1),img2(_img2),size2(_size2),img3(_img3),size3(_size3),id_edgeSheet(_id_edgeSheet)
{}
splitImg::~splitImg()
{
	if(img1!=NULL)
	{
		free(img1);
		img1 = NULL;
	}
	if(img2!=NULL)
	{
		free(img2);
		img2 = NULL;
	}
	if(img3!=NULL)
	{
		free(img3);
		img3 = NULL;
	}
}

bool splitImg::Save()
{
	if(id!=-1)
		return false;
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `splitImg` ("
							"`id` INT(11) NOT NULL AUTO_INCREMENT,"
							"`img1` LONGBLOB NOT NULL,"
							"`img2` LONGBLOB NOT NULL,"
							"`img3` LONGBLOB NULL DEFAULT NULL,"
							"`id_edgeSheet` INT(11) NOT NULL,"
							"PRIMARY KEY (`id`),"
							"INDEX `id_edgeSheet_idx` (`id_edgeSheet` ASC),"
							"CONSTRAINT `id_edgeSheet` "
							"FOREIGN KEY (`id_edgeSheet`) "
							"REFERENCES `edgeSheet` (`id`) "
							"ON DELETE NO ACTION "
							"ON UPDATE NO ACTION) "
							"ENGINE = InnoDB "
							"DEFAULT CHARACTER SET = utf8 "
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char *SaveCmd = (char*)malloc(1024+size1*2+size2*2+size3*2);

	int sql_len = 0;

	char *data1 = (char*)malloc(size1*2+2);
	char *data2 = (char*)malloc(size2*2+2);
	char *data3 = (char*)malloc(size3*2+2);
	mysql_real_escape_string(sock,data1,img1,size1);
	mysql_real_escape_string(sock,data2,img2,size2);
	mysql_real_escape_string(sock,data3,img3,size3);
	sql_len = sprintf(SaveCmd, "insert into splitImg(img1, img2, img3, id_edgeSheet) values('%s','%s','%s',%d);", data1,data2,data3,id_edgeSheet);
	
	if(mysql_real_query(sock, SaveCmd, sql_len))
	{
		free(data1);
		free(data2);
		free(data3);
		free(SaveCmd);
		return false;
	}
	/*
	MYSQL_STMT* stmt = mysql_stmt_init(sock);
	if(!stmt)
		return false;
	if(mysql_stmt_prepare(stmt,SaveCmd,strlen(SaveCmd)))
		return false;

	MYSQL_BIND bind[3];
	memset(bind,0,sizeof(bind));
	bind[0].buffer = img1;
	bind[0].buffer_type = MYSQL_TYPE_BLOB;
	bind[0].length = &size1;
	bind[0].is_null = 0;
	bind[1].buffer = img2;
	bind[1].buffer_type = MYSQL_TYPE_LONG_BLOB;
	bind[1].length = &size2;
	bind[1].is_null = 0;
	bind[2].buffer = img3;
	bind[2].buffer_type = MYSQL_TYPE_LONG_BLOB;
	bind[2].length = &size3;
	bind[2].is_null = 0;
	
	if(mysql_stmt_bind_param(stmt, bind))
	{
		string s = mysql_stmt_error(stmt);
		return false;
	}
	if(mysql_stmt_send_long_data(stmt,0,img1,size1))
		return false;
	if(mysql_stmt_send_long_data(stmt,1,img2,size2))
		return false;
	if(mysql_stmt_send_long_data(stmt,2,img3,size3))
		return false;
	if(mysql_stmt_execute(stmt))
	{
		string s = mysql_stmt_error(stmt);
		return false;
	}
	*/

	id = mysql_insert_id( sock );
	free(data1);
	free(data2);
	free(data3);
	free(SaveCmd);
	return true;
}

vector<splitImg*> splitImg::QuerySplitImg(string key,int value)
{
	vector<splitImg*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from splitImg where %s=%d;",key.c_str(),value);
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );

		int size1 = mysql_fetch_lengths(res)[1];
		char *img1 = (char*)malloc(size1+1);
		memset(img1,0,size1+1);
		memcpy(img1,row[1],size1);

		int size2 = mysql_fetch_lengths(res)[2];
		char *img2 = (char*)malloc(size2+1);
		memset(img2,0,size2+1);
		memcpy(img2,row[2],size2);

		int size3 = mysql_fetch_lengths(res)[3];
		char *img3 = (char*)malloc(size3+1);
		memset(img3,0,size3+1);
		memcpy(img3,row[3],size3);

		splitImg* pSplitImg = new splitImg(atoi(row[0]),img1,size1,img2,size2,img3,size3,atoi(row[4])); 
		ans.push_back(pSplitImg);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}
splitData::splitData(float _threshold1,float _threshold2,float _threshold3,float _threshold4,float _threshold5,float _threshold6,int _id_splitImg)
	: id(-1),threshold1(_threshold1),threshold2(_threshold2),threshold3(_threshold3),threshold4(_threshold4),threshold5(_threshold5),
	  threshold6(_threshold6),id_splitImg(_id_splitImg)
{}
splitData::splitData(int _id,float _threshold1,float _threshold2,float _threshold3,float _threshold4,float _threshold5,float _threshold6,int _id_splitImg)
	: id(_id),threshold1(_threshold1),threshold2(_threshold2),threshold3(_threshold3),threshold4(_threshold4),threshold5(_threshold5),
	  threshold6(_threshold6),id_splitImg(_id_splitImg)
{}

bool splitData::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `splitData` ("
							"`id` INT(11) NOT NULL AUTO_INCREMENT,"
							"`threshold1` FLOAT(11) NULL DEFAULT NULL,"
							"`threshold2` FLOAT(11) NULL DEFAULT NULL,"
							"`threshold3` FLOAT(11) NULL DEFAULT NULL,"
							"`threshold4` FLOAT(11) NULL DEFAULT NULL,"
							"`threshold5` FLOAT(11) NULL DEFAULT NULL,"
							"`threshold6` FLOAT(11) NULL DEFAULT NULL,"
							"`id_splitImg` INT(11) NOT NULL,"
							"PRIMARY KEY (`id`),"
							"INDEX `id_splitImg_idx` (`id_splitImg` ASC),"
							"CONSTRAINT `id_splitImg` "
							"FOREIGN KEY (`id_splitImg`) "
							"REFERENCES `splitImg` (`id`) "
							"ON DELETE NO ACTION "
							"ON UPDATE NO ACTION) "
							"ENGINE = InnoDB "
							"DEFAULT CHARACTER SET = utf8 "
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into splitData(threshold1, threshold2, threshold3, threshold4, threshold5, threshold6, id_splitImg) values('%.4f', '%.4f', '%.4f', '%.4f', '%.4f', '%.4f', '%d');",
					threshold1, threshold2, threshold3, threshold4, threshold5, threshold6, id_splitImg);
	else
		sprintf_s(SaveCmd,"update splitData set threshold1 = '%.4f',threshold2 = '%.4f',threshold3 = '%.4f', threshold4 = '%.4f',threshold5 = '%.4f' threshold6 = '%.4f' where id = '%d';", threshold1,threshold2,threshold3,threshold4,threshold5,threshold6,id);

	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}

vector<splitData*> splitData::QuerySplitData(string key,int value)
{
	vector<splitData*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from splitData where %s=%d;",key.c_str(),value);
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		splitData* pSplitData = new splitData(atoi(row[0]),atof(row[1]),atof(row[2]),atof(row[3]),atof(row[4]),atof(row[5]),atof(row[6]),atoi(row[7])); 
		ans.push_back(pSplitData);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

manager::manager(string _name,int _auth)
	: id(-1),name(_name),idCard(""),authority(_auth)
{}
manager::manager(string _name,string _idCard,int _auth)
	: id(-1),name(_name),idCard(_idCard),authority(_auth)
{}
bool manager::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `manager` ("
							"`id` INT(11) NOT NULL AUTO_INCREMENT,"
							"`name` VARCHAR(45) NULL DEFAULT NULL,"
							"`idCard` VARCHAR(64) NULL DEFAULT NULL,"
							"`authority` INT(11) NOT NULL,"
							"PRIMARY KEY (`id`)) "
							"ENGINE = InnoDB "
							"DEFAULT CHARACTER SET = utf8 "
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into manager(name,idCard,authority) values('%s','%s','%d');", name.c_str(),idCard.c_str(),authority);
	else
		sprintf_s(SaveCmd,"update manager set name = '%s',idCard = '%s',authority = '%d' where id = '%d';", name.c_str(), idCard.c_str(),authority,id);
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}

indent::indent(string _number,string _time,int _state,int _id_infoRoll,int _id_edgeSheet,int _id_manager,int _id)
	: id(_id),number(_number),time(_time),state(_state),id_infoRoll(_id_infoRoll),
	  id_edgeSheet(_id_edgeSheet),id_manager(_id_manager)
{}
bool indent::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `indent` ("
							"  `id` INT(11) NOT NULL,"
							"  `number` VARCHAR(16) NULL DEFAULT NULL,"
							"  `time` VARCHAR(45) NULL DEFAULT NULL,"
							"  `state` INT(11) NULL DEFAULT NULL,"
							"  `id_infoRoll` INT(11) NOT NULL,"
							"  `id_edgeSheet` INT(11) NOT NULL,"
							"  `id_manager` INT(11) NOT NULL,"
							"  PRIMARY KEY (`id`),"
							"  INDEX `k1_idx` (`id_infoRoll` ASC),"
							"  INDEX `k2_idx` (`id_edgeSheet` ASC),"
							"  INDEX `k3_idx` (`id_manager` ASC),"
							"  CONSTRAINT `k1`"
							"    FOREIGN KEY (`id_infoRoll`)"
							"    REFERENCES `infoRoll` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION,"
							"  CONSTRAINT `k2`"
							"    FOREIGN KEY (`id_edgeSheet`)"
							"    REFERENCES `edgeSheet` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION,"
							"  CONSTRAINT `k3`"
							"    FOREIGN KEY (`id_manager`)"
							"    REFERENCES `manager` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION)"
							"ENGINE = InnoDB"
							"DEFAULT CHARACTER SET = utf8"
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into indent(number,time,state,id_infoRoll,id_edgeSheet,id_manager) values('%s','%s','%d','%d','%d','%d');", number.c_str(),time.c_str(),state,id_infoRoll,id_edgeSheet,id_manager);
	else
		sprintf_s(SaveCmd,"update indent set number = '%s',time = '%s',state = '%d',id_infoRoll = '%d',id_edgeSheet = '%d',id_manager = '%d' where id = '%d';", number.c_str(), time.c_str(),state,id_infoRoll,id_edgeSheet,id_manager,id);
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}

vector<indent*> indent::QueryIndent()
{
	vector<indent*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from indent;");
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		indent* pIndent = new indent(row[1],row[2],atoi(row[3]),atoi(row[4]),atoi(row[5]),atoi(row[6]),atoi(row[0])); 
		ans.push_back(pIndent);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

RollOrder::RollOrder(string _number,int _state,string _cc,int _id_edgeSheet,int _id_manager,int _id)
	: id(_id),number(_number),state(_state),manufacturer(_cc),id_edgeSheet(_id_edgeSheet),id_manager(_id_manager)
{}
bool RollOrder::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `RollOrder` ("
							"  `id` INT(11) NOT NULL,"
							"  `number` VARCHAR(16) NULL DEFAULT NULL,"
							"  `state` INT(11) NOT NULL,"
							"  `manufacturer` VARCHAR(128) NULL DEFAULT NULL,"
							"  `id_edgeSheet` INT(11) NOT NULL,"
							"  `id_manager` INT(11) NOT NULL,"
							"  PRIMARY KEY (`id`),"
							"  INDEX `k4_idx` (`id_edgeSheet` ASC),"
							"  INDEX `k5_idx` (`id_manager` ASC),"
							"  CONSTRAINT `k4`"
							"    FOREIGN KEY (`id_edgeSheet`)"
							"    REFERENCES `edgeSheet` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION,"
							"  CONSTRAINT `k5`"
							"    FOREIGN KEY (`id_manager`)"
							"    REFERENCES `manager` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION)"
							"ENGINE = InnoDB"
							"DEFAULT CHARACTER SET = utf8"
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into RollOrder(number,state,manufacturer,id_edgeSheet,id_manager) values('%s','%d','%s','%d','%d');", number.c_str(),state,manufacturer,id_edgeSheet,id_manager);
	else
		sprintf_s(SaveCmd,"update RollOrder set number = '%s',state = '%d',manufacturer = '%s',id_edgeSheet = '%d',id_manager = '%d' where id = '%d';", number.c_str(),state,manufacturer,id_edgeSheet,id_manager,id);
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}
vector<RollOrder*> RollOrder::QueryRollOrder()
{
	vector<RollOrder*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from RollOrder;");
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		RollOrder* pRollOrder = new RollOrder(row[1],atoi(row[2]),row[3],atoi(row[4]),atoi(row[5]),atoi(row[0])); 
		ans.push_back(pRollOrder);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

newRollInLib::newRollInLib(string _time,int _id_RollOrder,int _id_infoRoll,int _id_manager,int _id)
	: id(_id),finishtime(_time),id_RollOrder(_id_RollOrder),id_infoRoll(_id_infoRoll),id_manager(_id_manager)
{}
bool newRollInLib::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `newRollOrderInLib` ("
							"  `id` INT(11) NOT NULL,"
							"  `finishtime` VARCHAR(45) NULL DEFAULT NULL,"
							"  `id_RollOrder` INT(11) NOT NULL,"
							"  `id_infoRoll` INT(11) NOT NULL,"
							"  `id_manager` INT(11) NOT NULL,"
							"  PRIMARY KEY (`id`),"
							"  INDEX `k6_idx` (`id_RollOrder` ASC),"
							"  INDEX `k7_idx` (`id_infoRoll` ASC),"
							"  INDEX `k8_idx` (`id_manager` ASC),"
							"  CONSTRAINT `k6`"
							"    FOREIGN KEY (`id_RollOrder`)"
							"    REFERENCES `RollOrder` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION,"
							"  CONSTRAINT `k7`"
							"    FOREIGN KEY (`id_infoRoll`)"
							"    REFERENCES `infoRoll` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION,"
							"  CONSTRAINT `k8`"
							"    FOREIGN KEY (`id_manager`)"
							"    REFERENCES `manager` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION)"
							"ENGINE = InnoDB"
							"DEFAULT CHARACTER SET = utf8"
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into newRollOrderInLib(finishtime,id_RollOrder,id_infoRoll,id_manager) values('%s','%d','%d','%d');", finishtime.c_str(),id_RollOrder,id_infoRoll,id_manager);
	else
		sprintf_s(SaveCmd,"update newRollOrderInLib set finishtime = '%s',id_RollOrder = '%d',id_infoRoll = '%d',id_manager = '%d' where id = '%d';", finishtime.c_str(),id_RollOrder,id_infoRoll,id_manager,id);
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}

outLibInfo::outLibInfo(string _time,int _id_infoRoll,int _id_indent,int _id_manager,int _id)
	: id(_id),outLibTime(_time),id_infoRoll(_id_infoRoll),id_indent(_id_indent),id_manager(_id_manager)
{}
bool outLibInfo::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `outLibInfo` ("
							"  `id` INT(11) NOT NULL,"
							"  `outLibTime` VARCHAR(45) NULL DEFAULT NULL,"
							"  `id_infoRoll` INT(11) NOT NULL,"
							"  `id_indent` INT(11) NOT NULL,"
							"  `id_manager` INT(11) NOT NULL,"
							"  PRIMARY KEY (`id`),"
							"  INDEX `k11_idx` (`id_infoRoll` ASC),"
							"  INDEX `k12_idx` (`id_indent` ASC),"
							"  INDEX `k13_idx` (`id_manager` ASC),"
							"  CONSTRAINT `k11`"
							"    FOREIGN KEY (`id_infoRoll`)"
							"    REFERENCES `infoRoll` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION,"
							"  CONSTRAINT `k12`"
							"    FOREIGN KEY (`id_indent`)"
							"    REFERENCES `indent` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION,"
							"  CONSTRAINT `k13`"
							"    FOREIGN KEY (`id_manager`)"
							"    REFERENCES `manager` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION)"
							"ENGINE = InnoDB"
							"DEFAULT CHARACTER SET = utf8"
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into outLibInfo(outLibTime,id_infoRoll,id_indent,id_manager) values('%s','%d','%d','%d');", outLibTime.c_str(),id_infoRoll,id_indent,id_manager);
	else
		sprintf_s(SaveCmd,"update outLibInfo set outLibTime = '%s',id_infoRoll = '%d',id_indent = '%d',id_manager = '%d' where id = '%d';", outLibTime.c_str(),id_infoRoll,id_indent,id_manager,id);
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}
vector<outLibInfo*> outLibInfo::QueryOutInfo()
{
	vector<outLibInfo*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from outLibInfo;");
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		outLibInfo* pOutLibInfo = new outLibInfo(row[1],atoi(row[2]),atoi(row[3]),atoi(row[4]),atoi(row[0])); 
		ans.push_back(pOutLibInfo);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

inLibInfo::inLibInfo(string _time,int _id_infoRoll,int _id_manager,int _id)
	: id(_id),inLibTime(_time),id_infoRoll(_id_infoRoll),id_manager(_id_manager)
{}
bool inLibInfo::Save()
{
	string CreateTableCmd = "CREATE TABLE IF NOT EXISTS `inLibInfo` ("
							"  `id` INT(11) NOT NULL,"
							"  `inLibTime` VARCHAR(45) NULL DEFAULT NULL,"
							"  `id_infoRoll` INT(11) NOT NULL,"
							"  `id_manager` INT(11) NOT NULL,"
							"  PRIMARY KEY (`id`),"
							"  INDEX `k20_idx` (`id_infoRoll` ASC),"
							"  INDEX `k21_idx` (`id_manager` ASC),"
							"  CONSTRAINT `k20`"
							"    FOREIGN KEY (`id_infoRoll`)"
							"    REFERENCES `infoRoll` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION,"
							"  CONSTRAINT `k21`"
							"    FOREIGN KEY (`id_manager`)"
							"    REFERENCES `mydb`.`manager` (`id`)"
							"    ON DELETE NO ACTION"
							"    ON UPDATE NO ACTION)"
							"ENGINE = InnoDB"
							"DEFAULT CHARACTER SET = utf8"
							"COLLATE = utf8_general_ci;";
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	if(mysql_query(sock,CreateTableCmd.c_str()))
	{
		return false;
	}
	char SaveCmd[1024] = {0};
	if(-1==id)
		sprintf_s(SaveCmd,"insert into inLibInfo(inLibTime,id_infoRoll,id_manager) values('%s','%d','%d');", inLibTime.c_str(),id_infoRoll,id_manager);
	else
		sprintf_s(SaveCmd,"update inLibInfo set inLibTime = '%s',id_infoRoll = '%d',id_manager = '%d' where id = '%d';", inLibTime.c_str(),id_infoRoll,id_manager,id);
	
	if(mysql_query(sock,SaveCmd))
	{
		return false;
	}
	if(-1==id)
		id = mysql_insert_id( sock );
	return true;
}
vector<inLibInfo*> inLibInfo::QueryInLibInfo()
{
	vector<inLibInfo*> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from inLibInfo;");
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		inLibInfo* pInLibInfo = new inLibInfo(row[1],atoi(row[2]),atoi(row[3]),atoi(row[0])); 
		ans.push_back(pInLibInfo);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}

char* Works::doImgSplit(string path, int &size)
{
	FILE * pFile;
    long lSize;
    int result;
	errno_t err;
	/* ��Ҫһ��byte��©�ض��������ļ���ֻ�ܲ��ö����Ʒ�ʽ�� */ 
	err = fopen_s (&pFile, path.c_str(), "rb" );
    if (err!=0)
    {
        fputs ("File error",stderr);
        return 0;
    }
    /* ��ȡ�ļ���С */
    fseek (pFile , 0 , SEEK_END);
    lSize = ftell (pFile);
    rewind (pFile);
	size = lSize;
    
	char *PicInfo = (char*)malloc(size+1);
	memset(PicInfo,0,size+1);
    /* ���ļ�������buffer�� */
    result = int(fread (PicInfo,1,size,pFile));
    if (result != size)
    {
		free(PicInfo);
		fclose(pFile);
        return 0;
    }
	fclose(pFile);
	return PicInfo;
}

RollLib::RollLib(int _id,string _number,string _createtime,string _manufacturer,CStringA _filePath,CImage* pImage)
	: id(_id),number(_number),createtime(_createtime),manufacturer(_manufacturer),filePath(_filePath),mpImage(pImage)
{}
RollLib::~RollLib()
{
	if(mpImage!=NULL)
		delete mpImage;
}

map<string,vector<float> > Works::ThresholdToFeature(float threshold1, float threshold2)
{
	map<string,vector<float> > res;
	vector<float> vf1;
	vf1.push_back(1.0);
	vf1.push_back(10.0);
	res.insert(pair<string,vector<float> >("f1",vf1));
	res.insert(pair<string,vector<float> >("f2",vf1));
	res.insert(pair<string,vector<float> >("f3",vf1));
	res.insert(pair<string,vector<float> >("f4",vf1));
	res.insert(pair<string,vector<float> >("f5",vf1));
	return res;
}

vector<CImage*>* Works::QueryImage(vector<double>& f)
{
	vector<picRoll*>* pics = QueryRoll(f,0.1);
	vector<CImage*>* imgs = new vector<CImage*>;
	for(int i=0;i<pics->size();i++)
	{
		CImage* pImage = new CImage;
		pImage->Load(pics->at(i)->GetStream());
		pics->at(i)->FreeData();
		imgs->push_back(pImage);
	}
	return imgs;
}

vector<RollLib*>* Works::QueryRollLibInfo(vector<double>& f,float threshold)
{
	vector<picRoll*>* pics = QueryRoll(f,threshold);
	vector<RollLib*>* rolls = new vector<RollLib*>;
	for(int i=0;i<pics->size();i++)
	{
		CImage* pImage = new CImage;
		pImage->Load(pics->at(i)->GetStream());
		pics->at(i)->FreeData();
		infoRoll* pRollInfo = pics->at(i)->GetRollInfo();
		RollLib* pRollLib = new RollLib(pRollInfo->id,pRollInfo->number,pRollInfo->createtime,pRollInfo->manufacturer,pics->at(i)->filePath,pImage);
		rolls->push_back(pRollLib);
	}
	return rolls;
}

vector<picRoll*>* Works::QueryRoll(vector<double>& f,float threshold)
{
	map<string,vector<float> > thresholds;
	vector<float> f0;
	f0.push_back(f[0]-threshold);
	f0.push_back(f[0]+threshold);
	vector<float> f1;
	f1.push_back(f[1]-threshold);
	f1.push_back(f[1]+threshold);
	vector<float> f2;
	f2.push_back(f[2]-threshold);
	f2.push_back(f[2]+threshold);
	thresholds.insert(pair<string,vector<float> >("f1",f0));
	thresholds.insert(pair<string,vector<float> >("f2",f1));
	thresholds.insert(pair<string,vector<float> >("f3",f2));
	vector<featureRoll*> featureRolls =  featureRoll::QueryFeatureRoll(thresholds);
	vector<picRoll*>* res = new vector<picRoll*>;
	for(int i=0;i<featureRolls.size();i++)
	{
		vector<picRoll*> tmp = picRoll::QueryPicRoll("id_infoRoll",featureRolls[i]->id_infoRoll);
		res->insert(res->end(),tmp.begin(),tmp.end());
	}
	for(int i=0;i<featureRolls.size();i++)
		delete featureRolls[i];

	return res;
}

vector<picRoll*> Works::QueryRoll(float threshold1, float threshold2)
{
	map<string,vector<float> > thresholds = Works::ThresholdToFeature(threshold1, threshold2);
	vector<featureRoll*> featureRolls =  featureRoll::QueryFeatureRoll(thresholds);
	vector<picRoll*> res;
	for(int i=0;i<featureRolls.size();i++)
	{
		vector<picRoll*> tmp = picRoll::QueryPicRoll("id_infoRoll",featureRolls[i]->id_infoRoll);
		res.insert(res.end(),tmp.begin(),tmp.end());
	}
	for(int i=0;i<featureRolls.size();i++)
		delete featureRolls[i];

	return res;
}
void Works::StartWork()
{
	infoCustom* pInfoCustom = new infoCustom("loyoen","15271909936","413026199010029039");
	pInfoCustom->Save();
	edgeSheet* pEdgeSheet = new edgeSheet("C:\\Users\\loyoen\\Desktop\\����\\178.jpg",0.1,0.2,pInfoCustom->id);
	pEdgeSheet->Save();
	
	int size1 = 0, size2 = 0, size3 = 0;
	
	char* img1 = Works::doImgSplit("C:\\Users\\loyoen\\Desktop\\����\\178.jpg",size1);
	char* img2 = Works::doImgSplit("C:\\Users\\loyoen\\Desktop\\����\\178.jpg",size2);
	char* img3 = Works::doImgSplit("C:\\Users\\loyoen\\Desktop\\����\\178.jpg",size3);
	
	splitImg* pSplitImg = new splitImg(img1,size1,img2,size2,img3,size3,pEdgeSheet->id);
	pSplitImg->Save();

	/*
	vector<splitImg*> ans = pSplitImg->QuerySplitImg("id_edgeSheet",pEdgeSheet->id);
	FILE* pFile;
	pFile = fopen("D:\\TEMP.jpg","wb");
	fwrite(ans[0]->img1,1,ans[0]->size1,pFile);
	fclose(pFile);
	*/

	vector<picRoll*> Rolls = Works::QueryRoll(1.0, 10.0);

	splitData* pSplitData = new splitData(1.0,10.0,1.0,10.0,1.0,10.0,pSplitImg->id);
	pSplitData->Save();
	
	delete pInfoCustom;
	delete pEdgeSheet;
	delete pSplitImg;
	delete pSplitData;
	for(int i=0;i<Rolls.size();i++)
		delete Rolls[i];
}
