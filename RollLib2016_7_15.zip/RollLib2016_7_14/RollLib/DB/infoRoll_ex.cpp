
#include "StdAfx.h"
#include "infoRoll_ex.h"

void CInfoRoll_ex::updateManufacturer ( string strManufacturer )
{
	manufacturer	= strManufacturer;
}



vector<LPINFO_ROLL_EX> CInfoRoll_ex::QueryInfoRoll_ex ( )
{
	vector<LPINFO_ROLL_EX> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from infoRoll ");
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		LPINFO_ROLL_EX pInfoRoll = new INFO_ROLL_EX(row[2],row[3],row[4],atoi(row[0]),atoi(row[1]));
		ans.push_back(pInfoRoll);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
}
