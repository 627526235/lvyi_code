#include "StdAfx.h"
#include "DBmySQLEx.h"


CDBmySQLEx::CDBmySQLEx ( )
{
}


CDBmySQLEx::~CDBmySQLEx ( )
{
}
