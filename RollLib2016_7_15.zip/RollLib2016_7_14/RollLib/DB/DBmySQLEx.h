

#ifndef	__DB_MYSQLEX_H__
#define	__DB_MYSQLEX_H__

#include "DBmySQL.h"

typedef class CItem	ITEM, *LPITEM;

class CItem
{
public:
	LPITEM	pNext;
	CString	strTitle;

public:
	CItem ( ){pNext = NULL;}
	~CItem ( ){}
};

class CDBmySQLEx : public CDBmySQL
{
public:
	CDBmySQLEx ( );
	~CDBmySQLEx ( );
};

#endif