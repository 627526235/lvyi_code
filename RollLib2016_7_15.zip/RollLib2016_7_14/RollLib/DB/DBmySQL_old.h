/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
[Module]
	DBmySQL.h
[Description]
	This module encapsulates a global access interface of database mySQL.
[Author]
	jicheng @ whu.edu.cn
[Date]
	2015-10-27

[Revision History]
----------------------------------------------------------------------------------------------------
	When		Who		Where				Description
----------------------------------------------------------------------------------------------------
 2015-10-27	  Jicheng	Wuhan University	Constructed
----------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------*/

#ifndef	__DB_MYSQL_H__
#define __DB_MYSQL_H__
#include<mysql.h>
#include <string>
#include <vector>
#include <map>
#define host "localhost"; 
#define user "root"; 
//#define password "loyoen"; 
#define password "1234"; 
#define db "ROLL6";

typedef	class CDBmySQL	*LPDB_MYSQL, DB_MYSQL;
using namespace std;

class CDBmySQL
{
public:
	static LPDB_MYSQL	getDB ( );
	static LPDB_MYSQL	m_pDB_mySQL;

private:
	MYSQL *sock; 
	string myHost;
	string myUser;
	string myPassword;
	string myDB;

public:
	CDBmySQL ( );
	~CDBmySQL ( );
	MYSQL* GetSock( );
	bool ConnectSQL( );
	
};

class infoRoll
{
public:
	int id;
	string number;
	string createtime;
	string manufacturer;
	int state;
public:
	infoRoll(string _number="",string _ct="",string _cc="",int _id=-1,int _state=-1){id=_id;state=_state;number=_number;createtime=_ct;manufacturer=_cc;}
	infoRoll(int _id, int _state){id=_id;state=_state;}
	~infoRoll(){}
	int getId(){return id;}
	void setState(int _state){state=_state;}
	bool Save();
	static vector<infoRoll*> QueryInfoRoll(string key,int value);

	//---------------------------------------------------------------begin yangfan 2016_3_12
	static vector<infoRoll*> QueryInfoRoll();
	//---------------------------------------------------------------end   yangfan 2016_3_12
};

class picRoll
{
public:
	int				id;
	CStringA		filePath;
	char*			data;
	unsigned long	size;
	int				id_infoRoll;

	char*	LoadData ( );

protected:
	IStream*	pStream;
	HGLOBAL		hGlobal;

public:
	picRoll ( CStringA _filePath, int _id_infoRoll );
	picRoll ( int _id, CStringA _filePath, char* _data, unsigned long _size, int _id_infoRoll );
	~picRoll ( );

	bool		Save ( );
	bool		Delete ( );
	void		FreeData ( );
	bool		LoadDataFromSQL ( );
	IStream*	GetStream ( );
	infoRoll*	GetRollInfo( );
	static vector<picRoll*>	QueryPicRoll ( string key, int value );
	static vector<picRoll*>	QueryPicRoll ( );
};

class featureRoll
{
public:
	int id;
	float f1;
	float f2;
	float f3;
	float f4;
	float f5;
	int id_infoRoll;
public:
	featureRoll(float _f1,float _f2,float _f3,float _f4,float _f5,int _id_infoRoll);
	featureRoll(int _id,float _f1,float _f2,float _f3,float _f4,float _f5,int _id_infoRoll);
	bool Save();
	static vector<featureRoll*> QueryFeatureRoll(map<string,vector<float> > kv);
};

class infoCustom
{
public:
	int id;
	string name;
	string telephone;
	string idCard;
public:
	infoCustom(string _name,string _telephone,string _idCard);
	infoCustom(int _id,string _name,string _telephone,string _idCard);
	bool Save();
	static vector<infoCustom*> QueryInfoCustom(string key,int value);
};

class edgeSheet
{
public:
	int id;
	char* psdInfo;
	char* jpgInfo;
	CStringA filePath;
	float threshold1;
	float threshold2;
	int id_infoCustom;
public:
	edgeSheet(CStringA _filePath,float _threshold1,float _threshold2,int _id_infoCustom);
	edgeSheet(int _id,char* _psdInfo, char* _jpgInfo,CStringA _filePath,float _threshold1,float _threshold2,int _id_infoCustom);
	~edgeSheet();
	bool Save();
	static vector<edgeSheet*> QueryEdgeSheet(string key,int value);
};

class splitImg
{
public:
	int id;
	char* img1;
	unsigned long size1;
	char* img2;
	unsigned long size2;
	char* img3;
	unsigned long size3;
	int id_edgeSheet;
public:
	splitImg(char* _img1,unsigned long _size1,char* _img2,unsigned long _size2,char* _img3,unsigned long _size3,int _id_edgeSheet);
	splitImg(int id,char* _img1,unsigned long _size1,char* _img2,unsigned long _size2,char* _img3,unsigned long _size3,int _id_edgeSheet);
	~splitImg();
	bool Save();
	static vector<splitImg*> QuerySplitImg(string key,int value);
};

class splitData
{
private:
	int id;
	float threshold1;
	float threshold2;
	float threshold3;
	float threshold4;
	float threshold5;
	float threshold6;
	int id_splitImg;
public:
	splitData(float _threshold1,float _threshold2,float _threshold3,float _threshold4,float _threshold5,float _threshold6,int _id_splitImg);
	splitData(int id,float _threshold1,float _threshold2,float _threshold3,float _threshold4,float _threshold5,float _threshold6,int _id_splitImg);
	bool Save();
	static vector<splitData*> QuerySplitData(string key,int value);
};

class manager
{
private:
	int id;
	string name;
	string idCard;
	int authority;
public:
	manager(string _name,int _auth);
	manager(string _name,string _idCard,int _auth);
	bool Save();
	string GetName(){return name;};
	int GetId(){return id;};
};

class indent  //�ڿ�������������� �µ�
{
private:
	int id;
	string number;
	string time;
	int state;
	int id_infoRoll;
	int id_edgeSheet;
	int id_manager;
public:
	indent(string _number,string _time,int _state,int _id_infoRoll,int _id_edgeSheet,int _id_manager,int _id=-1);
	bool Save();
	vector<indent*> QueryIndent();
};

class RollOrder
{
private:
	int id;
	string number;
	int state;
	string manufacturer;
	int id_edgeSheet;
	int id_manager;
public:
	RollOrder(string _number,int _state,string _cc,int _id_edgeSheet,int _id_manager,int _id=-1);
	bool Save();
	vector<RollOrder*> QueryRollOrder();
};

class newRollInLib
{
private:
	int id;
	string finishtime;
	int id_RollOrder;
	int id_infoRoll;
	int id_manager;
public:
	newRollInLib(string _time,int _id_RollOrder,int _id_infoRoll,int _id_manager,int _id=-1);
	bool Save();
};

class outLibInfo
{
private:
	int id;
	string outLibTime;
	int id_infoRoll;
	int id_indent;
	int id_manager;
public:
	outLibInfo(string _time,int _id_infoRoll,int _id_indent,int _id_manager,int _id=-1);
	bool Save();
	vector<outLibInfo*> QueryOutInfo();
};

class inLibInfo
{
private:
	int id;
	string inLibTime;
	int id_infoRoll;
	int id_manager;
public:
	inLibInfo(string _time,int _id_infoRoll,int _id_manager,int _id=-1);
	bool Save();
	vector<inLibInfo*> QueryInLibInfo();
};

class RollLib
{
public:
	int id;
	string number;
	string createtime;
	string manufacturer;
	CStringA filePath;
	CImage* mpImage;
public:
	RollLib(int _id,string _number,string _createtime,string _manufacturer,CStringA _filePath,CImage* pImage);
	~RollLib();
};

class Works
{
private:
	static map<string, vector<float> > ThresholdToFeature(float threshold1,float threshold2);
public:
	static vector<picRoll*>* QueryRoll(vector<double>& f,float threshold);
	static vector<CImage*>* QueryImage(vector<double>& f);
	static vector<RollLib*>* QueryRollLibInfo(vector<double>& f,float threshold);
	static void StartWork();
	static char* doImgSplit(string path, int &size);
	static vector<picRoll*> QueryRoll(float threshold1, float threshold2);
};
#endif	// #ifndef	__DB_MYSQL_H__