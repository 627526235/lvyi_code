#include "StdAfx.h"
#include"Compute.h"

//�������
void CCompute::nrerror(char *error_text)
{
	printf("Numerical Recipes run-time error...\n");
	printf("%s\n",error_text);
	printf("...now exiting to system...\n");
	exit(1);
}

unsigned char**  CCompute::cmatrix ( long nrl,long nrh,long ncl,long nch )
{
	int				i;
	unsigned char**	m;

	m	= (unsigned char **) calloc((unsigned) (nrh-nrl+1),sizeof(unsigned char*));

	if (!m) nrerror("allocation failure 1 in dmatrix()");

	m	-= nrl;

	for ( i=nrl; i<=nrh; i++ )
	{
		m[i]	= (unsigned char *) calloc((unsigned) (nch-ncl+1),sizeof(unsigned char));

		if ( !m[i] ) nrerror("allocation failure 2 in dmatrix()");

		m[i] -= ncl;
	}

	return m;
}

void CCompute::free_cmatrix ( unsigned char** m, long nrl, long nrh, long ncl, long nch )
{
	int				i;
	unsigned char*	lpPtr;

	m	-= nrl;

	for ( i=nrl; i<=nrh; i++ )
	{
		lpPtr	= m[i] + ncl;

		free ( lpPtr );
	}

	free ( m );
}


void CCompute::OpenImage ( CString& FilePathName )
{
	m_grayShow.LoadImage(FilePathName);
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
// 2015_12_11, jicheng, load image from a CImage object, begin
void CCompute::openImage ( CImage* pImage, LPBYTE lpBits )
{
	m_grayShow.loadImage ( pImage, lpBits );
}
// 2015_12_11, jicheng, load image from a CImage object, end
//--------------------------------------------------------------------

vector<double>* CCompute::ComputeFeature()
{
	unsigned char**		arLocalImage;
	double dEnergy			  = 0.0;
	double dEntropy			  = 0.0;
	double dInertiaQuadrature = 0.0;
	double dLocalCalm		  = 0.0;
	double dCorrelation		  = 0.0;
	double dEnergy1			  = 0.0;
	double dEntropy1		  = 0.0;
	double dInertiaQuadrature1= 0.0;
	double dLocalCalm1		  = 0.0;
	double dCorrelation1	  = 0.0;

	int rolltimeH	= m_grayShow.ImageHeight/m_grayShow.FilterWindowWidth;
	int rolltimeW	= m_grayShow.ImageWidth /m_grayShow.FilterWindowWidth;
	int i,j;
	int p,q;

	arLocalImage	= cmatrix ( 0, m_grayShow.FilterWindowWidth-1, 0, m_grayShow.FilterWindowWidth-1 );

	//��ͼ��ֳ����ɸ����ڣ�������������ֵ
	for(i=0; i< rolltimeH; i++)
	{
		for(j=0; j<rolltimeW; j++)
		{
			//���ȸ�ֵ���Ӵ���
			for(p=0; p<m_grayShow.FilterWindowWidth; p++)
			{
				for(q=0; q<m_grayShow.FilterWindowWidth; q++)
				{
					arLocalImage[p][q] = m_grayShow.ImageArray[i*m_grayShow.FilterWindowWidth+p][j*m_grayShow.FilterWindowWidth+q];
				}
			}
			m_grayShow.ComputeMatrix(arLocalImage, m_grayShow.FilterWindowWidth);
			m_grayShow.ComputeFeature(dEnergy1, dEntropy1, dInertiaQuadrature1, dCorrelation1, dLocalCalm1, m_grayShow.PMatrixH, m_grayShow.GrayLayerNum);
			dEnergy              += dEnergy1;
			dEntropy             += dEntropy1;
			dInertiaQuadrature   += dInertiaQuadrature1;
			dCorrelation         += dCorrelation1;
			dLocalCalm           += dLocalCalm1;
		}
	}

	free_cmatrix ( arLocalImage, 0, m_grayShow.FilterWindowWidth-1, 0, m_grayShow.FilterWindowWidth-1 );

	dEnergy              /= (rolltimeH*rolltimeW);
	dEntropy             /= (rolltimeH*rolltimeW);
	dInertiaQuadrature   /= (rolltimeH*rolltimeW);
	dCorrelation         /= (rolltimeH*rolltimeW);
	dLocalCalm           /= (rolltimeH*rolltimeW);
	m_dEnergy			 =  dEnergy;
	m_dEntropy			 =  dEntropy;
	m_dInertiaQuadrature =  dInertiaQuadrature;
	m_dCorrelation		 =  dCorrelation;
	m_dLocalCalm		 =  dLocalCalm;


	//����ȡ��������vector��ʽ����
	vector<double>* Feature	= new vector<double>;

	Feature->push_back(m_dEnergy);
	Feature->push_back(m_dEntropy);
	Feature->push_back(m_dInertiaQuadrature);
	Feature->push_back(m_dCorrelation);
	Feature->push_back(m_dLocalCalm);

	return Feature;
}