// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// DocRollLib.h : CDocRollLib ��Ľӿ�
//


#pragma once


#include "RollDoc.h"
#include "Job.h"


class CDocRollLib : public CRollDoc, CJob
{
	friend class CViewRollLib;

protected: // �������л�����
	CDocRollLib();
	DECLARE_DYNCREATE(CDocRollLib)

protected:
	virtual void	initializePropertyData ( );

public:
	virtual void	updatePropertyData ( );

	virtual void	onItemChanged ( LPPROPERTY_DATA_ITEM pItem, CMFCPropertyGridPropertyEx* pProp );

// ����
public:
//	static void	__stdcall test(void){}
	virtual void	DBquery ( void );

	void	OnQueryDone ( );

	CImage*		m_pImage;
	CString		m_strPath;
	int			m_iLength;

//--------------begin yangfan 3_12---------------
	long		m_lHeight;          //picRoll����û��ͼƬ�߶ȡ����ȵ���Ϣ
	long		m_lWidth;			//�ǲ��ǲ���Ҫ����������?
//--------------end yangfan 3_12-----------------
	DWORD		m_dwWidthBytes;
	DWORD		m_dwBitBytes;

	//----------------------------------------------------------------------begin yangfan 3_12
	vector<LPPIC_ROLL_EX>	 m_Result;	//picRoll����Ҫ��ʾ�������еĳ�Ա��m_strPath��m_iIndex��
									//�����Ҫ��ʾ��Ӧ����������һ����ص�vector��yangfan 3_12
	//----------------------------------------------------------------------end  yangfan 3_12


//----------------------------------------------------------------------begin yangfan 3_12
	string m_createtime,m_manufacturer;
//	vector<infoRoll*>	m_infoRollResult;
	vector<LPINFO_ROLL_EX>	m_infoRollResult;	// changed by jicheng 2016_03_21
//----------------------------------------------------------------------end yangfan 3_12


	LPPROPERTY_DATA_ITEM	m_pItem_manufacturer;
	//------------------------------------begin  yangfan  2016_3_23
	LPPROPERTY_DATA_ITEM	m_pItem_createtime;
	//------------------------------------end    yangfan  2016_3_23

	//------------------------------------begin  yangfan  2016_3_24
	LPPROPERTY_DATA_ITEM	m_pItem_id;
	//------------------------------------end    yangfan  2016_3_24

	//------------------------------------begin  yangfan  2016_3_30
	LPPROPERTY_DATA_ITEM	m_pItem_filePath;
	//------------------------------------end    yangfan  2016_3_30

	//------------------------------------begin  yangfan  2016_4_9
	//LPPROPERTY_DATA_ITEM	m_pItem_ImageHeight;
	//LPPROPERTY_DATA_ITEM	m_pItem_ImageWidth;

	//CRollLibApp* pRollLib;
	//------------------------------- ----end    yangfan  2016_4_9

	char		m_strQueryCmd [256];
	MYSQL_RES*	m_pResult;
	int			m_nNumRes;
	int			m_nCurrent;
	int			m_iIndex;

	bool	m_bDoneCalculating;
	bool	m_bCalculating;
	vector<double>*	feature_result;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//	color separation
	bool	m_bDouble;	// ����ɫ���

	CImage*		m_pImage_1;	// separated color
	CImage*		m_pImage_2;	// separated color
	CImage*		m_pImage_3;	// separated color
	CImage*		m_pGray;	// gray image

	//CBitmap*	m_pBmp_1;
	//CBitmap*	m_pBmp_2;
	//CBitmap*	m_pBmp_3;

	LPBITMAPINFO	m_lpbiImage_1;
	LPBITMAPINFO	m_lpbiImage_2;
	LPBITMAPINFO	m_lpbiImage_3;
	LPBITMAPINFO	m_lpbiGray;

	RGBQUAD		m_rgbColor_1[256];
	RGBQUAD		m_rgbColor_2[256];
	RGBQUAD		m_rgbColor_3[256];
	RGBQUAD		m_rgbGray[256];

	void	generateHeaders ( );
	void	calculateFeatures ( );
//--------------------------------------------------------------------

	// stored in table rollInfo
	char		m_lpszCustomer [64];


// ����
public:
	CImage*	getSeparated_1 ( );
	CImage*	getSeparated_2 ( );
	CImage*	getSeparated_3 ( );

	CImage*	extractImage_1 ( CImage* pImageSrc, CDC* pDC );

	void	outputString ( CString strMsg, int iKind=0);

	void	refreshProperty ( );

// ��д
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// ʵ��
public:
	virtual ~CDocRollLib();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	bool	m_bNewDoc;	// for surf the database
	bool	m_bQuery;	// query finished or not

	void	loadRollFile ( IStream* pStream );

	void	updateInfo ( infoRoll* pInfo );
	//----------------------------------------------------------begin yangfan  2016_3_30
	void	updatePicInfo( picRoll* pPicInfo);
	//----------------------------------------------------------end   yangfan  2016_3_30

	//----------------------------------------------------------begin yangfan  2016_4_9
	//void	updateImgInfo( CRollLibApp* pRollLib );
	//----------------------------------------------------------end   yangfan  2016_4_9

	void	updateData ( LPPROPERTY_DATA pData );

// ���ɵ���Ϣӳ�亯��
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// ����Ϊ�����������������������ݵ� Helper ����
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
public:
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	afx_msg void OnBtnDbInsert();
	virtual void SetTitle(LPCTSTR lpszTitle);
	afx_msg void OnUpdateBtnDbInsert(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbFirst();
	afx_msg void OnUpdateBtnDbFirst(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbLast();
	afx_msg void OnUpdateBtnDbLast(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbPrev();
	afx_msg void OnUpdateBtnDbPrev(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbDel();
	afx_msg void OnUpdateBtnDbDel(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbNext();
	afx_msg void OnUpdateBtnDbNext(CCmdUI *pCmdUI);
	afx_msg void OnBtnDbQuery();
	afx_msg void OnUpdateBtnDbQuery(CCmdUI *pCmdUI);
	afx_msg void OnChkDouble();
	afx_msg void OnUpdateChkDouble(CCmdUI *pCmdUI);
	afx_msg void OnChkTrible();
	afx_msg void OnUpdateChkTrible(CCmdUI *pCmdUI);
	afx_msg void OnBtnColorSeparate();
	afx_msg void OnUpdateBtnColorSeparate(CCmdUI *pCmdUI);
};
