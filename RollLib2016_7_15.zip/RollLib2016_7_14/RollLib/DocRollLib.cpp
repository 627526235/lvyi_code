// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// RollDoc.cpp : CDocRollLib ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "RollLib.h"
#endif

#include "DocRollLib.h"
#include "DBmySQL.h"
#include "Compute.h"

#include <propkey.h>
//#include <atlconv.h>

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDocRollLib

IMPLEMENT_DYNCREATE(CDocRollLib, CDocument)

BEGIN_MESSAGE_MAP(CDocRollLib, CDocument)
	ON_COMMAND(ID_BTN_DB_INSERT, &CDocRollLib::OnBtnDbInsert)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_INSERT, &CDocRollLib::OnUpdateBtnDbInsert)
	ON_COMMAND(ID_BTN_DB_FIRST, &CDocRollLib::OnBtnDbFirst)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_FIRST, &CDocRollLib::OnUpdateBtnDbFirst)
	ON_COMMAND(ID_BTN_DB_LAST, &CDocRollLib::OnBtnDbLast)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_LAST, &CDocRollLib::OnUpdateBtnDbLast)
	ON_COMMAND(ID_BTN_DB_PREV, &CDocRollLib::OnBtnDbPrev)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_PREV, &CDocRollLib::OnUpdateBtnDbPrev)
	ON_COMMAND(ID_BTN_DB_DEL, &CDocRollLib::OnBtnDbDel)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_DEL, &CDocRollLib::OnUpdateBtnDbDel)
	ON_COMMAND(ID_BTN_DB_NEXT, &CDocRollLib::OnBtnDbNext)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_NEXT, &CDocRollLib::OnUpdateBtnDbNext)
	ON_COMMAND(ID_BTN_DB_QUERY, &CDocRollLib::OnBtnDbQuery)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_QUERY, &CDocRollLib::OnUpdateBtnDbQuery)
	ON_COMMAND(ID_CHK_DOUBLE, &CDocRollLib::OnChkDouble)
	ON_UPDATE_COMMAND_UI(ID_CHK_DOUBLE, &CDocRollLib::OnUpdateChkDouble)
	ON_COMMAND(ID_CHK_TRIBLE, &CDocRollLib::OnChkTrible)
	ON_UPDATE_COMMAND_UI(ID_CHK_TRIBLE, &CDocRollLib::OnUpdateChkTrible)
	ON_COMMAND(ID_BTN_COLOR_SEPARATE, &CDocRollLib::OnBtnColorSeparate)
	ON_UPDATE_COMMAND_UI(ID_BTN_COLOR_SEPARATE, &CDocRollLib::OnUpdateBtnColorSeparate)
END_MESSAGE_MAP()


// CDocRollLib ����/����
void CDocRollLib::generateHeaders ( )
{
	int		i;
	DWORD	dwHeaderSize;
	char*	pBuffer;

	ASSERT ( m_lHeight );
	ASSERT ( m_lWidth );

	m_dwWidthBytes	= ((m_lWidth + 3) >> 2) << 2;
	m_dwBitBytes	= m_dwWidthBytes * (DWORD)m_lHeight;

	dwHeaderSize	= sizeof( BITMAPINFOHEADER ) + (sizeof( RGBQUAD ) << 8);
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_1	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_2	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_3	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiGray		= (LPBITMAPINFO) pBuffer;

	m_lpbiImage_1->bmiHeader.biSize			= sizeof( BITMAPINFOHEADER );
	m_lpbiImage_1->bmiHeader.biWidth		= m_lWidth;
	m_lpbiImage_1->bmiHeader.biHeight		= m_lHeight;
	m_lpbiImage_1->bmiHeader.biPlanes		= 1;
	m_lpbiImage_1->bmiHeader.biBitCount		= 8;
	m_lpbiImage_1->bmiHeader.biSizeImage	= m_dwBitBytes;
	m_lpbiImage_1->bmiHeader.biCompression	= BI_RGB;
	m_lpbiImage_1->bmiHeader.biXPelsPerMeter= 0;
	m_lpbiImage_1->bmiHeader.biYPelsPerMeter= 0;
	m_lpbiImage_1->bmiHeader.biClrUsed		= 256;
	m_lpbiImage_1->bmiHeader.biClrImportant	= 0;

	memcpy ( m_lpbiImage_2, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );
	memcpy ( m_lpbiImage_3, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );
	memcpy ( m_lpbiGray, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );

	for ( i=0; i<256; i++ )
	{
		m_lpbiImage_1->bmiColors[i].rgbBlue		= 0;
		m_lpbiImage_1->bmiColors[i].rgbGreen	= 0;
		m_lpbiImage_1->bmiColors[i].rgbRed		= i;
		m_lpbiImage_1->bmiColors[i].rgbReserved	= 0;

		m_lpbiImage_2->bmiColors[i].rgbBlue		= 0;
		m_lpbiImage_2->bmiColors[i].rgbGreen	= i;
		m_lpbiImage_2->bmiColors[i].rgbRed		= 0;
		m_lpbiImage_2->bmiColors[i].rgbReserved	= 0;

		m_lpbiImage_3->bmiColors[i].rgbBlue		= i;
		m_lpbiImage_3->bmiColors[i].rgbGreen	= 0;
		m_lpbiImage_3->bmiColors[i].rgbRed		= 0;
		m_lpbiImage_3->bmiColors[i].rgbReserved	= 0;

		m_lpbiGray->bmiColors[i].rgbBlue		= i;
		m_lpbiGray->bmiColors[i].rgbGreen		= i;
		m_lpbiGray->bmiColors[i].rgbRed			= i;
		m_lpbiGray->bmiColors[i].rgbReserved	= 0;

		m_rgbColor_1[i].rgbBlue		= i;
		m_rgbColor_1[i].rgbGreen	= i;
		m_rgbColor_1[i].rgbRed		= i;
		m_rgbColor_1[i].rgbReserved	= 0;

		m_rgbColor_2[i].rgbBlue		= i;
		m_rgbColor_2[i].rgbGreen	= i;
		m_rgbColor_2[i].rgbRed		= i;
		m_rgbColor_2[i].rgbReserved	= 0;

		m_rgbColor_3[i].rgbBlue		= i;
		m_rgbColor_3[i].rgbGreen	= i;
		m_rgbColor_3[i].rgbRed		= i;
		m_rgbColor_3[i].rgbReserved	= 0;

		m_rgbGray[i].rgbBlue		= i;
		m_rgbGray[i].rgbGreen		= i;
		m_rgbGray[i].rgbRed			= i;
		m_rgbGray[i].rgbReserved	= 0;
	}
}

CDocRollLib::CDocRollLib()
{
	m_bDirty	= false;

	m_pImage	= NULL;

	m_lpbiImage_1	= NULL;
	m_lpbiImage_2	= NULL;
	m_lpbiImage_3	= NULL;
	m_lpbiGray		= NULL;

	m_pImage_1	= NULL;
	m_pImage_2	= NULL;
	m_pImage_3	= NULL;
	m_pGray		= NULL;

	m_lHeight	= 0;
	m_lWidth	= 0;

	m_bNewDoc	= false;
	m_bQuery	= false;

	m_bDouble	= true;

	m_nCurrent	= 0;
	m_nNumRes	= 0;

	m_iIndex	= -1;

	m_pResult	= NULL;

	feature_result	= NULL;

	m_bDoneCalculating	= true;
	m_bCalculating		= false;
}

CDocRollLib::~CDocRollLib()
{
	int		i, iSize;
//------------------------------------------begin yangfan 2016_3_12
	int j,iSize_m_infoRollResult;
//------------------------------------------end   yangfan 2016_3_12

	if ( m_lpbiImage_1 )
		delete	m_lpbiImage_1;

	if ( m_lpbiImage_2 )
		delete	m_lpbiImage_2;

	if ( m_lpbiImage_3 )
		delete	m_lpbiImage_3;

	if ( m_lpbiGray )
		delete	m_lpbiGray;

	if ( m_pImage )
		delete	m_pImage;

	if ( m_pImage_1 )
		delete	m_pImage_1;

	if ( m_pImage_2 )
		delete	m_pImage_2;

	if ( m_pImage_3 )
		delete	m_pImage_3;

	if ( m_pGray )
		delete	m_pGray;

	//if ( m_pBmp_1 )
	//	delete	m_pBmp_1;

	//if ( m_pBmp_2 )
	//	delete	m_pBmp_2;

	//if ( m_pBmp_3 )
	//	delete	m_pBmp_3;

	if ( m_pResult )
		mysql_free_result ( m_pResult );

	if ( feature_result)
		delete	feature_result;

	iSize	= (int)m_Result.size();
	for ( i=0; i<iSize; i++ )
		delete m_Result[i];

//--------------------------------------------------------------begin yangfan 2016_3_12
	iSize_m_infoRollResult = (int) m_infoRollResult.size();
	for ( j=0; j<iSize_m_infoRollResult; j++ )
		delete m_infoRollResult[j];
//--------------------------------------------------------------end yangfan 2016_3_12
}

BOOL CDocRollLib::OnNewDocument ( )
{
	CMainFrame*	pMain;

	m_bNewDoc	= true;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	//if ( pMain->switch2RollLibView() )
	//	return	FALSE;

	if ( !CDocument::OnNewDocument() )
		return	FALSE;

	// surf the database
	pMain->switchGUI ( this );

	return TRUE;
}




// CDocRollLib ���л�

void CDocRollLib::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: �ڴ����Ӵ洢����
	}
	else
	{
		// TODO: �ڴ����Ӽ��ش���
	}
}

#ifdef SHARED_HANDLERS

// ����ͼ��֧��
void CDocRollLib::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// �޸Ĵ˴����Ի����ĵ�����
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// �������������֧��
void CDocRollLib::InitializeSearchContent()
{
	CString strSearchContent;
	// ���ĵ����������������ݡ�
	// ���ݲ���Ӧ�ɡ�;���ָ�

	// ����:  strSearchContent = _T("point;rectangle;circle;ole object;")��
	SetSearchContent(strSearchContent);
}

void CDocRollLib::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CDocRollLib ���

#ifdef _DEBUG
void CDocRollLib::AssertValid() const
{
	CDocument::AssertValid();
}

void CDocRollLib::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CDocRollLib ����


BOOL CDocRollLib::OnOpenDocument(LPCTSTR lpszPathName)
{
//	if (!CDocument::OnOpenDocument(lpszPathName))
//		return FALSE;

	HRESULT		hRes;

	m_pImage	= new CImage;

	hRes	= m_pImage->Load ( lpszPathName );

	if ( E_FAIL == hRes )
	{
		delete	m_pImage;

		m_pImage	= NULL;

		return	FALSE;
	}

	m_lHeight	= m_pImage->GetHeight ( );
	m_lWidth	= m_pImage->GetWidth ( );

	generateHeaders ( );
	m_bDoneCalculating	= false;	// header ready, do calculating

	m_strPath	= lpszPathName;

	CFile	file;

	file.Open ( lpszPathName, CFile::modeRead );

	m_iLength	= (int)file.GetLength ( );

	file.Close ( );

	return TRUE;
}

// yangfan
void CDocRollLib::OnBtnDbInsert()
{
	LPDB_MYSQL	pDB	= CDBmySQL::getDB();

	while ( !m_bDoneCalculating )
		Sleep ( 100 );
	
	infoRoll* pInfoRoll = new infoRoll();
	pInfoRoll->Save();
	
	picRoll* pPicRoll = new picRoll(CString2str(m_strPath),pInfoRoll->getId());
	pPicRoll->Save();

	//CImage*	pImage;

	//CCompute main_compute;
	//main_compute.OpenImage( m_strPath );	// yangfan dong
	//vector<double> feature_result = main_compute.ComputeFeature();

	featureRoll* pFeatureRoll = new featureRoll( (float)feature_result->at(0),
		(float)feature_result->at(1), (float)feature_result->at(2), (float)feature_result->at(3),
		(float)feature_result->at(4), pInfoRoll->getId() );

	pFeatureRoll->Save();
	delete	pFeatureRoll;

	delete	pPicRoll;
	delete	pInfoRoll;

	// insert the current document into DB
//	pDB->insertRollFile ( -1, CString2str(m_strPath), m_iLength );
}


void CDocRollLib::SetTitle(LPCTSTR lpszTitle)
{
	//CString	 strTitle ( lpszTitle );

	//if ( 0 == strTitle.Left(5).Compare(_T("��������")) )
	//{
	//	CDocument::SetTitle ( _T("��������") );
	//	return;
	//}

	CDocument::SetTitle(lpszTitle);
}


void CDocRollLib::OnUpdateBtnDbInsert(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( !m_bNewDoc & !m_bQuery );
}


void CDocRollLib::OnBtnDbFirst()
{
//	MYSQL_ROW	row;
//	CString		strMsg;

	if ( m_nNumRes < 1 )
		return;

	m_nCurrent	= 0;
	//mysql_data_seek ( m_pResult, m_nCurrent );

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	//if ( NULL == row )
	//{
	//	return;
	//}

	//m_strPath	= row[1];
	//m_iIndex		= atoi(row[0]);

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	//loadRollFile ( m_strPath );

	//m_strPath	= m_Result[0]->filePath;

	//m_iIndex	= m_Result[0]->id;

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	updateInfo ( m_infoRollResult.at(m_nCurrent) );
	//--------------------------------------------------------------------begin yangfan 2016_3_30
	updatePicInfo ( m_Result.at(m_nCurrent) );
	//--------------------------------------------------------------------end   yangfan 2016_3_30

	//--------------------------------------------------------------------begin  yangfan 2016_4_9
	//===================================���󣬲���ֱ����ôд��Ҫʹ����İ�ť��Ҫ��ʾ��ͼƬ��С��Ŷ�Ӧ
	//updateImgInfo( pRollLib );
	//--------------------------------------------------------------------end   yangfan 2016_4_9

	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();
}

void CDocRollLib::OnUpdateBtnDbFirst(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & (m_nCurrent>0) );
}


void CDocRollLib::OnBtnDbLast()
{
//	MYSQL_ROW	row;
//	CString		strMsg;

	if ( m_nNumRes < 1 )
		return;

	m_nCurrent	= m_nNumRes - 1;
	
	//mysql_data_seek ( m_pResult, m_nCurrent );

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	//if ( NULL == row )
	//{
	//	return;
	//}

	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	//loadRollFile ( m_strPath );

	//m_strPath	= m_Result[m_nCurrent]->filePath;
	//m_iIndex	= m_Result[m_nCurrent]->id;

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	updateInfo ( m_infoRollResult.at(m_nCurrent) );
	//--------------------------------------------------------------------begin yangfan 2016_3_30
	updatePicInfo ( m_Result.at(m_nCurrent) );
	//--------------------------------------------------------------------end   yangfan 2016_3_30
	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();
}


void CDocRollLib::OnUpdateBtnDbLast(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & (m_nCurrent<m_nNumRes-1) );
}


void CDocRollLib::OnBtnDbPrev()
{
//	MYSQL_ROW	row;

	//mysql_data_seek ( m_pResult, --m_nCurrent );

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	//if ( NULL == row )
	//{
	//	return;
	//}

	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	//loadRollFile ( m_strPath );
	
	if ( m_nCurrent > 0 )
		--m_nCurrent;
	else 
		return;

	updateInfo ( m_infoRollResult.at(m_nCurrent) );

	//--------------------------------------------------------------------begin yangfan 2016_3_30
	updatePicInfo ( m_Result.at(m_nCurrent) );
	//--------------------------------------------------------------------end   yangfan 2016_3_30


//-------------------------------------------------------------------begin yangfgan 2016_3_12
//	m_createtime = m_infoRollResult[m_nCurrent]->createtime;
//	m_manufacturer = m_infoRollResult[m_nCurrent]->manufacturer;
//-------------------------------------------------------------------end   yangfan 2016_3_12

	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();
}

void CDocRollLib::OnUpdateBtnDbPrev(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & (m_nCurrent>0) );
}


void CDocRollLib::OnBtnDbNext()
{
	//MYSQL_ROW	row;
//	CString		strMsg;

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	//if ( NULL == row )
	//{
	//	return;
	//}

	//m_nCurrent++;
	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	//loadRollFile ( m_strPath );

	if ( m_nCurrent >= m_nNumRes - 1 )
		return;


	m_nCurrent++;

	updateInfo ( m_infoRollResult.at(m_nCurrent) );
	//--------------------------------------------------------------------begin yangfan 2016_3_30
	updatePicInfo ( m_Result.at(m_nCurrent) );
	//--------------------------------------------------------------------end   yangfan 2016_3_30
	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();
}


void CDocRollLib::OnUpdateBtnDbNext(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & (m_nCurrent < m_nNumRes-1) );

//	m_fpInteract	= &CDocRollLib::test;
}


void CDocRollLib::OnQueryDone ( )
{
	CString		strMsg;

	strMsg.Format( _T("������ݿ��ѯ��ϣ��ܼ�¼��: %d"), m_nNumRes );
	this->outputString ( strMsg );

	if ( 0 == m_nNumRes )
	{
		this->refreshProperty ( );
		return;
	}

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	m_nCurrent	= 0;
	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);
//	m_strPath	= m_Result[0]->filePath;
//	m_iIndex	= m_Result[0]->id;
//
//	strMsg.Format( _T("��¼������: %d"), m_iIndex );
//	this->outputString ( strMsg );
//
////	loadRollFile ( m_strPath );
//	this->loadRollFile ( m_Result[m_nCurrent]->GetStream() );

	m_bQuery	= true;

//	this->refreshProperty ( );

	updateInfo ( m_infoRollResult.at(m_nCurrent) );

	//--------------------------------------------------------------------begin yangfan 2016_3_30
	updatePicInfo ( m_Result.at(m_nCurrent) );
	//--------------------------------------------------------------------end   yangfan 2016_3_30
	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();
	
	

	theApp.setBusy (false);
}

void CDocRollLib::DBquery ( )
{
	CString		strMsg;
	POSITION	pos;

	for(int k=0;k<(int)m_Result.size();k++)
		delete m_Result[k];
//-----------------------------------------------------------begin yangfan 2016_3_30
	//replaced by yangfan at 2016_3_30
	m_Result	= CPicRoll_ex::QueryPicRoll_ex();
	m_nNumRes	= (int)m_Result.size();	//ȡ����Ч��¼�� 
	//replaced by yangfan at 2016_3_30
//-----------------------------------------------------------end   yangfan 2016_3_30

//---------------------------------------------------------------------begin yangfan 2016_3_12
//	m_infoRollResult = infoRoll::QueryInfoRoll();
	m_infoRollResult = CInfoRoll_ex::QueryInfoRoll_ex();	// changed by jicheng, 2016_03_21
//---------------------------------------------------------------------end yangfan 2016_3_12

	pos	= this->GetFirstViewPosition ();

	::SendMessageA ( this->GetNextView(pos)->GetSafeHwnd(), _MSG_QUERY_DONE, 0, 0 );

//	this->GetNextView(pos);

	//---------------------------------------------------------------------begin yangfan 2016_3_12
	refreshProperty ( );       //begin yangfan 2016_4_9����
	//---------------------------------------------------------------------end yangfan 2016_3_12
	return;









	strMsg.Format( _T("������ݿ��ѯ��ϣ��ܼ�¼��: %d"), m_nNumRes );
//	this->outputString ( strMsg );

	if ( 0 == m_nNumRes )
	{
		this->refreshProperty ( );
		return;
	}

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	m_nCurrent	= 0;
	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);
	m_strPath	= m_Result[0]->filePath;
	m_iIndex	= m_Result[0]->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
//	this->outputString ( strMsg );

//	loadRollFile ( m_strPath );
	this->loadRollFile ( m_Result[m_nCurrent]->GetStream() );

	m_bQuery	= true;

	this->refreshProperty ( );
}


void CDocRollLib::OnBtnDbQuery(void)
{
	//MYSQL*		sock = CDBmySQL::getDB()->GetSock();
	//MYSQL_ROW	row;
	CString		strMsg;

	//theApp.setBusy();       -----------------------------------------------------------------------begin yangfan 2016_04_05

	strMsg.Format( _T("���ڲ�ѯ������ݿ⣬���Ժ�...") );
	outputString ( strMsg );


	//-----------------------------------------------------------------------------------------------begin yangfan 2016_04_05
	//-----------------------------------------------------------------------------------------------replace thread with function,
	//m_fpInteract	= (FP_JOB)&CDocRollLib::DBquery;
	 
	DBquery();   //yangfan 2016_04_05

	//theApp.addJob ( this );
	//-----------------------------------------------------------------------------------------------end  yangfan 2016_04_05

//	this->refreshProperty ( );    //�ǲ���Ӧ�ð������������733����

	return;




	//sprintf_s ( m_strQueryCmd,"select * from PicInfo;" );

	//if ( mysql_query(sock, m_strQueryCmd) )
	//{
	//	return;
	//}

//	m_pResult	= mysql_store_result ( sock );		//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
//	m_nNumRes	= (int)mysql_num_rows( m_pResult );	//ȡ����Ч��¼�� 
	for(int k=0;k<(int)m_Result.size();k++)
		delete m_Result[k];

	m_Result	= CPicRoll_ex::QueryPicRoll_ex();
	m_nNumRes	= (int)m_Result.size();	//ȡ����Ч��¼�� 

	strMsg.Format( _T("������ݿ��ѯ��ϣ��ܼ�¼��: %d"), m_nNumRes );
	outputString ( strMsg );

	if ( 0 == m_nNumRes )
	{
		refreshProperty ( );
		return;
	}

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	m_nCurrent	= 0;
	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);
	m_strPath	= m_Result[0]->filePath;
	m_iIndex	= m_Result[0]->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );

//	loadRollFile ( m_strPath );
	loadRollFile ( m_Result[m_nCurrent]->GetStream() );

	m_bQuery	= true;

	refreshProperty ( );
}


void CDocRollLib::OnUpdateBtnDbQuery(CCmdUI *pCmdUI)
{
	//---begin yangfan 2016_4_14
	//BOOL b= m_bNewDoc & !m_bQuery & !theApp.m_bBusy;
	//---end   yangfan 2016_4_14

	pCmdUI->Enable ( m_bNewDoc & !m_bQuery & !theApp.m_bBusy );
	
}

void CDocRollLib::loadRollFile ( IStream* pStream )
{
	CImage*		pImage;
	CImage*		pImageOld;
	HRESULT		hRes;

	pImage	= new CImage;

	hRes	= pImage->Load ( pStream );
	if ( E_FAIL == hRes )
	{
		pImageOld	= m_pImage;
		m_pImage	= NULL;

		UpdateAllViews ( NULL );

		delete	pImage;
		delete	pImageOld;

		return;
	}

	pImageOld	= m_pImage;
	m_pImage	= pImage;

	UpdateAllViews ( NULL );

	if ( pImageOld )
		delete	pImageOld;

//	refreshProperty ( );
}

void CDocRollLib::OnBtnDbDel()
{
	CString		strMsg;
	
	// pop out a warning
	if ( IDYES != MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
		_T("�˲�����ɾ��������ݿ��еĵ�ǰ��¼\r\n������?"),
		_T("���ؾ���"),
		MB_ICONEXCLAMATION | MB_YESNOCANCEL) )
	{
		return;
	}

	m_iIndex	= m_Result[m_nCurrent]->id;

	m_Result[m_nCurrent]->Delete ( );
	delete m_Result[m_nCurrent];

	m_Result.erase(m_Result.begin()+m_nCurrent);

	//--------------------------------------------begin yangfan 2016_3_26
	delete m_infoRollResult[m_nCurrent];
	m_infoRollResult.erase(m_infoRollResult.begin()+m_nCurrent);
	//--------------------------------------------end   yangfan 2016_3_26

	m_nNumRes --;

	strMsg.Format( _T("ɾ����¼��������: %d, �ܼ�¼����%d"), m_iIndex, m_nNumRes );
	outputString ( strMsg );

	if ( 0 == m_nNumRes )
	{
		CImage*		pImageOld;

		pImageOld	= m_pImage;

		m_pImage	= NULL;
		UpdateAllViews ( NULL );

		if ( pImageOld )
			delete	pImageOld;

		refreshProperty ( );

		return;
	}

	if ( m_nCurrent > m_nNumRes - 1 )
		m_nCurrent	= m_nNumRes - 1;

	m_strPath	= m_Result[m_nCurrent]->filePath;
	m_iIndex	= m_Result[m_nCurrent]->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );


	//------------------------------------------------------begin yangfgan 2016_4_14
	//============================begin yangfan 2016_4_18,cancle and new
	//updatePicInfo ( m_Result.at(m_nCurrent) );
	//updatePicInfo ( m_Result.at(m_nCurrent) );

	updateInfo ( m_infoRollResult.at(m_nCurrent) );
	updatePicInfo ( m_Result.at(m_nCurrent) );
	//============================end yangfan 2016_4_18,cancle and new
	//------------------------------------------------------end   yangfgan 2016_4_14

	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();

//	m_nCurrent = 0;
//	if ( m_nNumRes > 0 )
//		OnBtnDbFirst ( );
}


void CDocRollLib::OnUpdateBtnDbDel(CCmdUI *pCmdUI)
{
	//---begin yangfan 2016_4_14
	//BOOL b= m_bNewDoc & m_bQuery & m_nNumRes;
	//---end   yangfan 2016_4_14
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & m_nNumRes );
}

void CDocRollLib::outputString ( CString strMsg, int iKind/* =0 */ )
{
	CMainFrame*	pMain;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	pMain->outputString ( strMsg, iKind );
}

void CDocRollLib::refreshProperty ( )
{
	CMainFrame*	pMain;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	pMain->refreshProperty ( this );
}

void CDocRollLib::OnChkDouble()
{
	m_bDouble	= true;
}


void CDocRollLib::OnUpdateChkDouble(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( !m_bNewDoc );

	if ( !m_bNewDoc )
		pCmdUI->SetCheck ( m_bDouble );
}


void CDocRollLib::OnChkTrible()
{
	m_bDouble	= false;
}


void CDocRollLib::OnUpdateChkTrible(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( !m_bNewDoc );

	if ( !m_bNewDoc )
		pCmdUI->SetCheck ( !m_bDouble );
}

CImage* CDocRollLib::getSeparated_1 ( )
{
	return	m_pImage_1;
}

CImage* CDocRollLib::getSeparated_2 ( )
{
	return	m_pImage_2;
}

CImage* CDocRollLib::getSeparated_3 ( )
{
	return	m_pImage_3;
}

CImage* CDocRollLib::extractImage_1 ( CImage* pImageSrc, CDC* pDC )
{
	CImage*	pImage	= NULL;

	return	pImage;
}

void CDocRollLib::OnBtnColorSeparate()
{
	CDC			memDC;
	HDC			hDC;
	CDC*		pDC;
	HBITMAP		hBitmap, hOld;
	CMainFrame*	pMain;
	LPBYTE		ppvBits;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
//	pMain->refreshProperty ( this );

	hDC	= m_pImage->GetDC ( );
	pDC	= CDC::FromHandle ( hDC );

	memDC.DeleteDC ( );
	memDC.CreateCompatibleDC ( pDC );

	// m_pImage_1
	hBitmap	= CreateDIBSection ( hDC, m_lpbiImage_1, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_1 )
		delete	m_pImage_1;

	m_pImage_1	= new CImage;
	m_pImage_1->Attach ( hBitmap );
	m_pImage_1->SetColorTable ( 0, 256, m_rgbColor_1 );

	// m_pImage_2
	hBitmap	= CreateDIBSection ( hDC, m_lpbiImage_2, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_2 )
		delete	m_pImage_2;

	m_pImage_2	= new CImage;
	m_pImage_2->Attach ( hBitmap );
	m_pImage_2->SetColorTable ( 0, 256, m_rgbColor_2 );

	// m_pImage_3
	hBitmap	= CreateDIBSection ( hDC, m_lpbiImage_3, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_3 )
		delete	m_pImage_3;

	m_pImage_3	= new CImage;
	m_pImage_3->Attach ( hBitmap );
	m_pImage_3->SetColorTable ( 0, 256, m_rgbColor_3 );


	m_pImage->ReleaseDC ( );

//	calculateFeatures ( );

//	pMain->refreshSeparatedColors ( this );
}

void CDocRollLib::OnUpdateBtnColorSeparate(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( !m_bNewDoc );
}

/*
void CDocRollLib::initializePropertyData ( )
{
	CMainFrame*				pMain;
	LPPROPERTY_DATA_ITEM	pItem,pCreTimItem;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );

	pItem	= m_dataProperty.addItem (  _T("����") );
	m_pItem_manufacturer	= pItem->addSubItem ( _T("��������"), _T("����"), _T("�༭����") );
	m_pItem_manufacturer->m_pFP_infoRoll	= (FP_INFO_ROLL_EX)&CInfoRoll_ex::updateManufacturer;

	//-----------------------------------------------------------------begin  yangfan  2016_3_23
	pCreTimItem = m_dataProperty.addItem(_T("ʱ��"));
	m_pItem_createtime = pCreTimItem->addSubItem(_T("ʱ��"), _T("00:00 1970/1/1"), _T("�༭ʱ��"));
	m_pItem_createtime->m_pFP_infoRoll = (FP_INFO_ROLL_EX)&CInfoRoll_ex::updateCreatetime;
	//-----------------------------------------------------------------end    yangfan  2016_3_23

	pMain->initializeProperty ( this );
}
*/

/*
void CDocRollLib::updateInfo ( infoRoll* pInfo )
{
	CString	strMsg;

	m_createtime	= pInfo->createtime;

	// ͨ�� SetValue ( ... ) ����������

	m_iIndex	= pInfo->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );

	m_pItem_manufacturer->setValue ( (_variant_t)pInfo->manufacturer.c_str() );
	//--------------------------------------------begin yangfan 2016_3_23
	m_pItem_createtime->setValue((_variant_t)pInfo->createtime.c_str());
	//--------------------------------------------end   yangfan 2016_3_23

	refreshProperty ( );
}
*/

void CDocRollLib::updateData ( LPPROPERTY_DATA pData )
{
	// getitem, getsubitem
}

/*
void CDocRollLib::updatePropertyData ( )
{
	m_pItem_manufacturer->m_pProp->m_pItem	= m_pItem_manufacturer;

	//-------------------------------------------------------begin yangfan 2016_3_24
	m_pItem_createtime->m_pProp->m_pItem = m_pItem_createtime;
	//-------------------------------------------------------end   yangfan 2016_3_24

	// m_pItem_manufacturer->m_pProp->SetValue ( );
	// the above line has been done in m_pItem_manufacturer->setValue ( ... ) in updateInfo
}*/

void CDocRollLib::onItemChanged ( LPPROPERTY_DATA_ITEM pItem, CMFCPropertyGridPropertyEx* pProp )
{
	FP_INFO_ROLL_EX		pFP;
	//-----------------------------------------------begin yangfan 2016_3_30
	FP_PIC_ROLL_EX		pFP_pic;
	pFP_pic = pItem->m_pFP_picRoll;
	//-----------------------------------------------end   yangfan 2016_3_30
	COleVariant			varNewValue;
	COleVariant			varOldValue;

	m_bDirty	= true;

	pItem->onItemChanged ( pProp );

	pFP	= pItem->m_pFP_infoRoll;
	if ( pFP )
	{
		LPINFO_ROLL_EX	pInfo;

		varNewValue	= pProp->GetValue ( );
		varOldValue	= pProp->GetOriginalValue ( );

		pInfo	= m_infoRollResult.at(m_nCurrent);

		USES_CONVERSION;
		(pInfo->*pFP)( W2A(varNewValue.bstrVal) );

		pInfo->Save ( );
	}
	//-----------------------------------------------begin yangfan 2016_3_30
	if(pFP_pic)//pItem->m_strName=="�洢·��"
	{
		LPPIC_ROLL_EX	pPic;
		varNewValue	= pProp->GetValue ( );
		varOldValue	= pProp->GetOriginalValue ( );
		pPic = m_Result.at(m_nCurrent);
		USES_CONVERSION;
		(pPic->*pFP_pic)( W2A(varNewValue.bstrVal) );
		pPic->Save();
	}
	//-----------------------------------------------end   yangfan 2016_3_30
}
