#ifndef	_PROPERTY_DATA_H
#define	_PROPERTY_DATA_H

#include "PropertyDataItem.h"

typedef	class CPropertyData	PROPERTY_DATA, *LPPROPERTY_DATA;

class CPropertyData
{
public:
	// make a data object copy, will create a new data object, which
	// has exactly the same descendant structure as the source data object
	static LPPROPERTY_DATA	makeDataCopy ( LPPROPERTY_DATA pData_src );

	// the source and the target objects must have the same descendant structure
	// this function will copy all the binding informations from the init to the target
	void	copyBindingInfo ( LPPROPERTY_DATA pData_init );

public:
	void	addItem ( );
	void	addItem ( LPPROPERTY_DATA_ITEM pItem );

	LPPROPERTY_DATA_ITEM	addItem ( CString strName, CString strValue, LPCTSTR lpszDescr );
	LPPROPERTY_DATA_ITEM	addItem ( CString strName );

	LPPROPERTY_DATA_ITEM	m_pHeadList;	// header of the list
	LPPROPERTY_DATA_ITEM	m_pTailList;	// tailer of the list



public:
	CPropertyData ( );
	~CPropertyData ( );
};

#endif	// #ifndef	_PROPERTY_DATA_H