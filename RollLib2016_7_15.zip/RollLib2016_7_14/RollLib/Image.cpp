// Image.cpp: implementation of the Image class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Image.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Image::Image()
{
	m_hBitmap = NULL;
	m_pBits = NULL;
	m_hMemDC = NULL;

}

Image::~Image()
{
	Destroy();
}

//ͼ��ռ��ͷź���
void Image::Destroy()
{
	if( m_hBitmap!=NULL && m_pBits!=NULL && m_hMemDC!=NULL )
	{
		m_DC.Detach();
		SelectObject(m_hMemDC,m_hOldBitmap);
		DeleteDC(m_hMemDC);
		DeleteObject(m_hBitmap);
	}
	m_hBitmap = NULL;
	m_pBits = NULL;
	m_hMemDC = NULL;
}


/*
//��������ͼ��ߴ����ͼ����ڴ�ռ䣬��������ز�����
BOOL Image::Create(int a_Width, int a_Height)
{
	 Destroy();
	if( a_Width==0 || a_Height==0 )	return FALSE;
	if( a_Width<0 ) a_Width = -a_Width;
	if( a_Height<0 ) a_Height = -a_Height;
	
	BITMAPINFO bi;
	bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bi.bmiHeader.biWidth = a_Width;
	bi.bmiHeader.biHeight = -a_Height; 
	bi.bmiHeader.biPlanes = 1;
	bi.bmiHeader.biBitCount = 24;
	bi.bmiHeader.biCompression = BI_RGB;
	bi.bmiHeader.biSizeImage = 0;
	bi.bmiHeader.biXPelsPerMeter = 11810;
	bi.bmiHeader.biYPelsPerMeter = 11810;
	bi.bmiHeader.biClrUsed = 0;
	bi.bmiHeader.biClrImportant = 0;
	
	HDC hdc=CreateCompatibleDC(NULL);
	//�ú����ṩһ��ָ�룬��ָ��ָ��λͼλ����ֵ�ĵط������Ը��ļ�ӳ������ṩ���������ʹ���ļ�ӳ�����������λͼ��������ϵͳΪλͼ�����ڴ档 
	m_hBitmap = CreateDIBSection(hdc,&bi,DIB_RGB_COLORS,(void**)&m_pBits,NULL,0);  //�ú�������Ӧ�ó������ֱ��д��ġ����豸�޹ص�λͼ��DIB
	DeleteDC(hdc);
	
	if( m_hBitmap==NULL || m_pBits==NULL )
	{
		m_hBitmap = NULL;
		m_pBits = NULL;
		return FALSE;
	}
	BITMAP bm;
	GetObject(m_hBitmap,sizeof(BITMAP),&bm);
	m_Width = bm.bmWidth;
	m_Height = bm.bmHeight;
	m_WidthBytes = bm.bmWidthBytes;
	m_ImageSize = m_WidthBytes*m_Height;
	
	m_hMemDC = CreateCompatibleDC(NULL);
	if( m_hMemDC==NULL )
	{
		DeleteObject(m_hBitmap);
		m_hBitmap = NULL;
		m_pBits = NULL;
		m_hMemDC = NULL;
		return FALSE;
	}
	m_hOldBitmap = (HBITMAP)SelectObject(m_hMemDC,m_hBitmap);
	m_DC.Attach(m_hMemDC);
	return TRUE;

}

//ͼ��ռ��ͷź���
void Image::Destroy()
{
	if( m_hBitmap!=NULL && m_pBits!=NULL && m_hMemDC!=NULL )
	{
		m_DC.Detach();
		SelectObject(m_hMemDC,m_hOldBitmap);
		DeleteDC(m_hMemDC);
		DeleteObject(m_hBitmap);
	}
	m_hBitmap = NULL;
	m_pBits = NULL;
	m_hMemDC = NULL;
}

//ͼ����Ч���б�ͼ���ƺ���
BOOL Image::IsValid()
{
	return ( m_hBitmap!=NULL && m_pBits!=NULL && m_hMemDC!=NULL );
}


BOOL Image::CopyFrom(Image *a_pImg)
{
	if( a_pImg==NULL || !a_pImg->IsValid() )
		return FALSE;
	if( !Create(a_pImg->m_Width, a_pImg->m_Height) )
		return FALSE;
	memcpy(	(void*)m_pBits, (void*)a_pImg->m_pBits, m_WidthBytes*m_Height );
	return TRUE;
}

//ͼ����ʾ����
//ֱ����ʾ��������ʾ�����ʺϴ��ڵĳߴ���ʾͼ��
BOOL Image::BitBlt(HDC a_DestDC, int a_DestX, int a_DestY, int a_Width, int a_Height, int a_SrcX, int a_SrcY, DWORD a_Rop)
{
	return ::BitBlt(a_DestDC, a_DestX, a_DestY, a_Width, a_Height,m_hMemDC, a_SrcX, a_SrcY, a_Rop);
}

BOOL Image::StretchBlt(HDC a_DestDC, int a_DestX, int a_DestY, int a_DestWidth, int a_DestHeight, int a_SrcX, int a_SrcY, int a_SrcWidth, int a_SrcHeight, DWORD a_Rop)
{
	::SetStretchBltMode(a_DestDC,COLORONCOLOR);
	return ::StretchBlt(a_DestDC, a_DestX, a_DestY, a_DestWidth, a_DestHeight,m_hMemDC, a_SrcX, a_SrcY, a_SrcWidth, a_SrcHeight, a_Rop);
}

//�ļ����뺯��
BOOL Image::LoadBmpFile(CString a_Filename)
{
	FILE *pf = fopen(a_Filename,"rb");
	if( pf==NULL ) return FALSE;
	
	BITMAPFILEHEADER bmfHeader; //λͼ�ļ�ͷ��bitmap-file header��������ͼ�����͡�ͼ���С��ͼ�����ݴ�ŵ�ַ����������δʹ�õ��ֶΡ�

	if ( fread((LPSTR)&bmfHeader,1,sizeof(bmfHeader),pf) != sizeof(bmfHeader) ) //��ȡλͼ�ļ�ͷ
	{	
		fclose(pf); 
		return FALSE;
	}
	if( bmfHeader.bfType != ((WORD)('M'<<8) | 'B') )  //λͼ��𣬸��ݲ�ͬ�Ĳ���ϵͳ����ͬ����Windows�У����ֶε�ֵ��Ϊ'BM'

	{
		fclose(pf);
		return FALSE;
	}
	
	int leng = bmfHeader.bfSize - sizeof(bmfHeader); //bmfHeader.bfSize BMPͼ���ļ��Ĵ�С
	BYTE *pBmp = (BYTE *)calloc(leng,1);
	if( pBmp == NULL )
	{	
		fclose(pf); 
		return FALSE;	
	}
	
	if ( (int)fread(pBmp,1,leng,pf) != leng )  //��ȡλͼ�ļ�ʣ�µĲ���
	{
		free(pBmp); 
		fclose(pf);
		return FALSE;
	}
	fclose(pf);
	BYTE *pImg=(BYTE*)(pBmp + bmfHeader.bfOffBits - sizeof(BITMAPFILEHEADER)); //�õ� λͼ��Ϣͷ ��ַ
	BITMAPINFO *pbi;
	pbi = (BITMAPINFO*)pBmp;
	if( pbi->bmiHeader.biBitCount != 24 )  //24λͼƬ
	{
		free(pBmp); 
		return FALSE;	
	}
	int widthBytes = ((pbi->bmiHeader.biWidth*pbi->bmiHeader.biBitCount+31)/32)*4;  ////widthBytes ������4��������
	int i;
	BYTE *p1,*p2;
	RGBQUAD *ci = pbi->bmiColors;  //��ɫ��
	if( Create( pbi->bmiHeader.biWidth, abs(pbi->bmiHeader.biHeight) ) )
	{
		int bytes = m_WidthBytes;
		if( bytes>widthBytes ) bytes = widthBytes;
		for(i=0;i<m_Height;i++)
		{
			p1 = m_pBits + i*m_WidthBytes;
			if( pbi->bmiHeader.biHeight<0 )
				p2 = pImg + i*widthBytes;
			else
				p2 = pImg + (m_Height-1-i)*widthBytes;
			memcpy(p1,p2,bytes);
		}
		free(pBmp); return TRUE;
	}
	else 
	{
		free(pBmp);
		return FALSE;
	}


}

//�ļ����溯��
BOOL Image::SaveBitmap(CString a_Filename)
{
	if( !IsValid() ) return FALSE;	
	FILE *pf = fopen(a_Filename,"wb+");

	if( pf==NULL ) return FALSE;
    BITMAPINFO *pbmi; 
	
	pbmi = (BITMAPINFO*)calloc(1, sizeof(BITMAPINFOHEADER)); 	
    pbmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    pbmi->bmiHeader.biWidth = m_Width;
    pbmi->bmiHeader.biHeight = m_Height;
    pbmi->bmiHeader.biPlanes = 1;         
    pbmi->bmiHeader.biBitCount = 24;        
    pbmi->bmiHeader.biCompression = BI_RGB;  
	UINT widthBytes = ((m_Width * 24 +31)/32)*4;  
    pbmi->bmiHeader.biSizeImage = widthBytes * m_Height;
	pbmi->bmiHeader.biXPelsPerMeter = 11810;
	pbmi->bmiHeader.biYPelsPerMeter = 11810;
    pbmi->bmiHeader.biClrUsed = 0;
	pbmi->bmiHeader.biClrImportant = 0; 

    BITMAPFILEHEADER hdr;      
    BITMAPINFOHEADER *pbih; 
	
    pbih = (BITMAPINFOHEADER*)pbmi; 
    hdr.bfType = 0x4d42;	
    hdr.bfSize = (DWORD) (sizeof(BITMAPFILEHEADER) + 
		pbih->biSize + pbih->biSizeImage); 
    hdr.bfReserved1 = 0; 
    hdr.bfReserved2 = 0; 
    hdr.bfOffBits = (DWORD) sizeof(BITMAPFILEHEADER) + pbih->biSize; 
	fwrite(&hdr, sizeof(BITMAPFILEHEADER), 1, pf);  
	fwrite(pbih, sizeof(BITMAPINFOHEADER), 1, pf);
	int i;
	BYTE *p1;

	m_WidthBytes=widthBytes; 

	for(i=m_Height-1;i>=0;i--)
	{
		p1 = m_pBits + m_WidthBytes * i; 
		if( fwrite(p1, 1, widthBytes, pf) != widthBytes )  //д�ļ�����
		{	
			free((HLOCAL)pbmi); 
			fclose(pf); 
			return FALSE;
		}
	}	
	free((HLOCAL)pbmi);
	fclose(pf);
	return TRUE;

}
*/