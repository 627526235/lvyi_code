#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "RollLib.h"
#endif

#include "DocRollLib.h"
#include "DBmySQL.h"
#include "Compute.h"

#include <propkey.h>
//#include <atlconv.h>

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

void CDocRollLib::initializePropertyData ( )
{
	CMainFrame*				pMain;
	LPPROPERTY_DATA_ITEM	pItem;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );

	pItem	= m_dataProperty.addItem (  _T("����") );
	m_pItem_manufacturer	= pItem->addSubItem ( _T("��������"), _T("����"), _T("�༭����") );
	m_pItem_manufacturer->m_pFP_infoRoll	= (FP_INFO_ROLL_EX)&CInfoRoll_ex::updateManufacturer;
	//===============================================begin yangfan 2016_3_31
	m_pItem_manufacturer->m_pFP_picRoll = NULL;
	//===============================================end   yangfan 2016_3_31

	//-----------------------------------------------------------------begin  yangfan  2016_3_23
	LPPROPERTY_DATA_ITEM	pCreTimItem;
	pCreTimItem = m_dataProperty.addItem(_T("ʱ��"));
	m_pItem_createtime = pCreTimItem->addSubItem(_T("ʱ��"), _T("00:00 1970/1/1"), _T("�༭ʱ��"));
	m_pItem_createtime->m_pFP_infoRoll = (FP_INFO_ROLL_EX)&CInfoRoll_ex::updateCreatetime;
	//===============================================begin yangfan 2016_3_31
	m_pItem_createtime->m_pFP_picRoll = NULL;
	//===============================================end   yangfan 2016_3_31
	//-----------------------------------------------------------------end    yangfan  2016_3_23
	
	
	//-----------------------------------------------------------------begin  yangfan  2016_3_24
	LPPROPERTY_DATA_ITEM	pIdItem;
	pIdItem = m_dataProperty.addItem(_T("���"));
	m_pItem_id = pIdItem->addSubItem(_T("���"), _T("0"), _T("�༭���"));
	m_pItem_id->m_pFP_infoRoll = (FP_INFO_ROLL_EX)&CInfoRoll_ex::updateId;
	//===============================================begin yangfan 2016_3_31
	m_pItem_id->m_pFP_picRoll = NULL;
	//===============================================end   yangfan 2016_3_31
	//-----------------------------------------------------------------end    yangfan  2016_3_24
	
	//-----------------------------------------------------------------begin  yangfan  2016_3_30
	LPPROPERTY_DATA_ITEM	pFilePathItem;
	pFilePathItem = m_dataProperty.addItem(_T("�洢·��"));
	m_pItem_filePath = pFilePathItem->addSubItem(_T("�洢·��"), _T("X:\\default.jpg"), _T("�༭·��"));
	m_pItem_filePath->m_pFP_picRoll = (FP_PIC_ROLL_EX)&CPicRoll_ex::updateFilePath;
	//===============================================begin yangfan 2016_3_31
	m_pItem_filePath->m_pFP_infoRoll = NULL;
	//===============================================end   yangfan 2016_3_31
	//-----------------------------------------------------------------end    yangfan  2016_3_30


	//-----------------------------------------------------------------begin  yangfan  2016_4_9
	//LPPROPERTY_DATA_ITEM	pImageSizeItem;
	//pImageSizeItem = m_dataProperty.addItem(_T("ͼƬ��С"));
	//m_pItem_ImageHeight = pImageSizeItem->addSubItem(_T("��"), _T("0"), _T("�༭�߶�")); 
	//m_pItem_ImageWidth  = pImageSizeItem->addSubItem(_T("��"), _T("0"), _T("�༭����"));
	//-----------------------------------------------------------------end    yangfan  2016_4_9

	pMain->initializeProperty ( this );
}

//-----------------------------------------------------------------------begin  yangfan  2016_4_9
//void CDocRollLib::updateImgInfo( CRollLibApp* pRollLib )
//{
	//m_pItem_ImageHeight->setValue( (_variant_t)pRollLib->m_ImageHeight );
	//m_pItem_ImageWidth->setValue( (_variant_t)pRollLib->m_ImageWidth );
	//refreshProperty ( );
//}
//-----------------------------------------------------------------------end    yangfan  2016_4_9

//---------------------------------------------------------------------------------begin yangfan 2016_3_30
void CDocRollLib::updatePicInfo( picRoll* pPicInfo)
{
	m_pItem_filePath->setValue(  (_variant_t)pPicInfo->filePath );
	refreshProperty ( );
}
//---------------------------------------------------------------------------------end yangfan 2016_3_30

void CDocRollLib::updateInfo ( infoRoll* pInfo )
{
	CString	strMsg;
	//m_createtime	= pInfo->createtime;
	// ͨ�� SetValue ( ... ) ����������
	m_iIndex	= pInfo->id;
	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );
	m_pItem_manufacturer->setValue ( (_variant_t)pInfo->manufacturer.c_str() );

	//--------------------------------------------begin yangfan 2016_3_23
	m_pItem_createtime->setValue((_variant_t)pInfo->createtime.c_str());
	//--------------------------------------------end   yangfan 2016_3_23

	//--------------------------------------------begin yangfan 2016_3_24
	m_pItem_id->setValue((_variant_t)pInfo->number.c_str());
	//--------------------------------------------end   yangfan 2016_3_24

	refreshProperty ( );
}

void CDocRollLib::updatePropertyData ( )
{
	//---------------------------------------------------------------------------------begin yangfan 2016_3_30	
	m_pItem_filePath->m_pProp->m_pItem = m_pItem_filePath;	
    //---------------------------------------------------------------------------------end   yangfan 2016_3_30

	m_pItem_manufacturer->m_pProp->m_pItem	= m_pItem_manufacturer;

	//-------------------------------------------------------begin yangfan 2016_3_24
	m_pItem_createtime->m_pProp->m_pItem = m_pItem_createtime;
	//-------------------------------------------------------end   yangfan 2016_3_24

	//--------------------------------------------begin yangfan 2016_3_24
	m_pItem_id->m_pProp->m_pItem = m_pItem_id;
	//--------------------------------------------end   yangfan 2016_3_24

	//--------------------------------------------begin yangfan 2016_4_9
	//m_pItem_ImageHeight->m_pProp->m_pItem = m_pItem_ImageHeight;
	//m_pItem_ImageWidth->m_pProp->m_pItem  = m_pItem_ImageWidth;
	//--------------------------------------------end   yangfan 2016_4_9
	
}