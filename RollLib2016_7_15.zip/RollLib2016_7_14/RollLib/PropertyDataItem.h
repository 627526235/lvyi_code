#ifndef	_PROPERTY_DATA_ITEM_H
#define	_PROPERTY_DATA_ITEM_H

#include "DB/infoRoll_ex.h"
//-------------------------------------------------begin  yangfan 2016_3_30
#include "picRoll_ex(yf).h"
//-------------------------------------------------end    yangfan 2016_3_30

typedef class CPropertyDataItem	PROPERTY_DATA_ITEM, *LPPROPERTY_DATA_ITEM;

class CMFCPropertyGridPropertyEx;
class CPropertyDataItem
{
public:
	void	onItemChanged ( CMFCPropertyGridPropertyEx* pProp );
	void	setValue ( const COleVariant &varValue );

	void	copyItemBindingInfo ( LPPROPERTY_DATA_ITEM pItem_src );

	void	addKid ( LPPROPERTY_DATA_ITEM pKid );

	LPPROPERTY_DATA_ITEM	addSubItem ( const CString &strName, const COleVariant &varValue , LPCTSTR lpszDescr=(LPCTSTR) 0 );

public:
	LPPROPERTY_DATA_ITEM	pNext;	// brother
	LPPROPERTY_DATA_ITEM	pKids;	// child

	FP_INFO_ROLL_EX		m_pFP_infoRoll;
	//-------------------------------------------------begin  yangfan 2016_3_30
	FP_PIC_ROLL_EX		m_pFP_picRoll ;	
	
	//-------------------------------------------------end    yangfan 2016_3_30

	CString		m_strName;
	_variant_t	m_varValue;
	CString		m_strDescr;

	CMFCPropertyGridPropertyEx*	m_pProp;

public:
	CPropertyDataItem ( const CString &strName, const COleVariant &varValue , LPCTSTR lpszDescr=(LPCTSTR) 0 );
	CPropertyDataItem ( const LPPROPERTY_DATA_ITEM pItem_src );
	CPropertyDataItem ( );
	~CPropertyDataItem ( );
};

#endif	// #ifndef	_PROPERTY_DATA_ITEM_H