#ifndef	_MFC_PROPERTY_GRID_PROPERTY_EX_H_
#define	_MFC_PROPERTY_GRID_PROPERTY_EX_H_

// CMFCPropertyGridPropertyEx

#include "PropertyData.h"

class CMFCPropertyGridCtrlEx;

class CMFCPropertyGridPropertyEx : public CMFCPropertyGridProperty
{
public:
	CMFCPropertyGridCtrlEx*	m_pCtrl;

	LPPROPERTY_DATA_ITEM	m_pItem;	// current interacting item

public:
	CMFCPropertyGridPropertyEx ( LPPROPERTY_DATA_ITEM pItem_root, DWORD_PTR dwData=0UL, BOOL bIsValueList=0 );

	CMFCPropertyGridPropertyEx ( CString strName, DWORD_PTR dwData=0UL, BOOL bIsValueList=0 );

	CMFCPropertyGridPropertyEx ( const LPPROPERTY_DATA_ITEM pItem, bool bReserved, DWORD_PTR dwData = 0UL );

	CMFCPropertyGridPropertyEx ( const CString& strName, const COleVariant& varValue, LPCTSTR lpszDescr = NULL, DWORD_PTR dwData = 0UL,
		LPCTSTR lpszEditMask = NULL, LPCTSTR lpszEditTemplate = NULL, LPCTSTR lpszValidChars = NULL );

	virtual ~CMFCPropertyGridPropertyEx();

protected:
//	DECLARE_MESSAGE_MAP()
};

#endif
