#include "StdAfx.h"
#include "picRoll_ex(yf).h"


//-------------------------------------begin yangfan 2016_3_30

void CPicRoll_ex::updateFilePath( string strFilePath )
{
	filePath = strFilePath.c_str();
}
//-------------------------------------end   yangfan 2016_3_30

vector<LPPIC_ROLL_EX> CPicRoll_ex::QueryPicRoll_ex ( )
{
	vector<LPPIC_ROLL_EX> ans;
	MYSQL* sock = CDBmySQL::getDB()->GetSock();
	MYSQL_RES *res = NULL;
	MYSQL_ROW row; 
	char QueryCmd[128];
	sprintf_s(QueryCmd,"select * from picRoll;");
	if(mysql_query(sock,QueryCmd))
	{
		return ans;
	}
	//----------------------------begin yangfan 2016_3_31
	//----------------------------begin test tickCount
	DWORD start2,end2,consume2;
	start2 = GetTickCount();

	//res = mysql_store_result( sock ) ;//ȡ�ò�ѯ���,�����ѯ�������ݵ�res
	res = mysql_use_result( sock );		//change to mysql_use_result,yangfan 2016_3_31

	end2 = GetTickCount();
	consume2 = end2 - start2;
	//----------------------------end test tickCount2
	//----------------------------end yangfan 2016_3_31



	/*-------------------------------------------------------------------������
    int num = (int)mysql_num_rows( res ) ;//ȡ����Ч��¼�� 
	for(int i=0;i<num;i++)
	{
		row = mysql_fetch_row( res );
		int size = 0;//mysql_fetch_lengths(res)[2];
	
		LPPIC_ROLL_EX pPicRoll = new PIC_ROLL_EX(atoi(row[0]),row[1],NULL,size,atoi(row[3])); 
		ans.push_back(pPicRoll);
	}
    mysql_free_result(res); //�ͷŽ����Դ 
	return ans;
	//-------------------------------------------------------------------������*/
	
	while(row = mysql_fetch_row( res ))
	//int j;
	//for(int i=0;i<=(j=mysql_num_rows( res ));++i)
	{
		//row = mysql_fetch_row( res );
		int size = 0;
		LPPIC_ROLL_EX pPicRoll = new PIC_ROLL_EX(atoi(row[0]),row[1],NULL,size,atoi(row[3])); 
		ans.push_back(pPicRoll);
	}
	mysql_free_result(res);
	return ans;
}


