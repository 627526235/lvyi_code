// DlgSeparatedColors.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "RollLib.h"
#include "DlgSeparatedColors.h"
#include "afxdialogex.h"

#include "DocOrder.h"

// CDlgSeparatedColors �Ի���

IMPLEMENT_DYNAMIC(CDlgSeparatedColors, CDialogEx)

CDlgSeparatedColors::CDlgSeparatedColors(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDlgSeparatedColors::IDD, pParent)
{
	m_pImage_1	= NULL;
	m_pImage_2	= NULL;
	m_pImage_3	= NULL;
	m_pImage	= NULL;

	m_pDoc	= NULL;
}

CDlgSeparatedColors::~CDlgSeparatedColors()
{
}

void CDlgSeparatedColors::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BTN_1, m_btnImage_1);
	DDX_Control(pDX, IDC_BTN_2, m_btnImage_2);
	DDX_Control(pDX, IDC_BTN_3, m_btnImage_3);
	DDX_Control(pDX, IDC_BTN_4, m_btnImage_4);
	DDX_Control(pDX, IDC_BTN_5, m_btnImage_1m);
	DDX_Control(pDX, IDC_BTN_6, m_btnImage_2m);
	DDX_Control(pDX, IDC_BTN_7, m_btnImage_3m);
}


BEGIN_MESSAGE_MAP(CDlgSeparatedColors, CDialogEx)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BTN_1, &CDlgSeparatedColors::OnBnClickedBtn1)
	ON_BN_CLICKED(IDC_BTN_2, &CDlgSeparatedColors::OnBnClickedBtn2)
	ON_BN_CLICKED(IDC_BTN_3, &CDlgSeparatedColors::OnBnClickedBtn3)
	ON_BN_CLICKED(IDC_BTN_4, &CDlgSeparatedColors::OnBnClickedBtn4)
	ON_BN_CLICKED(IDC_BTN_5, &CDlgSeparatedColors::OnBnClickedBtn1m)
	ON_BN_CLICKED(IDC_BTN_6, &CDlgSeparatedColors::OnBnClickedBtn2m)
	ON_BN_CLICKED(IDC_BTN_7, &CDlgSeparatedColors::OnBnClickedBtn3m)
END_MESSAGE_MAP()


// CDlgSeparatedColors ��Ϣ��������

void CDlgSeparatedColors::UpdateSeparatedColors ( CDocOrder* pDoc )
{
	//HDC			hDC;
	//CDC*		pDC;
	//CBitmap		bmpSep_1;
	//CDC			memDC;
	//CBitmap*	pOld;
	//int			nWidth, nHeight;
	//HBITMAP		hBitmap;

	m_pDoc	= pDoc;

	m_pImage_1	= pDoc->getSeparated_1 ( );
	m_pImage_2	= pDoc->getSeparated_2 ( );
	m_pImage_3	= pDoc->getSeparated_3 ( );
//	m_pImage_3	= pDoc->m_pGray;
	m_pImage	= pDoc->m_pImage;


	//nWidth		= m_pImage_1->GetWidth ( );
	//nHeight		= m_pImage_1->GetHeight ( );

	//hDC	= m_pImage_1->GetDC ( );
	//pDC	= CDC::FromHandle ( hDC );

	//bmpSep_1.CreateCompatibleBitmap ( pDC, nWidth, nHeight );
	//memDC.CreateCompatibleDC ( pDC );

	//pOld	= (CBitmap*)memDC.SelectObject ( &bmpSep_1 );

	//m_pImage_1->StretchBlt ( memDC.m_hDC, CRect(0,0,nWidth, nHeight), CRect(0,0,nWidth, nHeight), SRCCOPY );

	//hBitmap	= (HBITMAP)memDC.SelectObject ( pOld->m_hObject );

	//m_pImage_1->ReleaseDC ( );

//	m_btnImage_1.SetBitmaps ( hBitmap, RGB(255,255,255), hBitmap, RGB(255,255,255) );
//	m_btnImage_1.SetBitmaps ( hBitmap, RGB(0,0,0) );

	m_btnImage_1.EnableWindow ( );
	m_btnImage_4.EnableWindow ( );	// original pic

	m_btnImage_1.DrawTransparent ( );
	m_btnImage_2.DrawTransparent ( );

	if ( m_pImage_2 )
	{
		m_btnImage_2.EnableWindow ( );
		m_btnImage_2.DrawTransparent ( );
	}
	if ( m_pImage_3 )
	{
		m_btnImage_3.EnableWindow ( );
		m_btnImage_3.DrawTransparent ( );
	}

	RedrawWindow ( );
	Invalidate ( );
	UpdateWindow ( );
}

void CDlgSeparatedColors::clear ( )
{
	m_pDoc	= NULL;

	m_pImage_1	= NULL;
	m_pImage_2	= NULL;
	m_pImage_3	= NULL;
	m_pImage	= NULL;

	m_btnImage_1.DrawTransparent ( TRUE );
	m_btnImage_2.DrawTransparent ( TRUE );
	m_btnImage_3.DrawTransparent ( TRUE );
	m_btnImage_4.DrawTransparent ( TRUE );

	m_btnImage_1.EnableWindow ( FALSE );
	m_btnImage_2.EnableWindow ( FALSE );
	m_btnImage_3.EnableWindow ( FALSE );
	m_btnImage_4.EnableWindow ( FALSE );

	RedrawWindow ( );
	Invalidate ( );
	UpdateWindow ( );
}

BOOL CDlgSeparatedColors::OnEraseBkgnd(CDC* pDC)
{
	CDialogEx::OnEraseBkgnd(pDC);

	CRect	rcDlg;
	CRect	rcBtn;

	GetWindowRect ( rcDlg );

	//pDC->Rectangle ( rcDlg );
	//pDC->MoveTo ( 0, 0 );
	//pDC->LineTo ( 100, 700 );
	if ( NULL == m_pDoc )
	{
		return	FALSE;
	}

	if ( m_pImage_1 )
	{
		m_btnImage_1.GetWindowRect ( rcBtn );


		m_pImage_1->BitBlt ( pDC->GetSafeHdc(), rcBtn.left-rcDlg.left, rcBtn.top-rcDlg.top,
			rcBtn.Width(), rcBtn.Height(), 0, 0, SRCCOPY );
	}

	if ( m_pImage_2 )
	{
		m_btnImage_2.GetWindowRect ( rcBtn );


		m_pImage_2->BitBlt ( pDC->GetSafeHdc(), rcBtn.left-rcDlg.left, rcBtn.top-rcDlg.top,
			rcBtn.Width(), rcBtn.Height(), 0, 0, SRCCOPY );
	}

	if ( m_pImage_3 )
	{
		m_btnImage_3.GetWindowRect ( rcBtn );


		m_pImage_3->BitBlt ( pDC->GetSafeHdc(), rcBtn.left-rcDlg.left, rcBtn.top-rcDlg.top,
			rcBtn.Width(), rcBtn.Height(), 0, 0, SRCCOPY );
	}

	if ( (NULL != m_pImage_1) & (NULL != m_pImage) )
	{
		m_btnImage_4.GetWindowRect ( rcBtn );


		m_pImage->BitBlt ( pDC->GetSafeHdc(), rcBtn.left-rcDlg.left, rcBtn.top-rcDlg.top,
			rcBtn.Width(), rcBtn.Height(), 0, 0, SRCCOPY );
	}

	return TRUE;
}

void CDlgSeparatedColors::OnSize(UINT nType, int cx, int cy)
{
	CRect	rcBtn;

	CDialogEx::OnSize(nType, cx, cy);

	cy	= cy - 35;

	if ( cy < 20 )
		cy	= 20;

	if ( NULL != m_btnImage_1.GetSafeHwnd() )
	{
		m_btnImage_4.MoveWindow ( 7, 7, (cx-14)/2, cy/4 );
		m_btnImage_1.MoveWindow ( 7, 14+cy/4, (cx-14)/2, cy/4 );
		m_btnImage_2.MoveWindow ( 7, 21+cy/2, (cx-14)/2, cy/4 );
		m_btnImage_3.MoveWindow ( 7, 28+cy*3/4, (cx-14)/2, cy/4 );

		m_btnImage_1m.MoveWindow ( 10+(cx-14)/2, 14+cy/4, (cx-14)/2, cy/4 );
		m_btnImage_2m.MoveWindow ( 10+(cx-14)/2, 21+cy/2, (cx-14)/2, cy/4 );
		m_btnImage_3m.MoveWindow ( 10+(cx-14)/2, 28+cy*3/4, (cx-14)/2, cy/4 );
	}
}

void CDlgSeparatedColors::OnBnClickedBtn1()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 1 );
}

void CDlgSeparatedColors::OnBnClickedBtn2()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 2 );
}

void CDlgSeparatedColors::OnBnClickedBtn3()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 3 );
}

void CDlgSeparatedColors::OnBnClickedBtn4()
{
	if ( NULL == m_pDoc )
		return;

	m_pDoc->setDisplay ( 0/*0*/ );
}


void CDlgSeparatedColors::OnBnClickedBtn1m()
{

}

void CDlgSeparatedColors::OnBnClickedBtn2m()
{

}

void CDlgSeparatedColors::OnBnClickedBtn3m()
{

}
