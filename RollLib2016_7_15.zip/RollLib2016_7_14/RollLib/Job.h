#ifndef	__JOB_H__
#define	__JOB_H__

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
[Module]
	Job.h
[Description]
	This module encapsulates user interacting job.
[Author]
	jicheng @ whu.edu.cn
[Date]
	2016-02-18

[Revision History]
----------------------------------------------------------------------------------------------------
	When		Who		Where				Description
----------------------------------------------------------------------------------------------------
 2016-02-18	  Jicheng	Wuhan University	Constructed
----------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------*/

typedef	class CJob JOB, *LP_JOB;

typedef	void (CJob::*FP_JOB)(void);
//typedef	void (__stdcall CJob::*FP_JOB)(void);
//typedef	void (__thiscall CJob::*FP_JOB)(void);
//typedef	void (__stdcall *FP_JOB)(void);

class CJob
{
public:
	virtual void	DBquery ( ){}

public:
	FP_JOB	m_fpInteract;

	LP_JOB	m_pNext;

	CJob ( );
	~CJob ( );
};

#endif	// #ifndef	__JOB_H__
