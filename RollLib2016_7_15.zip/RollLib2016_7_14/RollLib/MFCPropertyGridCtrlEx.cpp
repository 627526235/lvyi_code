// MFCPropertyGridCtrlEx.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "RollLib.h"
#include "MFCPropertyGridCtrlEx.h"
#include "MFCPropertyGridPropertyEx.h"


// CMFCPropertyGridCtrlEx

IMPLEMENT_DYNAMIC(CMFCPropertyGridCtrlEx, CMFCPropertyGridCtrl)

void CMFCPropertyGridCtrlEx::initializeData ( LPPROPERTY_DATA pData_initial )
{
	if ( NULL == m_pData_initial )
	{
		m_pData_initial	= CPropertyData::makeDataCopy ( pData_initial );

		// ����Ԫ�س�ʼ������
		bindGrid ( );
	}

	pData_initial->copyBindingInfo ( m_pData_initial );
}

CMFCPropertyGridCtrlEx::CMFCPropertyGridCtrlEx()
{
	m_pDoc	= NULL;

	m_pData_initial	= NULL;
//	m_pData_display	= NULL;
}

CMFCPropertyGridCtrlEx::~CMFCPropertyGridCtrlEx()
{
	if ( m_pData_initial )
		delete	m_pData_initial;

//	if ( m_pData_display )
//		delete	m_pData_display;
}


BEGIN_MESSAGE_MAP(CMFCPropertyGridCtrlEx, CMFCPropertyGridCtrl)
END_MESSAGE_MAP()



// CMFCPropertyGridCtrlEx ��Ϣ��������
int CMFCPropertyGridCtrlEx::AddProperty(CMFCPropertyGridPropertyEx* pProp, BOOL bRedraw, BOOL bAdjustLayout )
{
	pProp->m_pCtrl	= this;

	return CMFCPropertyGridCtrl::AddProperty ( pProp, bRedraw, bAdjustLayout );
}

void CMFCPropertyGridCtrlEx::bindGrid ( )
{
	LPPROPERTY_DATA_ITEM		pItem, pItem_next;
	CMFCPropertyGridPropertyEx*	pGroup;

	pItem	= m_pData_initial->m_pHeadList;
	while ( pItem )
	{
		pItem_next	= pItem->pNext;

		pGroup	= new CMFCPropertyGridPropertyEx ( pItem );

		pItem->m_pProp	= pGroup;

		this->AddProperty ( pGroup );

		pGroup->Expand ( );

		pItem	= pItem_next;
	}
}
