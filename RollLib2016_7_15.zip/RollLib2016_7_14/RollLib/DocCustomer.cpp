// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// RollDoc.cpp : CDocCustomer ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "RollLib.h"
#endif

#include "DocCustomer.h"
#include "DBmySQL.h"
#include "Compute.h"

#include <propkey.h>

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDocCustomer

IMPLEMENT_DYNCREATE(CDocCustomer, CDocument)

BEGIN_MESSAGE_MAP(CDocCustomer, CDocument)
	ON_COMMAND(ID_BTN_DB_INSERT, &CDocCustomer::OnBtnDbInsert)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_INSERT, &CDocCustomer::OnUpdateBtnDbInsert)
	ON_COMMAND(ID_BTN_DB_FIRST, &CDocCustomer::OnBtnDbFirst)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_FIRST, &CDocCustomer::OnUpdateBtnDbFirst)
	ON_COMMAND(ID_BTN_DB_LAST, &CDocCustomer::OnBtnDbLast)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_LAST, &CDocCustomer::OnUpdateBtnDbLast)
	ON_COMMAND(ID_BTN_DB_PREV, &CDocCustomer::OnBtnDbPrev)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_PREV, &CDocCustomer::OnUpdateBtnDbPrev)
	ON_COMMAND(ID_BTN_DB_DEL, &CDocCustomer::OnBtnDbDel)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_DEL, &CDocCustomer::OnUpdateBtnDbDel)
	ON_COMMAND(ID_BTN_DB_NEXT, &CDocCustomer::OnBtnDbNext)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_NEXT, &CDocCustomer::OnUpdateBtnDbNext)
	ON_COMMAND(ID_BTN_DB_QUERY, &CDocCustomer::OnBtnDbQuery)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_QUERY, &CDocCustomer::OnUpdateBtnDbQuery)
	ON_COMMAND(ID_CHK_DOUBLE, &CDocCustomer::OnChkDouble)
	ON_UPDATE_COMMAND_UI(ID_CHK_DOUBLE, &CDocCustomer::OnUpdateChkDouble)
	ON_COMMAND(ID_CHK_TRIBLE, &CDocCustomer::OnChkTrible)
	ON_UPDATE_COMMAND_UI(ID_CHK_TRIBLE, &CDocCustomer::OnUpdateChkTrible)
	ON_COMMAND(ID_BTN_COLOR_SEPARATE, &CDocCustomer::OnBtnColorSeparate)
	ON_UPDATE_COMMAND_UI(ID_BTN_COLOR_SEPARATE, &CDocCustomer::OnUpdateBtnColorSeparate)
END_MESSAGE_MAP()


// CDocCustomer ����/����
void CDocCustomer::generateHeaders ( )
{
	int		i;
	DWORD	dwHeaderSize;
	char*	pBuffer;

	ASSERT ( m_lHeight );
	ASSERT ( m_lWidth );

	m_dwWidthBytes	= ((m_lWidth + 3) >> 2) << 2;
	m_dwBitBytes	= m_dwWidthBytes * (DWORD)m_lHeight;

	dwHeaderSize	= sizeof( BITMAPINFOHEADER ) + (sizeof( RGBQUAD ) << 8);
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_1	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_2	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_3	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiGray		= (LPBITMAPINFO) pBuffer;

	m_lpbiImage_1->bmiHeader.biSize			= sizeof( BITMAPINFOHEADER );
	m_lpbiImage_1->bmiHeader.biWidth		= m_lWidth;
	m_lpbiImage_1->bmiHeader.biHeight		= m_lHeight;
	m_lpbiImage_1->bmiHeader.biPlanes		= 1;
	m_lpbiImage_1->bmiHeader.biBitCount		= 8;
	m_lpbiImage_1->bmiHeader.biSizeImage	= m_dwBitBytes;
	m_lpbiImage_1->bmiHeader.biCompression	= BI_RGB;
	m_lpbiImage_1->bmiHeader.biXPelsPerMeter= 0;
	m_lpbiImage_1->bmiHeader.biYPelsPerMeter= 0;
	m_lpbiImage_1->bmiHeader.biClrUsed		= 256;
	m_lpbiImage_1->bmiHeader.biClrImportant	= 0;

	memcpy ( m_lpbiImage_2, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );
	memcpy ( m_lpbiImage_3, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );
	memcpy ( m_lpbiGray, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );

	for ( i=0; i<256; i++ )
	{
		m_lpbiImage_1->bmiColors[i].rgbBlue		= 0;
		m_lpbiImage_1->bmiColors[i].rgbGreen	= 0;
		m_lpbiImage_1->bmiColors[i].rgbRed		= i;
		m_lpbiImage_1->bmiColors[i].rgbReserved	= 0;

		m_lpbiImage_2->bmiColors[i].rgbBlue		= 0;
		m_lpbiImage_2->bmiColors[i].rgbGreen	= i;
		m_lpbiImage_2->bmiColors[i].rgbRed		= 0;
		m_lpbiImage_2->bmiColors[i].rgbReserved	= 0;

		m_lpbiImage_3->bmiColors[i].rgbBlue		= i;
		m_lpbiImage_3->bmiColors[i].rgbGreen	= 0;
		m_lpbiImage_3->bmiColors[i].rgbRed		= 0;
		m_lpbiImage_3->bmiColors[i].rgbReserved	= 0;

		m_lpbiGray->bmiColors[i].rgbBlue		= i;
		m_lpbiGray->bmiColors[i].rgbGreen		= i;
		m_lpbiGray->bmiColors[i].rgbRed			= i;
		m_lpbiGray->bmiColors[i].rgbReserved	= 0;

		m_rgbColor_1[i].rgbBlue		= i;
		m_rgbColor_1[i].rgbGreen	= i;
		m_rgbColor_1[i].rgbRed		= i;
		m_rgbColor_1[i].rgbReserved	= 0;

		m_rgbColor_2[i].rgbBlue		= i;
		m_rgbColor_2[i].rgbGreen	= i;
		m_rgbColor_2[i].rgbRed		= i;
		m_rgbColor_2[i].rgbReserved	= 0;

		m_rgbColor_3[i].rgbBlue		= i;
		m_rgbColor_3[i].rgbGreen	= i;
		m_rgbColor_3[i].rgbRed		= i;
		m_rgbColor_3[i].rgbReserved	= 0;

		m_rgbGray[i].rgbBlue		= i;
		m_rgbGray[i].rgbGreen		= i;
		m_rgbGray[i].rgbRed			= i;
		m_rgbGray[i].rgbReserved	= 0;
	}
}

CDocCustomer::CDocCustomer()
{
	m_pImage	= NULL;

	m_lpbiImage_1	= NULL;
	m_lpbiImage_2	= NULL;
	m_lpbiImage_3	= NULL;
	m_lpbiGray		= NULL;

	m_pImage_1	= NULL;
	m_pImage_2	= NULL;
	m_pImage_3	= NULL;
	m_pGray		= NULL;

	m_lHeight	= 0;
	m_lWidth	= 0;

	m_bNewDoc	= false;
	m_bQuery	= false;

	m_bDouble	= true;

	m_nCurrent	= 0;
	m_nNumRes	= 0;

	m_iIndex	= -1;

	m_pResult	= NULL;

	feature_result	= NULL;

	m_bDoneCalculating	= true;
	m_bCalculating		= false;
}

CDocCustomer::~CDocCustomer()
{
	int		i, iSize;

	if ( m_lpbiImage_1 )
		delete	m_lpbiImage_1;

	if ( m_lpbiImage_2 )
		delete	m_lpbiImage_2;

	if ( m_lpbiImage_3 )
		delete	m_lpbiImage_3;

	if ( m_lpbiGray )
		delete	m_lpbiGray;

	if ( m_pImage )
		delete	m_pImage;

	if ( m_pImage_1 )
		delete	m_pImage_1;

	if ( m_pImage_2 )
		delete	m_pImage_2;

	if ( m_pImage_3 )
		delete	m_pImage_3;

	if ( m_pGray )
		delete	m_pGray;

	//if ( m_pBmp_1 )
	//	delete	m_pBmp_1;

	//if ( m_pBmp_2 )
	//	delete	m_pBmp_2;

	//if ( m_pBmp_3 )
	//	delete	m_pBmp_3;

	if ( m_pResult )
		mysql_free_result ( m_pResult );

	if ( feature_result)
		delete	feature_result;

	iSize	= (int)m_Result.size();
	for ( i=0; i<iSize; i++ )
		delete m_Result[i];
}

BOOL CDocCustomer::OnNewDocument()
{
	m_bNewDoc	= true;

	if (!CDocument::OnNewDocument())
		return FALSE;

	// surf the database

	return TRUE;
}




// CDocCustomer ���л�

void CDocCustomer::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: �ڴ����Ӵ洢����
	}
	else
	{
		// TODO: �ڴ����Ӽ��ش���
	}
}

#ifdef SHARED_HANDLERS

// ����ͼ��֧��
void CDocCustomer::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// �޸Ĵ˴����Ի����ĵ�����
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// �������������֧��
void CDocCustomer::InitializeSearchContent()
{
	CString strSearchContent;
	// ���ĵ����������������ݡ�
	// ���ݲ���Ӧ�ɡ�;���ָ�

	// ����:  strSearchContent = _T("point;rectangle;circle;ole object;")��
	SetSearchContent(strSearchContent);
}

void CDocCustomer::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CDocCustomer ���

#ifdef _DEBUG
void CDocCustomer::AssertValid() const
{
	CDocument::AssertValid();
}

void CDocCustomer::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CDocCustomer ����

BOOL CDocCustomer::OnOpenDocument(LPCTSTR lpszPathName)
{
//	if (!CDocument::OnOpenDocument(lpszPathName))
//		return FALSE;

	m_pImage	= new CImage;

	m_pImage->Load ( lpszPathName );

	m_lHeight	= m_pImage->GetHeight ( );
	m_lWidth	= m_pImage->GetWidth ( );

	generateHeaders ( );
	m_bDoneCalculating	= false;	// header ready, do calculating

	m_strPath	= lpszPathName;

	CFile	file;

	file.Open ( lpszPathName, CFile::modeRead );

	m_iLength	= (int)file.GetLength ( );

	file.Close ( );

	return TRUE;
}

// yangfan
void CDocCustomer::OnBtnDbInsert()
{
	LPDB_MYSQL	pDB	= CDBmySQL::getDB();

	while ( !m_bDoneCalculating )
		Sleep ( 100 );
	
	infoRoll* pInfoRoll = new infoRoll();
	pInfoRoll->Save();
	
	picRoll* pPicRoll = new picRoll(CString2str(m_strPath),pInfoRoll->getId());
	pPicRoll->Save();

	//CImage*	pImage;

	//CCompute main_compute;
	//main_compute.OpenImage( m_strPath );	// yangfan dong
	//vector<double> feature_result = main_compute.ComputeFeature();

	featureRoll* pFeatureRoll = new featureRoll( (float)feature_result->at(0),
		(float)feature_result->at(1), (float)feature_result->at(2), (float)feature_result->at(3),
		(float)feature_result->at(4), pInfoRoll->getId() );

	pFeatureRoll->Save();
	delete	pFeatureRoll;

	delete	pPicRoll;
	delete	pInfoRoll;

	// insert the current document into DB
//	pDB->insertRollFile ( -1, CString2str(m_strPath), m_iLength );
}


void CDocCustomer::SetTitle(LPCTSTR lpszTitle)
{
	CString	 strTitle ( lpszTitle );

	if ( 0 == strTitle.Left(6).Compare(_T("��������ļ�")) )
	{
		CDocument::SetTitle ( _T("��������") );
		return;
	}

	CDocument::SetTitle(lpszTitle);
}


void CDocCustomer::OnUpdateBtnDbInsert(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( !m_bNewDoc & !m_bQuery );
}


void CDocCustomer::OnBtnDbFirst()
{
//	MYSQL_ROW	row;
	CString		strMsg;

	m_nCurrent	= 0;
	//mysql_data_seek ( m_pResult, m_nCurrent );

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	//if ( NULL == row )
	//{
	//	return;
	//}

	//m_strPath	= row[1];
	//m_iIndex		= atoi(row[0]);

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	//loadRollFile ( m_strPath );

	m_strPath	= m_Result[0]->filePath;

	m_iIndex	= m_Result[0]->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );

	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();
}

void CDocCustomer::OnUpdateBtnDbFirst(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & (m_nCurrent>0) );
}


void CDocCustomer::OnBtnDbLast()
{
//	MYSQL_ROW	row;
	CString		strMsg;

	m_nCurrent	= m_nNumRes - 1;
	//mysql_data_seek ( m_pResult, m_nCurrent );

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	//if ( NULL == row )
	//{
	//	return;
	//}

	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	//loadRollFile ( m_strPath );

	m_strPath	= m_Result[m_nCurrent]->filePath;
	m_iIndex	= m_Result[m_nCurrent]->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );

	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();
}


void CDocCustomer::OnUpdateBtnDbLast(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & (m_nCurrent<m_nNumRes-1) );
}


void CDocCustomer::OnBtnDbPrev()
{
//	MYSQL_ROW	row;
	CString		strMsg;

	//mysql_data_seek ( m_pResult, --m_nCurrent );

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	//if ( NULL == row )
	//{
	//	return;
	//}

	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	//loadRollFile ( m_strPath );
	
	if(m_nCurrent > 0)
		--m_nCurrent;
	else 
		return;

	m_strPath	= m_Result[m_nCurrent]->filePath;
	m_iIndex	= m_Result[m_nCurrent]->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );

	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();
}

void CDocCustomer::OnUpdateBtnDbPrev(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & (m_nCurrent>0) );
}


void CDocCustomer::OnBtnDbNext()
{
	//MYSQL_ROW	row;
	CString		strMsg;

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	//if ( NULL == row )
	//{
	//	return;
	//}

	//m_nCurrent++;
	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);

	//strMsg.Format( _T("��¼������: %d"), m_iIndex );
	//outputString ( strMsg );

	//loadRollFile ( m_strPath );

	if(m_nCurrent >= m_nNumRes - 1)
		return;


	m_nCurrent++;
	m_strPath	= m_Result[m_nCurrent]->filePath;
	m_iIndex	= m_Result[m_nCurrent]->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );

	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();
}


void CDocCustomer::OnUpdateBtnDbNext(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & (m_nCurrent < m_nNumRes-1) );
}


void CDocCustomer::OnBtnDbQuery()
{
	//MYSQL*		sock = CDBmySQL::getDB()->GetSock();
	//MYSQL_ROW	row;
	CString		strMsg;

	//sprintf_s ( m_strQueryCmd,"select * from PicInfo;" );

	//if ( mysql_query(sock, m_strQueryCmd) )
	//{
	//	return;
	//}

//	m_pResult	= mysql_store_result ( sock );		//ȡ�ò�ѯ���,�����ѯ�������ݵ�res 
//	m_nNumRes	= (int)mysql_num_rows( m_pResult );	//ȡ����Ч��¼�� 
	m_Result	= picRoll::QueryPicRoll();
	m_nNumRes	= (int)m_Result.size();	//ȡ����Ч��¼�� 

	strMsg.Format( _T("��ѯ������ݿ��У��ܹ���¼��: %d"), m_nNumRes );
	outputString ( strMsg );

	if ( 0 == m_nNumRes )
	{
		refreshProperty ( );
		return;
	}

	//row	= mysql_fetch_row( m_pResult );	//��ȡ���������,���ζ�ȡ������¼

	m_nCurrent	= 0;
	//m_strPath	= row[1];
	//m_iIndex	= atoi(row[0]);
	m_strPath	= m_Result[0]->filePath;
	m_iIndex	= m_Result[0]->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );

//	loadRollFile ( m_strPath );
	loadRollFile ( m_Result[m_nCurrent]->GetStream() );

	m_bQuery	= true;

	refreshProperty ( );
}


void CDocCustomer::OnUpdateBtnDbQuery(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & !m_bQuery );
}

void CDocCustomer::loadRollFile ( IStream* pStream )
{
	CImage*		pImage;
	CImage*		pImageOld;

	pImage	= new CImage;

	pImage->Load ( pStream );

	pImageOld	= m_pImage;
	m_pImage	= pImage;

	UpdateAllViews ( NULL );

	if ( pImageOld )
		delete	pImageOld;

	refreshProperty ( );
}

void CDocCustomer::loadRollFile ( LPCTSTR lpszPathName )
{
	CImage*		pImage;
	CImage*		pImageOld;

	pImage	= new CImage;

	pImage->Load ( m_strPath );

	CFile	file;

	file.Open ( m_strPath, CFile::modeRead );

	m_iLength	= (int)file.GetLength ( );

	file.Close ( );

	pImageOld	= m_pImage;
	m_pImage	= pImage;

	UpdateAllViews ( NULL );

	if ( pImageOld )
		delete	pImageOld;

	refreshProperty ( );
}

void CDocCustomer::OnBtnDbDel()
{
	CString		strMsg;
	
	// pop out a warning
	if ( IDYES != MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
		_T("�˲�����ɾ��������ݿ��еĵ�ǰ��¼\r\n������?"),
		_T("���ؾ���"),
		MB_ICONEXCLAMATION | MB_YESNOCANCEL) )
	{
		return;
	}

	m_iIndex	= m_Result[m_nCurrent]->id;

	m_Result[m_nCurrent]->Delete ( );
	delete m_Result[m_nCurrent];

	m_Result.erase(m_Result.begin()+m_nCurrent);
	m_nNumRes --;

	strMsg.Format( _T("ɾ����¼��������: %d, �ܼ�¼����%d"), m_iIndex, m_nNumRes );
	outputString ( strMsg );

	if ( 0 == m_nNumRes )
	{
		CImage*		pImageOld;

		pImageOld	= m_pImage;

		m_pImage	= NULL;
		UpdateAllViews ( NULL );

		if ( pImageOld )
			delete	pImageOld;

		refreshProperty ( );

		return;
	}

	if ( m_nCurrent > m_nNumRes - 1 )
		m_nCurrent	= m_nNumRes - 1;

	m_strPath	= m_Result[m_nCurrent]->filePath;
	m_iIndex	= m_Result[m_nCurrent]->id;

	strMsg.Format( _T("��¼������: %d"), m_iIndex );
	outputString ( strMsg );

	loadRollFile ( m_Result[m_nCurrent]->GetStream() );
	m_Result[m_nCurrent]->FreeData();

//	m_nCurrent = 0;
//	if ( m_nNumRes > 0 )
//		OnBtnDbFirst ( );
}


void CDocCustomer::OnUpdateBtnDbDel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bNewDoc & m_bQuery & m_nNumRes );
}

void CDocCustomer::outputString ( CString strMsg, int iKind/* =0 */ )
{
	CMainFrame*	pMain;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	pMain->outputString ( strMsg, iKind );
}

void CDocCustomer::refreshProperty ( )
{
	CMainFrame*	pMain;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
//	pMain->refreshProperty ( this );
}

void CDocCustomer::OnChkDouble()
{
	m_bDouble	= true;
}


void CDocCustomer::OnUpdateChkDouble(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( !m_bNewDoc );

	if ( !m_bNewDoc )
		pCmdUI->SetCheck ( m_bDouble );
}


void CDocCustomer::OnChkTrible()
{
	m_bDouble	= false;
}


void CDocCustomer::OnUpdateChkTrible(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( !m_bNewDoc );

	if ( !m_bNewDoc )
		pCmdUI->SetCheck ( !m_bDouble );
}

CImage* CDocCustomer::getSeparated_1 ( )
{
	return	m_pImage_1;
}

CImage* CDocCustomer::getSeparated_2 ( )
{
	return	m_pImage_2;
}

CImage* CDocCustomer::getSeparated_3 ( )
{
	return	m_pImage_3;
}

CImage* CDocCustomer::extractImage_1 ( CImage* pImageSrc, CDC* pDC )
{
	CImage*	pImage	= NULL;

	return	pImage;
}

void CDocCustomer::OnBtnColorSeparate()
{
	CDC			memDC;
	HDC			hDC;
	CDC*		pDC;
	HBITMAP		hBitmap, hOld;
	CMainFrame*	pMain;
	LPBYTE		ppvBits;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
//	pMain->refreshProperty ( this );

	hDC	= m_pImage->GetDC ( );
	pDC	= CDC::FromHandle ( hDC );

	memDC.DeleteDC ( );
	memDC.CreateCompatibleDC ( pDC );

	// m_pImage_1
	hBitmap	= CreateDIBSection ( hDC, m_lpbiImage_1, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_1 )
		delete	m_pImage_1;

	m_pImage_1	= new CImage;
	m_pImage_1->Attach ( hBitmap );
	m_pImage_1->SetColorTable ( 0, 256, m_rgbColor_1 );

	// m_pImage_2
	hBitmap	= CreateDIBSection ( hDC, m_lpbiImage_2, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_2 )
		delete	m_pImage_2;

	m_pImage_2	= new CImage;
	m_pImage_2->Attach ( hBitmap );
	m_pImage_2->SetColorTable ( 0, 256, m_rgbColor_2 );

	// m_pImage_3
	hBitmap	= CreateDIBSection ( hDC, m_lpbiImage_3, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pImage_3 )
		delete	m_pImage_3;

	m_pImage_3	= new CImage;
	m_pImage_3->Attach ( hBitmap );
	m_pImage_3->SetColorTable ( 0, 256, m_rgbColor_3 );


	m_pImage->ReleaseDC ( );

//	calculateFeatures ( );

//	pMain->refreshSeparatedColors ( this );
}

void CDocCustomer::OnUpdateBtnColorSeparate(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( !m_bNewDoc );
}
