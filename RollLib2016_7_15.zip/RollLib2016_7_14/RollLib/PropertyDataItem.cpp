#include "StdAfx.h"
#include "PropertyDataItem.h"
#include "MFCPropertyGridPropertyEx.h"


void CPropertyDataItem::setValue ( const COleVariant &varValue )
{
	m_varValue	= varValue;

	if ( m_pProp )
	{
		m_pProp->SetValue ( varValue );
	}
}

void CPropertyDataItem::addKid ( LPPROPERTY_DATA_ITEM pItem )
{
	LPPROPERTY_DATA_ITEM	pKid_youngest, pNext;

	if ( NULL == pKids )
	{
		pKids	= pItem;
		return;
	}

	pKid_youngest	= pKids;
	pNext			= pKids;
	while ( pNext )
	{
		pKid_youngest	= pNext;

		pNext	= pNext->pNext;
	}

	pKid_youngest->pNext	= pItem;
}

LPPROPERTY_DATA_ITEM CPropertyDataItem::addSubItem ( const CString &strName, const COleVariant &varValue , LPCTSTR lpszDescr )
{
	LPPROPERTY_DATA_ITEM	pSubItem;

	pSubItem	= new CPropertyDataItem ( strName, varValue, lpszDescr );

	addKid ( pSubItem );

	return	pSubItem;
}

CPropertyDataItem::CPropertyDataItem ( const CString &strName, const COleVariant &varValue , LPCTSTR lpszDescr )
{
	pNext	= NULL;
	pKids	= NULL;

	m_pProp	= NULL;

	m_pFP_infoRoll	= NULL;

	m_strName	= strName;
	m_varValue	= varValue;
	m_strDescr	= lpszDescr;
}

CPropertyDataItem::CPropertyDataItem ( const LPPROPERTY_DATA_ITEM pItem_src )
{	// make a copy of pItem and all of its kids
	LPPROPERTY_DATA_ITEM	pItem, pItem_next;
	LPPROPERTY_DATA_ITEM	pItem_new;

	m_strName	= pItem_src->m_strName;
	m_varValue	= pItem_src->m_varValue;
	m_strDescr	= pItem_src->m_strDescr;

	pNext	= NULL;
	pKids	= NULL;

	m_pProp	= NULL;

	m_pFP_infoRoll	= NULL;

	pItem	= pItem_src->pKids;
	while ( pItem )
	{
		pItem_next	= pItem->pNext;

		pItem_new	= new CPropertyDataItem ( pItem );

		this->addKid ( pItem_new );

		pItem	= pItem_next;
	}
}

CPropertyDataItem::CPropertyDataItem ( )
{
	pNext	= NULL;
	pKids	= NULL;

	m_pProp	= NULL;

	m_pFP_infoRoll	= NULL;
}


CPropertyDataItem::~CPropertyDataItem ( )
{
	LPPROPERTY_DATA_ITEM	pItem;

	// !!!
	// ÿһ������������Ŀֻ�����Լ��ĺ��, ��Ҫ�����Լ����ֵ�, �ֵܵĺ�����ֵ����Լ�����

	// delete all its kids
	pItem	= pKids;	// first
	while ( pItem )
	{
		pKids	= pItem->pNext;	// and kids' brothers

		delete	pItem;

		pItem	= pKids;
	}

	// do NOT delete brothers of this ONE
	// delete	pItem->pNext
}

void CPropertyDataItem::copyItemBindingInfo ( LPPROPERTY_DATA_ITEM pItem_src )
{
	LPPROPERTY_DATA_ITEM	pItem, pSrc;
	LPPROPERTY_DATA_ITEM	pItem_next, pSrc_next;

	m_pProp	= pItem_src->m_pProp;

	// now copy binding info of all of its kids
	pSrc	= pItem_src->pKids;
	pItem	= pKids;
	while ( pItem )
	{
		pItem_next	= pItem->pNext;
		pSrc_next	= pSrc->pNext;

		pItem->m_pProp	= pSrc->m_pProp;

		pItem	= pItem_next;
		pSrc	= pSrc_next;
	}
}

void CPropertyDataItem::onItemChanged ( CMFCPropertyGridPropertyEx* pProp )
{
	COleVariant					varNewValue;
	COleVariant					varOldValue;

	ASSERT ( pProp == m_pProp );

	varNewValue	= pProp->GetValue ( );
	varOldValue	= pProp->GetOriginalValue ( );

	m_varValue	= varNewValue;
}