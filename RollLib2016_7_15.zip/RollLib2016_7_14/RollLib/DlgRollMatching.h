#pragma once


// CDlgRollMatching �Ի���
#include "Resource.h"
#include "BtnST.h"
#include "afxwin.h"

#include "DBmySQL.h"

class CDocOrder;
class CDlgRollMatching : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgRollMatching)

public:
	void	updateRollMatches ( CDocOrder* pDoc );

	CDocOrder*	m_pDoc;

	CImage*		m_pImage;

//	vector<CImage*>*	match_result;
	vector<RollLib*>*	match_result;

	int		m_iCnt_matchRoll;

	void	clear ( );

public:
	CDlgRollMatching(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgRollMatching();

// �Ի�������
	enum { IDD = IDD_DLG_ROLL_MATCHING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

public:
	CButtonST	m_btnImage_0;
	CButtonST	m_btnImage_1;
	CButtonST	m_btnImage_2;
	CButtonST	m_btnImage_3;
	CButtonST	m_btnImage_4;
	CButtonST	m_btnImage_5;
	CButtonST	m_btnImage_6;
	CButtonST	m_btnImage_7;
	CButtonST	m_btnImage_8;
	CButtonST	m_btnImage_9;

	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedBtn0();
	afx_msg void OnBnClickedBtn1();
	afx_msg void OnBnClickedBtn2();
	afx_msg void OnBnClickedBtn3();
	afx_msg void OnBnClickedBtn4();
	afx_msg void OnBnClickedBtn5();
	afx_msg void OnBnClickedBtn6();
	afx_msg void OnBnClickedBtn7();
	afx_msg void OnBnClickedBtn8();
	afx_msg void OnBnClickedBtn9();

	CStatic m_Curtain;
};
