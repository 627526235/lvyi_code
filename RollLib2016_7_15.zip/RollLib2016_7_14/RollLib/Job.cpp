#include "StdAfx.h"
#include "Job.h"


CJob::CJob ( )
{
	m_fpInteract	= NULL;

	m_pNext			= NULL;
}


CJob::~CJob ( )
{
}
