// Image.h: interface for the Image class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMAGE_H__DBF96251_8908_48A3_A58D_02CB0B585922__INCLUDED_)
#define AFX_IMAGE_H__DBF96251_8908_48A3_A58D_02CB0B585922__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Image  
{
public:
	Image();
	virtual ~Image();
	
	//BOOL CopyFrom(Image *a_pImg);
    //BOOL Create(int a_Width,int a_Height);
    //int FitBlt(HDC a_DestDC,int a_DestX,int a_DestY,int a_DestWidth,int a_DestHeight,int a_SrcX,int a_SrcY,int a_SrcWidth,int a_SrcHeight,DWORD a_Rop=SRCCOPY);
	//BOOL StretchBlt(HDC a_DestDC,int a_DestX,int a_DestY,int a_DestWidth,int a_DestHeight,int a_SrcX,int a_SrcY,int a_SrcWidth,int a_SrcHeight,DWORD a_Rop=SRCCOPY);
	//BOOL BitBlt(HDC a_DestDC,int a_DestX,int a_DestY,int a_Width,int a_Height,int a_SrcX,int a_SrcY,DWORD a_Rop=SRCCOPY);
	//BOOL SaveBitmap(CString a_Filename);
	//BOOL IsValid();
	void Destroy();
	CDC m_DC;
	BYTE * m_pBits;
	int m_ImageSize;
	int m_WidthBytes;
	int m_Height;
	//BOOL LoadBmpFile(CString a_Filename);
	int m_Width;

protected:
	HDC m_hMemDC;
	HBITMAP m_hBitmap;
private:
	HBITMAP m_hOldBitmap;

};

#endif // !defined(AFX_IMAGE_H__DBF96251_8908_48A3_A58D_02CB0B585922__INCLUDED_)
