// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

#pragma once

#include "MFCPropertyGridPropertyEx.h"
#include "MFCPropertyGridCtrlEx.h"

class CPropertiesToolBar : public CMFCToolBar
{
public:
	virtual void OnUpdateCmdUI(CFrameWnd* /*pTarget*/, BOOL bDisableIfNoHndler)
	{
		CMFCToolBar::OnUpdateCmdUI((CFrameWnd*) GetOwner(), bDisableIfNoHndler);
	}

	virtual BOOL AllowShowOnList() const { return FALSE; }
};

class CRollDoc;

class CDocRoll;
class CDocRollLib;
class CDocOrder;
class CPropertiesWnd : public CDockablePane
{
// ����
public:
	CPropertiesWnd();

	void AdjustLayout();

	int		m_iStatus;	// 1 CDocRollLib
						// 2 CDocRoll
						// 3 CDocOrder
	
	//------------------------------------------------begin yangfan 2016_4_12
	//CPropertyData   m_dataProperty_ListRoll;
	//------------------------------------------------end   yangfan 2016_4_12



	CRollDoc*		m_pDocCurrent;

	CDocRoll*		m_pDocRollCurrent;
	CDocRollLib*	m_pDocRollLibCurrent;
	CDocOrder*		m_pDocOrderCurrent;

// ����
public:
	void SetVSDotNetLook(BOOL bSet)
	{
//		m_wndPropList.SetVSDotNetLook(bSet);
//		m_wndPropList.SetGroupNameFullWidth(bSet);

		m_wndPropListOrder.SetVSDotNetLook(bSet);
		m_wndPropListOrder.SetGroupNameFullWidth(bSet);

		m_wndPropListLib.SetVSDotNetLook(bSet);
		m_wndPropListLib.SetGroupNameFullWidth(bSet);

		m_wndPropListRoll.SetVSDotNetLook(bSet);
		m_wndPropListRoll.SetGroupNameFullWidth(bSet);
	}

	void	initializeProperty ( CDocRoll* pDoc );
	void	initializeProperty ( CDocRollLib* pDoc );
	void	initializeProperty ( CDocOrder* pDoc );

	void	updateProperties ( CDocOrder* pDoc, bool bOnlyShow );
	void	updateProperties ( CDocRoll* pDoc, bool bOnlyShow );
	void	updateProperties ( CDocRollLib* pDoc );

	void	showProperties ( CDocOrder* pDoc );
	void	showProperties ( CDocRoll* pDoc );
	void	showProperties ( CDocRollLib* pDoc );

protected:
	CFont m_fntPropList;
	CComboBox m_wndObjectCombo;
	CPropertiesToolBar m_wndToolBar;

//	CMFCPropertyGridCtrl	m_wndPropList;
	CMFCPropertyGridCtrlEx	m_wndPropListOrder;
	CMFCPropertyGridCtrlEx	m_wndPropListLib;
	CMFCPropertyGridCtrlEx	m_wndPropListRoll;

	CMFCPropertyGridProperty*	m_pPropManufacturer;

// ʵ��
public:
	virtual ~CPropertiesWnd();

protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnExpandAllProperties();
	afx_msg void OnUpdateExpandAllProperties(CCmdUI* pCmdUI);
	afx_msg void OnSortProperties();
	afx_msg void OnUpdateSortProperties(CCmdUI* pCmdUI);
	afx_msg void OnProperties1();
	afx_msg void OnUpdateProperties1(CCmdUI* pCmdUI);
	afx_msg void OnProperties2();
	afx_msg void OnUpdateProperties2(CCmdUI* pCmdUI);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnSettingChange(UINT uFlags, LPCTSTR lpszSection);
	afx_msg	LRESULT OnPropertyChanged ( WPARAM wParam, LPARAM lParam );

	DECLARE_MESSAGE_MAP()

	void InitPropListLib ( );
	void InitPropListOrder ( );
	void InitPropListRoll ( );
	void SetPropListFont ( );
};

