// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// DocRollLib.h : CDocOrder ��Ľӿ�
//


#pragma once


#include "RollDoc.h"
//--------------------------begin yangfan 2016_6_13
#include "Image.h"
//--------------------------end   yangfan 2016_6_13

//------------------------begin yangfan 2016_7_13
#include"Texture.h"
//------------------------end   yangfan 2016_7_13

//--------------------------------------------begin yangfan 2016_7_15
#include<io.h>
#include<list>
#include<string>
//--------------------------------------------end   yangfan 2016_7_15

class CDocOrder : public CRollDoc
{
	
protected: // �������л�����
	CDocOrder();
	DECLARE_DYNCREATE(CDocOrder)

	//---------------------------------------------begin yangfan 2016_4_23
	virtual void	initializePropertyData ( );

	virtual void	updatePropertyData ( );

	virtual void	onItemChanged ( LPPROPERTY_DATA_ITEM pItem, CMFCPropertyGridPropertyEx* pProp );

	//---------------------------------------------end   yangfan 2016_4_23

// ����
public:

	//--------------------------------------------begin yangfan 2016_7_15
	int m_pictureCount;
	string readPath;
	vector<string> fileList;			//ɨ��ָ��·����õ�
	list<CString>  picturePath;			//�洢���·����vector
	HANDLE	m_hThreadCalculating;
	static DWORD __stdcall threadTextureIntoLib(LPVOID lpVoid);
	int FileCount;	//��Ҫ����Ŀ¼�°��ͼƬ�ĸ���
	void getAllFiles(string path, vector<string>& files);
	LPTEXTURE_FEATURE	m_pthreadFeature;
	CTexture *	m_pthreadTexture;
	//--------------------------------------------end   yangfan 2016_7_15

	//--------------------------------------------begin yangfan 2016_7_13
	LPTEXTURE_FEATURE	m_pFeature;
	CTexture *	m_pTexture;
	CImage* m_pFastSearImg;
	//--------------------------------------------end   yangfan 2016_7_13

	//--------------------------------------------begin yangfan 2016_6_13
	class Image *m_pCurImage,*m_pLastImage; //����ͼ����ָ��
	int cx,cy;
	//--------------------------------------------end   yangfan 2016_6_13

	//--------------------------------------------begin yangfan 2016_4_23
	//LPPROPERTY_DATA_ITEM  m_pItem_CustomerName;
	//LPPROPERTY_DATA_ITEM  m_pItem_CustomerTel;
	//LPPROPERTY_DATA_ITEM  m_pItem_CustomerIDCard;

	LPPROPERTY_DATA_ITEM	m_pItem_CustomerNumber;
	LPPROPERTY_DATA_ITEM	m_pItem_threshold;
	LPPROPERTY_DATA_ITEM	m_pItem_number_indent;
	LPPROPERTY_DATA_ITEM	m_pItem_time_indent;
	LPPROPERTY_DATA_ITEM	m_pItem_filepath;
	//--------------------------------------------end   yangfan 2016_4_23

	//-----------------------------------------------------begin yangfan 2016_4_25
	//=========================================�洢�û���DocRoll�������޸ĵ����ֵ
	//map<string,string> mapDocOrder_Customer;
	//map<string,string> mapDocOrder_Manager;
	//map<string,string> mapDocOrder_EdgeSheet;
	map<string,string> mapDocOrder_Indent;
	//-----------------------------------------------------end   yangfan 2016_4_25
	//--------------------------begin yangfan 2016_4_29
	bool updateNewCustomer;
	int m_nNumberIndent ;
	int m_nCurrentIndent;
	vector<indent_yf*> m_ResultIndent;
	vector<picIndent*>  m_ResultPicInd;

	//--------------------------begin yangfan 2016_5_13
	bool Query_DocOrder;
	//--------------------------end   yangfan 2016_5_13

	//--------------------------end yangfan 2016_4_29
	CImage*		m_pImageDisplay;
	int			m_iDisplay;			// 0, m_pImage
									// 1, m_pImage_1
									// ...

	void	setDisplay ( int iDisplay );
	void	doRollMatching ( CImage* pImage );

	CImage*		m_pImage;
	CString		m_strPath;
	int			m_iLength;

	long		m_lHeight;
	long		m_lWidth;
	DWORD		m_dwWidthBytes;
	DWORD		m_dwBitBytes;

	vector<picRoll*>	 m_Result;

	char		m_strQueryCmd [256];
	MYSQL_RES*	m_pResult;
	int			m_nNumRes;
	int			m_nCurrent;
	int			m_iIndex;

	//---------------------------------------begin yangfan 2016_7_14
	bool	m_bTestCalcu;
	//---------------------------------------end   yanfang 2016_7_14

	bool	m_bDoneCalculating;
	bool	m_bCalculating;
	vector<double>*	feature_result;

	vector<CImage*>*	match_result;
	vector<RollLib*>*	match_roll;

	vector<CImage*>*	findInDB ( vector<double>* features, float fThreshold );

	int		m_iCnt_matchRoll;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//	color separation
	int		m_iColors;	// ��ɫ����

	CImage*		m_pImage_1;	// separated color
	CImage*		m_pImage_2;	// separated color
	CImage*		m_pImage_3;	// separated color
	CImage*		m_pGray;	// gray image

	//CBitmap*	m_pBmp_1;
	//CBitmap*	m_pBmp_2;
	//CBitmap*	m_pBmp_3;

	LPBITMAPINFO	m_lpbiImage_1;
	LPBITMAPINFO	m_lpbiImage_2;
	LPBITMAPINFO	m_lpbiImage_3;
	LPBITMAPINFO	m_lpbiGray;

	RGBQUAD		m_rgbColor_1[256];
	RGBQUAD		m_rgbColor_2[256];
	RGBQUAD		m_rgbColor_3[256];
	RGBQUAD		m_rgbGray[256];

	void	generateHeaders ( );
	void	calculateFeatures ( );
//--------------------------------------------------------------------

	// stored in table rollInfo
	char		m_lpszCustomer [64];

	float	m_fThreshold;

// ����
public:
	CImage*	getSeparated_1 ( );
	CImage*	getSeparated_2 ( );
	CImage*	getSeparated_3 ( );

	CImage*	extractImage_1 ( CImage* pImageSrc, CDC* pDC );

	void	outputString ( CString strMsg, int iKind=0);

	void	refreshProperty ( );

protected:
	void	createMono ( );
	void	createDouble ( );
	void	createTrible ( );

// ��д
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// ʵ��
public:
	virtual ~CDocOrder();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	bool	m_bNewDoc;	// for surf the database
	bool	m_bQuery;	// query finished or not

	void	loadRollFile ( LPCTSTR lpszPathName );
	void	loadRollFile ( IStream* pStream );
	//-----------------------------------------------begin yangfan 2016_5_11
	void	updateIndent ( indent_yf* pIndent );
	void    updatePicInd ( picIndent* pPicInd );
	//-----------------------------------------------end   yangfan 2016_5_11

// ���ɵ���Ϣӳ�亯��
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// ����Ϊ�����������������������ݵ� Helper ����
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
public:
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void SetTitle(LPCTSTR lpszTitle);

	afx_msg void OnChkDouble();
	afx_msg void OnUpdateChkDouble(CCmdUI *pCmdUI);
	afx_msg void OnChkTrible();
	afx_msg void OnUpdateChkTrible(CCmdUI *pCmdUI);
	afx_msg void OnBtnColorSeparate();
	afx_msg void OnUpdateBtnColorSeparate(CCmdUI *pCmdUI);
	afx_msg void OnUpdateBtnFindFast(CCmdUI *pCmdUI);
	afx_msg void OnBtnFindFast();
	afx_msg void OnChkMono();
	afx_msg void OnUpdateChkMono(CCmdUI *pCmdUI);
	afx_msg void OnSldColor1Separation();
	afx_msg void OnUpdateSldColor1Separation(CCmdUI *pCmdUI);
	afx_msg void OnBtnDborderInsert();
	afx_msg void OnUpdateBtnDborderInsert(CCmdUI *pCmdUI);
	//---------------------------------------------------------begin yangfan 2016_4_26
	afx_msg void OnBtnOrderQuery();
	afx_msg void OnUpdateBtnOrderQuery(CCmdUI *pCmdUI);
	//afx_msg void OnBtnNewcustomer();
	//afx_msg void OnUpdateBtnNewcustomer(CCmdUI *pCmdUI);
	//---------------------------------------------------------end yangfan 2016_4_26
	afx_msg void OnDbOrderLast();
	afx_msg void OnDbOrderFirst();
	afx_msg void OnDbOrderPrev();
	afx_msg void OnDbOrderNext();
	afx_msg void OnUpdateDbOrderFirst(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDbOrderLast(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDbOrderPrev(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDbOrderNext(CCmdUI *pCmdUI);
	
	afx_msg void OnBtnInlib();
	afx_msg void OnUpdateBtnFastsearch(CCmdUI *pCmdUI);
	afx_msg void OnUpdateBtnInlib(CCmdUI *pCmdUI);
	afx_msg void OnBtnFastsearch();
};
