// MFCPropertyGridPropertyEx.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "RollLib.h"
#include "MFCPropertyGridPropertyEx.h"


// CMFCPropertyGridPropertyEx

//IMPLEMENT_DYNAMIC(CMFCPropertyGridPropertyEx, CMFCPropertyGridProperty)

CMFCPropertyGridPropertyEx::CMFCPropertyGridPropertyEx ( LPPROPERTY_DATA_ITEM pItem_root, DWORD_PTR dwData, BOOL bIsValueList )
: CMFCPropertyGridProperty ( pItem_root->m_strName, dwData, bIsValueList )
{
	LPPROPERTY_DATA_ITEM		pItem, pItem_next;
	CMFCPropertyGridPropertyEx*	pProp;

	pItem	= pItem_root->pKids;
	while ( pItem )
	{
		pItem_next	= pItem->pNext;

		pProp	= new CMFCPropertyGridPropertyEx ( pItem->m_strName, pItem->m_varValue, pItem->m_strDescr );

		pItem->m_pProp	= pProp;

		this->AddSubItem ( pProp );

		pItem	= pItem_next;
	}

	m_pItem	= NULL;
}

CMFCPropertyGridPropertyEx::CMFCPropertyGridPropertyEx ( CString strName, DWORD_PTR dwData, BOOL bIsValueList )
: CMFCPropertyGridProperty ( strName, dwData, bIsValueList )
{
	m_pItem	= NULL;
}

CMFCPropertyGridPropertyEx::CMFCPropertyGridPropertyEx ( LPPROPERTY_DATA_ITEM pItem, bool bReserved, DWORD_PTR dwData )
: CMFCPropertyGridProperty ( pItem->m_strName, pItem->m_varValue, pItem->m_strDescr )
{
	m_pItem	= NULL;
}

CMFCPropertyGridPropertyEx::CMFCPropertyGridPropertyEx(const CString &strName, 
	const COleVariant& varValue, LPCTSTR lpszDescr, DWORD_PTR dwData,
		LPCTSTR lpszEditMask, LPCTSTR lpszEditTemplate, LPCTSTR lpszValidChars) 
: CMFCPropertyGridProperty ( strName, varValue, lpszDescr, dwData, lpszEditMask, lpszValidChars  )
{
	m_pItem	= NULL;
}

CMFCPropertyGridPropertyEx::~CMFCPropertyGridPropertyEx()
{
}


//BEGIN_MESSAGE_MAP(CMFCPropertyGridPropertyEx, CMFCPropertyGridProperty)
//END_MESSAGE_MAP()



// CMFCPropertyGridPropertyEx ��Ϣ��������


