// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// RollDoc.cpp : CDocRoll ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "RollLib.h"
#endif

#include "DocRoll.h"
#include "DBmySQL.h"
#include "Compute.h"

#include <propkey.h>

#include "MainFrm.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDocRoll

IMPLEMENT_DYNCREATE(CDocRoll, CDocument)

BEGIN_MESSAGE_MAP(CDocRoll, CDocument)
	ON_COMMAND(ID_BTN_DB_INSERT, &CDocRoll::OnBtnDbInsert)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_INSERT, &CDocRoll::OnUpdateBtnDbInsert)
	ON_COMMAND(ID_BTN_DB_FIRST, &CDocRoll::OnBtnDbFirst)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_FIRST, &CDocRoll::OnUpdateBtnDbFirst)
	ON_COMMAND(ID_BTN_DB_LAST, &CDocRoll::OnBtnDbLast)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_LAST, &CDocRoll::OnUpdateBtnDbLast)
	ON_COMMAND(ID_BTN_DB_PREV, &CDocRoll::OnBtnDbPrev)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_PREV, &CDocRoll::OnUpdateBtnDbPrev)
	ON_COMMAND(ID_BTN_DB_DEL, &CDocRoll::OnBtnDbDel)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_DEL, &CDocRoll::OnUpdateBtnDbDel)
	ON_COMMAND(ID_BTN_DB_NEXT, &CDocRoll::OnBtnDbNext)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_NEXT, &CDocRoll::OnUpdateBtnDbNext)
	ON_COMMAND(ID_BTN_DB_QUERY, &CDocRoll::OnBtnDbQuery)
	ON_UPDATE_COMMAND_UI(ID_BTN_DB_QUERY, &CDocRoll::OnUpdateBtnDbQuery)
	ON_COMMAND(ID_CHK_DOUBLE, &CDocRoll::OnChkDouble)
	ON_UPDATE_COMMAND_UI(ID_CHK_DOUBLE, &CDocRoll::OnUpdateChkDouble)
	ON_COMMAND(ID_CHK_TRIBLE, &CDocRoll::OnChkTrible)
	ON_UPDATE_COMMAND_UI(ID_CHK_TRIBLE, &CDocRoll::OnUpdateChkTrible)
END_MESSAGE_MAP()


// CDocRoll ����/����
void CDocRoll::generateHeaders ( )
{
	int		i;
	DWORD	dwHeaderSize;
	char*	pBuffer;

	ASSERT ( m_lHeight );
	ASSERT ( m_lWidth );

	m_dwWidthBytes	= ((m_lWidth + 3) >> 2) << 2;
	m_dwBitBytes	= m_dwWidthBytes * (DWORD)m_lHeight;

	dwHeaderSize	= sizeof( BITMAPINFOHEADER ) + (sizeof( RGBQUAD ) << 8);
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_1	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_2	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiImage_3	= (LPBITMAPINFO) pBuffer;
	pBuffer			= new char[dwHeaderSize];
	m_lpbiGray		= (LPBITMAPINFO) pBuffer;

	m_lpbiImage_1->bmiHeader.biSize			= sizeof( BITMAPINFOHEADER );
	m_lpbiImage_1->bmiHeader.biWidth		= m_lWidth;
	m_lpbiImage_1->bmiHeader.biHeight		= m_lHeight;
	m_lpbiImage_1->bmiHeader.biPlanes		= 1;
	m_lpbiImage_1->bmiHeader.biBitCount		= 8;
	m_lpbiImage_1->bmiHeader.biSizeImage	= m_dwBitBytes;
	m_lpbiImage_1->bmiHeader.biCompression	= BI_RGB;
	m_lpbiImage_1->bmiHeader.biXPelsPerMeter= 0;
	m_lpbiImage_1->bmiHeader.biYPelsPerMeter= 0;
	m_lpbiImage_1->bmiHeader.biClrUsed		= 256;
	m_lpbiImage_1->bmiHeader.biClrImportant	= 0;

	memcpy ( m_lpbiImage_2, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );
	memcpy ( m_lpbiImage_3, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );
	memcpy ( m_lpbiGray, m_lpbiImage_1, sizeof(BITMAPINFOHEADER) );

	for ( i=0; i<256; i++ )
	{
		m_lpbiImage_1->bmiColors[i].rgbBlue		= 0;
		m_lpbiImage_1->bmiColors[i].rgbGreen	= 0;
		m_lpbiImage_1->bmiColors[i].rgbRed		= i;
		m_lpbiImage_1->bmiColors[i].rgbReserved	= 0;

		m_lpbiImage_2->bmiColors[i].rgbBlue		= 0;
		m_lpbiImage_2->bmiColors[i].rgbGreen	= i;
		m_lpbiImage_2->bmiColors[i].rgbRed		= 0;
		m_lpbiImage_2->bmiColors[i].rgbReserved	= 0;

		m_lpbiImage_3->bmiColors[i].rgbBlue		= i;
		m_lpbiImage_3->bmiColors[i].rgbGreen	= 0;
		m_lpbiImage_3->bmiColors[i].rgbRed		= 0;
		m_lpbiImage_3->bmiColors[i].rgbReserved	= 0;

		m_lpbiGray->bmiColors[i].rgbBlue		= i;
		m_lpbiGray->bmiColors[i].rgbGreen		= i;
		m_lpbiGray->bmiColors[i].rgbRed			= i;
		m_lpbiGray->bmiColors[i].rgbReserved	= 0;

		m_rgbColor_1[i].rgbBlue		= i;
		m_rgbColor_1[i].rgbGreen	= i;
		m_rgbColor_1[i].rgbRed		= i;
		m_rgbColor_1[i].rgbReserved	= 0;

		m_rgbColor_2[i].rgbBlue		= i;
		m_rgbColor_2[i].rgbGreen	= i;
		m_rgbColor_2[i].rgbRed		= i;
		m_rgbColor_2[i].rgbReserved	= 0;

		m_rgbColor_3[i].rgbBlue		= i;
		m_rgbColor_3[i].rgbGreen	= i;
		m_rgbColor_3[i].rgbRed		= i;
		m_rgbColor_3[i].rgbReserved	= 0;

		m_rgbGray[i].rgbBlue		= i;
		m_rgbGray[i].rgbGreen		= i;
		m_rgbGray[i].rgbRed			= i;
		m_rgbGray[i].rgbReserved	= 0;
	}
}

CDocRoll::CDocRoll()
{

	//--------------------------begin yangfan 2016_7_13
	m_pTexture = new CTexture;
	m_pFeature = NULL;
	//--------------------------end   yangfan 2016_7_13

	//----------------------------------------------------------begin yangfan 2016_4_12
	m_infoRollResult_roll =  CInfoRoll_ex::QueryInfoRoll_ex();
	m_Result_roll      	  =  CPicRoll_ex::QueryPicRoll_ex();
	m_nNumRes	= (int)m_Result_roll.size();
	//----------------------------------------------------------end   yangfan 2016_4_12

	m_strIdentifier		= _T("δ���");
	m_strManufacturer	= _T("����������������");

	m_pImage	= NULL;

	m_bReadyInsert	= FALSE;
	m_bModified		= TRUE;

	m_lpbiImage_1	= NULL;
	m_lpbiImage_2	= NULL;
	m_lpbiImage_3	= NULL;
	m_lpbiGray		= NULL;

	m_pImage_1	= NULL;
	m_pImage_2	= NULL;
	m_pImage_3	= NULL;
	m_pGray		= NULL;

	m_lHeight	= 0;
	m_lWidth	= 0;

	m_bNewDoc	= false;
	m_bQuery	= false;

	m_bDouble	= true;

	//-----------------------------begin yangfan 2016_4_12
	m_nCurrent	= m_nNumRes;
	//m_nNumRes	= 0;
	//-----------------------------end   yangfan 2016_4_12


	m_iIndex	= -1;

	m_pResult	= NULL;

	feature_result	= NULL;

	m_bDoneCalculating	= true;
	m_bCalculating		= false;
}

CDocRoll::~CDocRoll()
{

	//--------------------------begin yangfan 2016_7_13
	if(m_pTexture)
		delete m_pTexture;
	//delete pFeature;
	LPTEXTURE_FEATURE	pNext;

	while (m_pFeature)
	{
		pNext = m_pFeature->pNext;

		delete	m_pFeature;

		m_pFeature = pNext;
	}
	//--------------------------end   yangfan 2016_7_13

	int		i, iSize;

	if ( m_lpbiImage_1 )
		delete	m_lpbiImage_1;

	if ( m_lpbiImage_2 )
		delete	m_lpbiImage_2;

	if ( m_lpbiImage_3 )
		delete	m_lpbiImage_3;

	if ( m_lpbiGray )
		delete	m_lpbiGray;

	if ( m_pImage )
		delete	m_pImage;

	if ( m_pImage_1 )
		delete	m_pImage_1;

	if ( m_pImage_2 )
		delete	m_pImage_2;

	if ( m_pImage_3 )
		delete	m_pImage_3;

	if ( m_pGray )
		delete	m_pGray;

	//if ( m_pBmp_1 )
	//	delete	m_pBmp_1;

	//if ( m_pBmp_2 )
	//	delete	m_pBmp_2;

	//if ( m_pBmp_3 )
	//	delete	m_pBmp_3;

	if ( m_pResult )
		mysql_free_result ( m_pResult );

	if ( feature_result)
		delete	feature_result;
	//---------------------begin yangfan 2016_4_12
	iSize	= (int)m_Result_roll.size();
	for ( i=0; i<iSize; i++ )
		delete m_Result_roll[i];
	//---------------------end yangfan 2016_4_12
}

BOOL CDocRoll::OnNewDocument()
{
	m_bNewDoc	= true;

	if (!CDocument::OnNewDocument())
		return FALSE;

	// surf the database

	return TRUE;
}




// CDocRoll ���л�

void CDocRoll::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: �ڴ����Ӵ洢����
	}
	else
	{
		// TODO: �ڴ����Ӽ��ش���
	}
}

#ifdef SHARED_HANDLERS

// ����ͼ��֧��
void CDocRoll::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// �޸Ĵ˴����Ի����ĵ�����
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// �������������֧��
void CDocRoll::InitializeSearchContent()
{
	CString strSearchContent;
	// ���ĵ����������������ݡ�
	// ���ݲ���Ӧ�ɡ�;���ָ�

	// ����:  strSearchContent = _T("point;rectangle;circle;ole object;")��
	SetSearchContent(strSearchContent);
}

void CDocRoll::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CDocRoll ���

#ifdef _DEBUG
void CDocRoll::AssertValid() const
{
	CDocument::AssertValid();
}

void CDocRoll::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CDocRoll ����

BOOL CDocRoll::OnOpenDocument(LPCTSTR lpszPathName)
{
//	if (!CDocument::OnOpenDocument(lpszPathName))
//		return FALSE;

	m_pImage	= new CImage;

	m_pImage->Load ( lpszPathName );

	m_lHeight	= m_pImage->GetHeight ( );
	m_lWidth	= m_pImage->GetWidth ( );

	generateHeaders ( );
	m_bDoneCalculating	= false;	// header ready, do calculating

	m_strPath	= lpszPathName;

	CFile	file;

	file.Open ( lpszPathName, CFile::modeRead );

	m_iLength	= (int)file.GetLength ( );

	file.Close ( );

	return TRUE;
}

//---------------------------------------------------------------------------begin   yangfan  2016_4_13
void CDocRoll::updatePropertyData()
{
	m_pItem_filePath_roll->m_pProp->m_pItem = m_pItem_filePath_roll;
	m_pItem_manufacturer_roll->m_pProp->m_pItem	= m_pItem_manufacturer_roll;
	m_pItem_createtime_roll->m_pProp->m_pItem = m_pItem_createtime_roll;
	m_pItem_id_roll->m_pProp->m_pItem = m_pItem_id_roll;
}
//---------------------------------------------------------------------------end     yangfan  2016_4_12

//---------------------------------------------------------------------------begin   yangfan  2016_4_12
void CDocRoll::onItemChanged ( LPPROPERTY_DATA_ITEM pItem, CMFCPropertyGridPropertyEx* pProp )
{
	//-----------------------------------------------------------------------begin yangfan 2016_4_15
	//MessageBox(AfxGetMainWnd()->GetSafeHwnd(),_T("������RollView���Խ���"),_T("��ʾ"),MB_OK);
	COleVariant			varNewValue;
	COleVariant			varOldValue;
	varNewValue	= pProp->GetValue ( );
	varOldValue	= pProp->GetOriginalValue ( );

	USES_CONVERSION;
	string strNewValue = W2A(varNewValue.bstrVal);

	CString DocRollPropItemName = pProp->m_pItem->m_strName;
	string s = W2A(DocRollPropItemName);

	
	mapDocRoll[s] = strNewValue;
	//string test = "e";
	//-----------------------------------------------------------------------end  yangfan  2016_4_15




	//===================================================================cancel by yangfan 2016_4_15
	//*******************************************************************because we need to get value of modified item 
	/*
	FP_INFO_ROLL_EX		pFP;
	//-----------------------------------------------begin yangfan 2016_3_30
	FP_PIC_ROLL_EX		pFP_pic;
	pFP_pic = pItem->m_pFP_picRoll;
	//-----------------------------------------------end   yangfan 2016_3_30
	COleVariant			varNewValue;
	COleVariant			varOldValue;

	m_bDirty	= true;

	pItem->onItemChanged ( pProp );

	pFP	= pItem->m_pFP_infoRoll;
	if ( pFP )
	{
		LPINFO_ROLL_EX	pInfo;

		varNewValue	= pProp->GetValue ( );
		varOldValue	= pProp->GetOriginalValue ( );

		pInfo	= m_infoRollResult_roll.at(m_nCurrent);

		USES_CONVERSION;
		(pInfo->*pFP)( W2A(varNewValue.bstrVal) );

		pInfo->Save ( );
	}
	//-----------------------------------------------begin yangfan 2016_3_30
	if(pFP_pic)//pItem->m_strName=="�洢·��"
	{
		LPPIC_ROLL_EX	pPic;
		varNewValue	= pProp->GetValue ( );
		varOldValue	= pProp->GetOriginalValue ( );
		pPic = m_Result_roll.at(m_nCurrent);
		USES_CONVERSION;
		(pPic->*pFP_pic)( W2A(varNewValue.bstrVal) );
		pPic->Save();
	}
	//-----------------------------------------------end   yangfan 2016_3_30
	*/
	//===================================================================cancel by yangfan 2016_4_15
}
//---------------------------------------------------------------------------end   yangfan  2016_4_12




//---------------------------------------------------------------------------begin   yangfan  2016_4_12
void CDocRoll::initializePropertyData()
{
	CMainFrame*				pMain;
	LPPROPERTY_DATA_ITEM	pItem;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );

	pItem	= m_dataProperty.addItem (  _T("����") );
	m_pItem_manufacturer_roll	= pItem->addSubItem ( _T("��������"), _T("����"), _T("�༭����") );
	m_pItem_manufacturer_roll->m_pFP_infoRoll	= (FP_INFO_ROLL_EX)&CInfoRoll_ex::updateManufacturer;
	
	m_pItem_manufacturer_roll->m_pFP_picRoll = NULL;

	
	LPPROPERTY_DATA_ITEM	pCreTimItem;
	pCreTimItem = m_dataProperty.addItem(_T("ʱ��"));
	m_pItem_createtime_roll = pCreTimItem->addSubItem(_T("ʱ��"), _T("00:00 1970/1/1"), _T("�༭ʱ��"));
	m_pItem_createtime_roll->m_pFP_infoRoll = (FP_INFO_ROLL_EX)&CInfoRoll_ex::updateCreatetime;
	
	m_pItem_createtime_roll->m_pFP_picRoll = NULL;
	
	
	
	
	
	LPPROPERTY_DATA_ITEM	pIdItem;
	pIdItem = m_dataProperty.addItem(_T("���"));
	m_pItem_id_roll = pIdItem->addSubItem(_T("���"), _T("0"), _T("�༭���"));
	m_pItem_id_roll->m_pFP_infoRoll = (FP_INFO_ROLL_EX)&CInfoRoll_ex::updateId;
	
	m_pItem_id_roll->m_pFP_picRoll = NULL;
	
	
	
	
	LPPROPERTY_DATA_ITEM	pFilePathItem;
	pFilePathItem = m_dataProperty.addItem(_T("�洢·��"));
	//----------------------------------------------------------------------------------------begin yangfan 2016_4_17
	//===============================================================���м�Ĳ����ĳɵ���½������ť��õ���ͼƬ·��
	m_pItem_filePath_roll = pFilePathItem->addSubItem(_T("�洢·��"),m_strPath, _T("�༭·��"));//CString2str(m_strPath) _T("X:\\default.jpg")
	//===============================================================���м�Ĳ����ĳɵ���½������ť��õ���ͼƬ·��

	m_pItem_filePath_roll->m_pFP_picRoll = (FP_PIC_ROLL_EX)&CPicRoll_ex::updateFilePath;
	
	m_pItem_filePath_roll->m_pFP_infoRoll = NULL;
	
	

	pMain->initializeProperty ( this );
}
//---------------------------------------------------------------------------end   yangfan  2016_4_12

// yangfan
void CDocRoll::OnBtnDbInsert()
{
	CString		strMsg;
	LPDB_MYSQL	pDB;
	infoRoll*	pInfoRoll;
	picRoll*	pPicRoll;
	CMainFrame*	pMain;
	pDB	= CDBmySQL::getDB();
	// check the input info
    
	//------------------------------------------------------begin yangfan 2016_4_15 , enable MessageBox which cancled before
	// pop out a warning
	if ( IDYES != MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
		_T("��ǰ�İ��ɨ��ͼ�������浽���ݿ���\r\n������?"),
		_T("ȷ��"),	MB_ICONINFORMATION | MB_YESNOCANCEL) )
	{
		return;
	}
	//------------------------------------------------------end  yangfan  2016_4_15

	//------------------------------------------------------begin yangfan  2016_4_16
	map<string,string>::iterator iter;
	string strValue[4] = {CString2str(m_strPath),"0","00:00 1970/1/1","����"};//"X:\\default.jpg"
	for(iter=mapDocRoll.begin();iter!=mapDocRoll.end();++iter)
	{
		string strItem = iter->first;
		if( strItem == "��������" )
		{
			strValue[3] = iter->second;
		}
		else if( strItem == "ʱ��" )
		{
			strValue[2] = iter->second;
		}
		else if( strItem=="���" )
		{
			strValue[1] = iter->second;
		}
		else
		{
			strValue[0] = iter->second;
		}
	}
	pInfoRoll = new infoRoll( strValue[1],strValue[2],strValue[3],-1 ,-1 );
	pInfoRoll->Save();

	//------------------------------------------------------end   yangfan  2016_4_16

	

	while ( !m_bDoneCalculating )
		Sleep ( 100 );
	
	//------------------------------------------------------begin  yangfan 2016_4_16, cancel
	//pInfoRoll = new infoRoll();	//�����ԣ����õ���DBmySQL.h�е��ж�������Ĺ��캯����65��
	//pInfoRoll->Save();
	//------------------------------------------------------end    yangfan 2016_4_16, cancel

	pPicRoll = new picRoll(CString2str(m_strPath),pInfoRoll->getId());
	pPicRoll->Save();

	//CImage*	pImage;

	//CCompute main_compute;
	//main_compute.OpenImage( m_strPath );	// yangfan dong
	//vector<double> feature_result = main_compute.ComputeFeature();
	
	//----------------------------begin yangfan 2016_7_13
	/*
	featureRoll* pFeatureRoll = new featureRoll( (float)feature_result->at(0),
		(float)feature_result->at(1), (float)feature_result->at(2),
		0.0,	//(float)feature_result->at(3),
		(float)feature_result->at(4), pInfoRoll->getId() );
	*/
	featureRoll* pFeatureRoll = new featureRoll(m_pFeature->fEnergy,m_pFeature->fEntropy,
		m_pFeature->fInertiaQuadrature,m_pFeature->fCorrelation,m_pFeature->fLocalCalm,pInfoRoll->getId() );
	//----------------------------end  yangfan 2016_7_13

	pFeatureRoll->Save();

	strMsg.Format( _T("������в����¼�¼��������: %d"), pInfoRoll->getId() );
	outputString ( strMsg );

	delete	pFeatureRoll;

	delete	pPicRoll;
	delete	pInfoRoll;

	// insert the current document into DB
//	pDB->insertRollFile ( -1, CString2str(m_strPath), m_iLength );

	m_bNewDoc	= true;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	pMain->switch2RollLibView ( TRUE );

	CDocument::OnCloseDocument ( );
}


void CDocRoll::SetTitle(LPCTSTR lpszTitle)
{
	CString	 strTitle ( lpszTitle );

	if ( 0 == strTitle.Left(6).Compare(_T("��������ļ�")) )
	{
		CDocument::SetTitle ( _T("��������") );
		return;
	}

	CDocument::SetTitle(lpszTitle);
}


void CDocRoll::loadRollFile ( IStream* pStream )
{
	CImage*		pImage;
	CImage*		pImageOld;

	pImage	= new CImage;

	pImage->Load ( pStream );

	pImageOld	= m_pImage;
	m_pImage	= pImage;

	UpdateAllViews ( NULL );

	if ( pImageOld )
		delete	pImageOld;

	refreshProperty ( );
}

void CDocRoll::loadRollFile ( LPCTSTR lpszPathName )
{
	CImage*		pImage;
	CImage*		pImageOld;

	pImage	= new CImage;

	pImage->Load ( m_strPath );

	CFile	file;

	file.Open ( m_strPath, CFile::modeRead );

	m_iLength	= (int)file.GetLength ( );

	file.Close ( );

	pImageOld	= m_pImage;
	m_pImage	= pImage;

	UpdateAllViews ( NULL );

	if ( pImageOld )
		delete	pImageOld;

	refreshProperty ( );
}

void CDocRoll::outputString ( CString strMsg, int iKind/* =0 */ )
{
	CMainFrame*	pMain;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
	pMain->outputString ( strMsg, iKind );
}

void CDocRoll::refreshProperty ( )
{
	CMainFrame*	pMain;

	pMain	= (CMainFrame*) AfxGetMainWnd ( );
//	pMain->refreshProperty ( this );
}


CImage* CDocRoll::extractImage_1 ( CImage* pImageSrc, CDC* pDC )
{
	CImage*	pImage	= NULL;

	return	pImage;
}

void CDocRoll::OnUpdateBtnDbInsert(CCmdUI *pCmdUI)
{
	pCmdUI->Enable ( m_bReadyInsert );
}

void CDocRoll::calculateFeatures ( )
{
	CDC			memDC;
	HDC			hDC;
	CDC*		pDC;
	HBITMAP		hBitmap, hOld;
	LPBYTE		ppvBits;

	if ( m_bDoneCalculating )
	{
		Sleep ( 20 );
		return;
	}

	if ( m_bCalculating )
	{
		Sleep ( 20 );
		return;
	}

	m_bCalculating	= true;

	hDC	= m_pImage->GetDC ( );
	pDC	= CDC::FromHandle ( hDC );

	memDC.DeleteDC ( );
	memDC.CreateCompatibleDC ( pDC );

	// m_pGray
	hBitmap	= CreateDIBSection ( hDC, m_lpbiGray, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pGray )
		delete	m_pGray;

	m_pGray	= new CImage;
	m_pGray->Attach ( hBitmap );

	m_pImage->ReleaseDC ( );

	//----------------------------------------begin yangfan 2016_7_13
	//block former code and replace
	/*
	CCompute	main_compute;

	main_compute.openImage ( m_pGray, ppvBits );

	feature_result	= main_compute.ComputeFeature ( ); 
	*/
	m_pFeature = m_pTexture->computingFeatures(m_pGray);
	//----------------------------------------end yangfan 2016_7_13

	m_bDoneCalculating	= true;	// all has been calculated
	m_bCalculating		= false;
	m_bReadyInsert		= TRUE;
}