#ifndef	__PIC_ROLL_EX_H__
#define	__PIC_ROLL_EX_H__

#include "DBmySQLEx.h"

typedef class CPicRoll_ex	PIC_ROLL_EX, *LPPIC_ROLL_EX;

typedef	void (CPicRoll_ex::*FP_PIC_ROLL_EX)( string );

class CPicRoll_ex : public picRoll
{
public:
	//begin yangfan----------------------------------2016_3_30
	void     updateFilePath( string );  
	//end   yangfan----------------------------------2016_3_30
	static vector<LPPIC_ROLL_EX>	QueryPicRoll_ex ( );
public:
	CPicRoll_ex ( int _id, CStringA _filePath,
					char* _data, unsigned long _size,
					int _id_infoRoll)
					: picRoll(_id, _filePath, _data,
					_size, _id_infoRoll)
	{}
	CPicRoll_ex ( CStringA _filePath, int _id_infoRoll ) :picRoll(_filePath,_id_infoRoll){}
	
};

#endif