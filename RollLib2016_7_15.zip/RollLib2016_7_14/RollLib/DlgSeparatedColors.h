#pragma once


// CDlgSeparatedColors �Ի���
#include "Resource.h"
#include "BtnST.h"
#include "afxwin.h"

class CDocOrder;
class CDlgSeparatedColors : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgSeparatedColors)

public:
	void	UpdateSeparatedColors ( CDocOrder* pDoc );

	CDocOrder*	m_pDoc;

	CImage*		m_pImage_1;
	CImage*		m_pImage_2;
	CImage*		m_pImage_3;

	CImage*		m_pImage_1m;
	CImage*		m_pImage_2m;
	CImage*		m_pImage_3m;

	CImage*		m_pImage;

	void	clear ( );

public:
	CDlgSeparatedColors(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgSeparatedColors();

// �Ի�������
	enum { IDD = IDD_DLG_SEPARATED_COLOR };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

public:
	CButtonST	m_btnImage_1;
	CButtonST	m_btnImage_2;
	CButtonST	m_btnImage_3;
	CButtonST	m_btnImage_4;
	CButtonST	m_btnImage_1m;
	CButtonST	m_btnImage_2m;
	CButtonST	m_btnImage_3m;

	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedBtn1();
	afx_msg void OnBnClickedBtn2();
	afx_msg void OnBnClickedBtn3();
	afx_msg void OnBnClickedBtn4();
	afx_msg void OnBnClickedBtn1m();
	afx_msg void OnBnClickedBtn2m();
	afx_msg void OnBnClickedBtn3m();
};
