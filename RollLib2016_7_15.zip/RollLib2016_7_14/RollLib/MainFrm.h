// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// MainFrm.h : CMainFrame ��Ľӿ�
//

#pragma once
#include "FileView.h"
#include "ClassView.h"
#include "OutputWnd.h"
#include "PropertiesWnd.h"
#include "CalendarBar.h"
#include "Resource.h"

class COutlookBar : public CMFCOutlookBar
{
	virtual BOOL AllowShowOnPaneMenu() const { return TRUE; }
	virtual void GetPaneName(CString& strName) const { BOOL bNameValid = strName.LoadString(IDS_OUTLOOKBAR); ASSERT(bNameValid); if (!bNameValid) strName.Empty(); }
};

class CDocRoll;
class CDocRollLib;
class CDocOrder;
class CMainFrame : public CMDIFrameWndEx
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

	//-----------------------------------begin yangfan 2016_4_29
	//bool updateBtnOrderQuery;
	//int m_nNumberIndent ;
	//vector<indent_yf*> m_ResultIndent;
	//-----------------------------------end   yangfan 2016_4_29

// ����
public:
	CDocRoll*		m_pDocRollCurrent;
	CDocRollLib*	m_pDocRollLibCurrent;
	CDocOrder*		m_pDocOrderCurrent;

// ����
public:

	//------------------------------------------begin yangfan 2016_6_13
	void ShowScale(int a_Scale);  //��״̬������ʾͼ����ʾ����
	//------------------------------------------end   yangfan 2016_6_13



	CPropertiesWnd*	getPropertyWnd ( ){return &m_wndProperties;};

	void	outputString ( CString strMsg, int iKind=1 );

	void	setCurrentDoc ( CDocRoll* pDoc, bool bRefreshProperty=true );
	void	setCurrentDoc ( CDocRollLib* pDoc, bool bRefreshProperty=true );
	void	setCurrentDoc ( CDocOrder* pDoc, bool bRefreshProperty=true );

	void	refreshProperty ( CDocRoll* pDoc, bool bOnlyShow=true );
	void	refreshProperty ( CDocRollLib* pDoc );
	void	refreshProperty ( CDocOrder* pDoc, bool bOnlyShow=true );

	void	initializeProperty ( CDocRoll* pDoc );
	void	initializeProperty ( CDocRollLib* pDoc );
	void	initializeProperty ( CDocOrder* pDoc );

	void	refreshSeparatedColors ( CDocOrder* pDoc );
	void	refreshRollMatches ( CDocOrder* pDoc );

	void	switchGUI ( CDocRollLib* pDoc );
	//----------------------------begin yangfan 2016_5_10
	void	switchGUI ( CDocOrder* pDoc );
	//----------------------------end   yangfan 2016_5_10

	void	SwitchToView ( CDocTemplate* pTemplate, CRuntimeClass* pViewClass );
	void	CloseView ( CDocTemplate* pTemplate, CRuntimeClass* pViewClass );

	BOOL	switch2RollLibView ( BOOL bLast=FALSE );
	//----------------------------begin yangfan 2016_5_10
	BOOL	switch2DocOrderView ( BOOL bLast=FALSE );
	//----------------------------end   yangfan 2016_5_10

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// ʵ��
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CMFCRibbonBar     m_wndRibbonBar;

protected:  // �ؼ���Ƕ���Ա
	CMFCRibbonApplicationButton m_MainButton;
	CMFCToolBarImages m_PanelImages;
	CMFCRibbonStatusBar  m_wndStatusBar;
	CFileView         m_wndFileView;
	CClassView        m_wndClassView;
	COutputWnd        m_wndOutput;
	CPropertiesWnd    m_wndProperties;
	COutlookBar       m_wndNavigationBar;
	CMFCShellTreeCtrl m_wndTree;
	CCalendarBar      m_wndCalendar;
	CMFCCaptionBar    m_wndCaptionBar;
	//-----------------------------------begin yangfan 2016_6_13
	CStatusBar  m_wndStatusBars;
	//-----------------------------------end   yangfan 2016_6_13
// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnWindowManager();
	afx_msg void OnApplicationLook(UINT id);
	afx_msg void OnUpdateApplicationLook(CCmdUI* pCmdUI);
	afx_msg void OnViewCaptionBar();
	afx_msg void OnUpdateViewCaptionBar(CCmdUI* pCmdUI);
	afx_msg void OnOptions();
	afx_msg void OnSettingChange(UINT uFlags, LPCTSTR lpszSection);
	DECLARE_MESSAGE_MAP()

	BOOL CreateDockingWindows();
	void SetDockingWindowIcons(BOOL bHiColorIcons);
	BOOL CreateOutlookBar(CMFCOutlookBar& bar, UINT uiID, CMFCShellTreeCtrl& tree, CCalendarBar& calendar, int nInitialWidth);
	BOOL CreateCaptionBar();

	int FindFocusedOutlookWnd(CMFCOutlookBarTabCtrl** ppOutlookWnd);

	CMFCOutlookBarTabCtrl* FindOutlookParent(CWnd* pWnd);
	CMFCOutlookBarTabCtrl* m_pCurrOutlookWnd;
	CMFCOutlookBarPane*    m_pCurrOutlookPage;
public:
	afx_msg void OnClose();
	afx_msg void OnBtnNewcustomer();
	afx_msg void OnBtnOrderQuery();
	afx_msg void OnUpdateBtnOrderQuery(CCmdUI *pCmdUI);
};


