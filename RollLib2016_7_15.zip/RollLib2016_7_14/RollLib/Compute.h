#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GrayShow.h"
#include<vector>
using namespace std;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// 2015_12_11, jicheng, load image from a CImage object, begin
// 2015_12_11, jicheng, load image from a CImage object, end
//--------------------------------------------------------------------
class CCompute
{
public:
	CGrayShow m_grayShow; //����һ���Ҷȹ��־�����
	double	m_dCorrelation;
	double	m_dEnergy;
	double	m_dEntropy;
	double	m_dInertiaQuadrature;
	double	m_dLocalCalm;

	void nrerror(char*);
	void OpenImage(CString& FilePathName);
	vector<double>* ComputeFeature();
	unsigned char **cmatrix(long nrl,long nrh,long ncl,long nch);

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
// 2015_12_11, jicheng, load image from a CImage object, begin
	void	free_cmatrix ( unsigned char** m, long nrl, long nrh, long ncl, long nch );
	void	openImage ( CImage* pImage, LPBYTE lpBits  );
// 2015_12_11, jicheng, load image from a CImage object, end
//--------------------------------------------------------------------
};