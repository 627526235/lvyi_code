

#include "stdafx.h"


#ifndef SHARED_HANDLERS
#include "RollLib.h"
#endif

#include "RollDoc.h"
#include "DBmySQL.h"
#include "Compute.h"
#include "RollView.h"

#include <propkey.h>

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CRollDoc
void CRollDoc::calculateFeatures ( )
{
	CDC			memDC;
	HDC			hDC;
	CDC*		pDC;
	HBITMAP		hBitmap, hOld;
	LPBYTE		ppvBits;

	if ( m_bDoneCalculating )
	{
		Sleep ( 20 );
		return;
	}

	if ( m_bCalculating )
	{
		Sleep ( 20 );
		return;
	}

	m_bCalculating	= true;

	hDC	= m_pImage->GetDC ( );
	pDC	= CDC::FromHandle ( hDC );

	memDC.DeleteDC ( );
	memDC.CreateCompatibleDC ( pDC );

	// m_pGray
	hBitmap	= CreateDIBSection ( hDC, m_lpbiGray, DIB_RGB_COLORS, (void**)&ppvBits, NULL, 0 );

	hOld	= (HBITMAP) memDC.SelectObject ( hBitmap );

	m_pImage->BitBlt ( memDC.m_hDC, 0, 0, m_lWidth, m_lHeight, 0, 0, SRCCOPY );

	GdiFlush ( );
	memDC.SelectObject ( hOld );

	if ( m_pGray )
		delete	m_pGray;

	m_pGray	= new CImage;
	m_pGray->Attach ( hBitmap );

	m_pImage->ReleaseDC ( );

	//----------------------------------------begin yangfan 2016_7_13
	/*
	CCompute	main_compute;

	main_compute.openImage ( m_pGray, ppvBits );

	feature_result	= main_compute.ComputeFeature ( );
	*/
	m_pFeature = m_pTexture->computingFeatures(m_pGray);
	//------------------------------------------end yangfan 2016_7_13

	m_bDoneCalculating	= true;	// all has been calculated
	m_bCalculating		= false;
}

