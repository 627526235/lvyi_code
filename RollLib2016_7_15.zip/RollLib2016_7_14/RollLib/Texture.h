#ifndef _TEXTURE_H_
#define	_TEXTURE_H_

//#define _AFXDLL

#include <afxwin.h>

#include <atlimage.h>

typedef	struct tagTextureFeature	TEXTURE_FEATURE, *LPTEXTURE_FEATURE;

struct tagTextureFeature
{
	int		iX;
	int		iY;
	long	lWidth;
	long	lHeight;
	int		iDistance;

	float	fEnergy;			// ����
	float	fEntropy;			// ��
	float	fInertiaQuadrature;	// ���Ծ�
	float	fCorrelation;		// ���
	float	fLocalCalm;			// �ֲ�ƽ��

	LPTEXTURE_FEATURE	pNext;

	tagTextureFeature() { pNext = NULL; }
};

void free(LPTEXTURE_FEATURE pFeature);

class CTexture
{
public:
	void	setData(LPBYTE lpBytes, long lWidth, long lHeight);
	void	setImage(CImage* pImage) {}

	LPTEXTURE_FEATURE	computingFeatures(CImage* pImage);

protected:
	CImage*	m_pGray;

	LPBYTE	m_lpBytes;
	long	m_lWidthBytes;
	long	m_lBitBytes;
	long	m_lWidth;
	long	m_lHeight;

	int		m_iGrayLevel;	// if count number of gray levels is equal to 8, this value would be 3
							// that means, 1 << m_iGrayLevel is the count number of gray levels

	int**	m_ppGLCM;	// Gray Level Co-occurrence Matrix

	LPBITMAPINFO	m_lpbiGray;

	CImage*	converToGray(CImage* pImage, LPBYTE* ppvBits);

	void	generateHeader(BYTE yGrayLevel);

	LPTEXTURE_FEATURE	computingFeatures(LPBYTE lpBits, BYTE yGrayLevel, int iDistance, int x, int y, int iWidth, int iHeight);
	LPTEXTURE_FEATURE	ComputeFeature(int** pMatrix, int dim);

public:
	CTexture();
	~CTexture();
};

#endif // !_TEXTURE_H_