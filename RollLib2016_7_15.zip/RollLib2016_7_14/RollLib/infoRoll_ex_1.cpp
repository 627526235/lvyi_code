#include "StdAfx.h"
#include "infoRoll_ex.h"

//-------------------------------------begin yangfan 2016_3_23
void CInfoRoll_ex::updateCreatetime(string strCreateTime)
{
	createtime = strCreateTime;
}
//-------------------------------------end   yangfan 2016_3_23

//-------------------------------------begin yangfan 2016_3_24
void CInfoRoll_ex::updateId(string strId)
{
	number = strId;
}
//-------------------------------------end   yangfan 2016_3_24


